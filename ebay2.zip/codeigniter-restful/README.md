Codeigniter RestServer is an application web api. Maybe we call is CIR. <br>
CIR can return API with different functions. <br>
My idea for CIR is :<br>
 1. It can manager multi project.<br>
 2. support multi language.<br>
 3. return multi data type.<br>
 4. don't need session.<br>
so.<br>
  CIR need 1 master account for manage multi project .<br>
forexemple : <br>
  now, CIR can manage ebay API . It have multi function (manage item, manage category, order cart ).<br>
     I want add 2 application : <br>
         1. manage (is multisync).<br>
         2. order cart (is ebayForSeller).<br>
so. I need account manage 2 this application .<br>
This account can :<br>
  know have how many application.<br>
  permission : functions use.<br>
This things near like dev.ebay.com.<br>
illustration :<br>
https://imgur.com/a9Eoahh<br>
<img src="https://imgur.com/a9Eoahh" >