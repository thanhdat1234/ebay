<?php

defined('BASEPATH') OR exit('No direct script access allowed');
/** @noinspection PhpIncludeInspection */
/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Test extends MY_Controller{

    function __construct()
    {
        // Construct the parent class
        parent::__construct();
        // Configure limits on our controller methods
        // Ensure you have created the 'limits' table and enabled 'limits' within application/config/rest.php
        $this->methods['index_get']['limit'] = 500; // 500 requests per hour per user/key
        $this->methods['users_post']['limit'] = 100; // 100 requests per hour per user/key
        $this->methods['users_delete']['limit'] = 50; // 50 requests per hour per user/key
        //print_r($this->methods);
    }

    public function index_get()
    {
        /*$string = $this->get('pass');
        echo $string;
        echo $this->_hashPassword($string);
        return;*/
        $this->load->model('ebc2s');
        $data = $this->ebc2s->getArrayCategory();
        $dataz = $this->ebc2s->buidPathCategory($data);
        //pre($data);
        pre($dataz);
        die;
        try{
            die;
            $this->load->library('ebaysdk/tradingz');
            $zData = $this->tradingz->getCategories(0);
            if(!empty($zData['error'])){
                echo 'fail';
                pre($zData);
                //$this->_returnBad($this->lang->line('text_long_message_system_ebay'));
            }else{
                $this->load->model('Ebcs');
                /*step one delete All*/
                //$flash = $this->tb_ebc->deleteAllCategory();
                //if($flash == true){
                    $d = date_create($zData['UpdateTime']);
                    $in_item['ebc_upTime']  = date_format($d,"Y-m-d H:i:s"); // update Time for check get update
                    $in_item['ebc_vch1']    = 0; // Categories site ID
                    /*pre($zData);
                    return;*/
                    for($i=0;$i <$zData['CategoryCount'];$i++){
                        if($zData['CategoryArray']['Category']){
                            $item = $zData['CategoryArray']['Category'];

                            $in_item['ebc_int0'] = $item[$i]['CategoryID']; // CategoryID
                            $in_item['ebc_int1'] = $item[$i]['CategoryLevel']; // Category Level
                            $in_item['ebc_vch0'] = $item[$i]['CategoryName']; // Category Name
                            $in_item['ebc_int2'] = $item[$i]['CategoryParentID'][0]; // Category Parent ID
                            $in_item['ebc_dat1'] = !empty($item[$i]['BestOfferEnabled'])?$item[$i]['BestOfferEnabled']:null; // Best Offer Enabled
                            $in_item['ebc_dat2'] = !empty($item[$i]['AutoPayEnabled'])?$item[$i]['AutoPayEnabled']:null; // Auto Pay enabled
                            $in_item['ebc_dat3'] = !empty($item[$i]['LeafCategory'])?$item[$i]['LeafCategory']:null; // Leaf category
                            $result_in = $this->tb_ebc->addRowData($in_item);
                            if(!empty($result_in['flash']) && $result_in['flash'] == 0){
                                echo "insert fail";
                                pre($result_in);
                            }else{
                                pre($result_in);
                            }
                        }
                    }
                    /*date('Y-m-d\Th:i:s.000\Z', strtotime($startTimeFrom)),$requestXml)*/
                    /*echo $zData['UpdateTime']."<br>";
                    $d = date_create($zData['UpdateTime']);
                    echo date_format($d,"Y/m/d H:i:s")."<br>";

                    echo strtotime($zData['UpdateTime'])."<br>";
                    echo date('Y-m-d\Th:i:s.000\Z',strtotime($zData['UpdateTime']));*/

                    //echo date_create(strtotime($zData['UpdateTime']),'d-m-Y H:i:s');
                    pre($zData);
                /*}else{
                    echo "bad";
                }*/
            }

        }catch (Exception $exception){
            $this->_returnBad($exception->getMessage());
        }
        return;
        $this->load->library('ebaysdk/tradingz');
        $this->tradingz->getCategories();
        /*$this->load->library('ebaysdk/oauth');
        $this->load->model('tb_ebt');
        try{
            $data_token = $this->oauth->getAppToken();
            if(!empty($data_token['error'])){
                return $data_token['error_description'].'error 1zzzz';
            }else{
                try{
                    $id = $this->tb_ebt->addRowData($data_token);
                    if(!$id){
                        return false;
                    }else{
                        //return ...
                    }
                }catch (Exception $exception){
                    //return $exception->getMessage();
                }
            }
        }catch (Exception $exception){
            echo "dat";
            pre($exception->getMessage());
            //return $exception->getMessage();
        }*/
        //$this->tb_ebt->addRowData([]);
        //$this->load->library('ebaysdk/tradingz');

        //$ebayz = new EbayXml(['test.xcmml']);
        //$dataz = $this->oauth->getAppToken();
        //pre($dataz);
        die("123");
        $data = [];
        echo $this->_hashPassword('a123456');
        return $this->load->view('/user/test_post.php',$data);

        //die('123');
        // Users from a data store e.g. database
        $users = [
            ['id' => 1, 'name' => 'John', 'email' => 'john@example.com', 'fact' => 'Loves coding'],
            ['id' => 2, 'name' => 'Jim', 'email' => 'jim@example.com', 'fact' => 'Developed on CodeIgniter'],
            ['id' => 3, 'name' => 'Jane', 'email' => 'jane@example.com', 'fact' => 'Lives in the USA', ['hobbies' => ['guitar', 'cycling']]],
        ];

        $id = $this->get('id');
        /*echo $id;
        echo "<hr>";
        $idz = $this->get('dat');
        echo $idz;
        echo "<hr>";
        $idzs = $this->get('format');
        echo $idzs;
        die;*/
        // If the id parameter doesn't exist return all the users

        if ($id === NULL)
        {
            // Check if the users data store contains users (in case the database result returns NULL)
            if ($users)
            {
                // Set the response and exit
                $this->response($users, REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
            }
            else
            {
                // Set the response and exit
                $this->response([
                    'status' => FALSE,
                    'message' => 'No users were found'
                ], REST_Controller::HTTP_NOT_FOUND); // NOT_FOUND (404) being the HTTP response code
            }
        }

        // Find and return a single record for a particular user.

        $id = (int) $id;

        // Validate the id.
        if ($id <= 0)
        {
            // Invalid id, set the response and exit.
            $this->response(NULL, REST_Controller::HTTP_BAD_REQUEST); // BAD_REQUEST (400) being the HTTP response code
        }

        // Get the user from the array, using the id as key for retrieval.
        // Usually a model is to be used for this.

        $user = NULL;

        if (!empty($users))
        {
            foreach ($users as $key => $value)
            {
                if (isset($value['id']) && $value['id'] === $id)
                {
                    $user = $value;
                }
            }
        }

        if (!empty($user))
        {
            $this->set_response($user, REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
        }
        else
        {
            $this->set_response([
                'status' => FALSE,
                'message' => 'User could not be found'
            ], REST_Controller::HTTP_NOT_FOUND); // NOT_FOUND (404) being the HTTP response code
        }
    }

    public function users_post()
    {
        //die('1233');

        // $this->some_model->update_user( ... );
        $message = [
            'id' => 100, // Automatically generated by the model
            'name' => $this->post('name'),
            'email' => $this->post('email'),
            'message' => 'Added a resource'
        ];

        $this->set_response($message, REST_Controller::HTTP_CREATED); // CREATED (201) being the HTTP response code
    }

    public function users_delete()
    {
        $id = (int) $this->get('id');

        // Validate the id.
        if ($id <= 0)
        {
            // Set the response and exit
            $this->response(NULL, REST_Controller::HTTP_BAD_REQUEST); // BAD_REQUEST (400) being the HTTP response code
        }

        // $this->some_model->delete_something($id);
        $message = [
            'id' => $id,
            'message' => 'Deleted the resource'
        ];

        $this->set_response($message, REST_Controller::HTTP_NO_CONTENT); // NO_CONTENT (204) being the HTTP response code
    }

}
