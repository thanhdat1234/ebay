<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: thanhdat
 * Date: 09/11/2017
 * Time: 16:33
 */

class EbayToken extends CI_Controller
{
    protected $_user_mid = 0;

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
    }
    public function indexToken($token,$eby_mid){
        $this->load->library('ebaysdk/oauth');
        //return redirect($this->oauth->getUserTokenz());
        $url_login = $this->oauth->getAccessToken();
        $this->_user_mid = $eby_mid;
        $newdata = array(
            'eby_mid'  => (int)$eby_mid,
        );

        $this->session->set_userdata($newdata);
        redirect($url_login);
    }
    public function getIndexToken(){
        $this->load->library('ebaysdk/oauth');
        $this->load->model('ebys');
        $code = $this->input->get('code');
        $result_arr = $this->oauth->getUserToken($code);
        $data= [
            'eby_vch3'      => $result_arr['access_token'],    // EBAY_AuthToken
            'eby_dat0'      => $result_arr['expires_in']/3600/24,    // EBAY_AuthTokenExpire
        ];
        echo $this->session->userdata('eby_mid');
        die;
        $this->ebys->updateDatas($data,$this->session->userdata('eby_mid'));
        echo '
            <script>
                  window.opener.location.reload();window.close();
            </script>
        ';
    }
}