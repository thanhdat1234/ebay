<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
//require APPPATH . '/libraries/REST_Controller.php';

/**
 * Keys Controller
 * This is a basic Key Management REST controller to make and delete keys
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Trading extends MY_Controller {

    public function __construct()
    {
        parent:: __construct();
    }
    protected $methods = [
        'routerFunction_get' => ['level' => 10, 'limit' => 10]
    ];
/*==================================
|Router function get
|===================================
*/
    public function routerFunction_get(){
        $call_function = $this->head($this->config->item('x_api_callname'));
        switch ($call_function){
            case 'getCategoriesFromEbay'          :   $this->_checkAccessToken(); $this->_getCategoriesFromEbay(); break;
            case 'getListCategories'                  :   $this->_checkAccessToken(); $this->_getListCategories(); break;
            case 'getSearchUsers'           :   $this->_checkAccessToken(); $this->_getSearchUsers(); break;
            default : $this->response([
                $this->config->item('action_name')=>$this->config->item('action_fail'),
                $this->config->item('error_short_message') => $this->lang->line('text_miss_param'),
                $this->config->item('error_name') => [
                    'error'=>[
                        $this->config->item('param_name')           =>  $this->config->item('x_api_callname'),
                        $this->config->item('error_long_message')   =>  $this->lang->line('text_rest_invalid_call_name')
                    ]
                ]
            ], REST_Controller::HTTP_NOT_FOUND);
                break;
        }
    }

    public function _setTableCategories(){

    }
    public function __destruct()
    {
        // TODO: Implement __destruct() method.
    }
}
