<?php
/**
 * Created by PhpStorm.
 * User: thanhdat
 * Date: 20/10/2017
 * Time: 16:17
 */
Class Users extends MY_Controller {
    public function __construct()
    {
        parent:: __construct();
    }
    protected $methods = [
        'routerFunction_post' => ['level' => 1,'limit' => 100],
    ];
    public function routerFunction_post(){
        $data[0] = $this->post();
        $data[1] = $this->get();
        $data[2] = $this->head();
        //die;
        $this->return_array_creat_file('logz','user_z.txt',json_encode($data));

        $call_function = $this->head('X-AGL-API-CALL-NAME');
        switch ($call_function){
            case 'addUser'          : $this->addUser(); break;
            case 'getLoginToken'    : $this->getLoginToken(); break;
            default : $this->response([
                'status' => FALSE,
                'message' => 'No users were found'
            ], REST_Controller::HTTP_NOT_FOUND);
            break;
        }
    }
    public function addUser()
    {
        $this->response([
            'status' => 1,
            'message' => 'No users were found'
        ], REST_Controller::HTTP_OK);
    }
    public function getLoginToken()
    {
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        //print_r($this->input->post());
        $this->form_validation->set_rules('user_name', 'Username', 'required|min_length[8]');
        $this->form_validation->set_rules('user_pass', 'Password', 'required|min_length[8]');
        if ($this->form_validation->run() == FALSE)
        {
            $data = $this->validation_errors();
            //print_r(form_error('user_name'));
            /*echo "<pre>";
            print_r(validation_errors('user_name'));
            echo "</pre>";*/
            print_r($data);
            $this->response([
                'status' => 0,
                'message' => $this->lang->line('text_rest_invalid_call_name')
            ], REST_Controller::HTTP_BAD_REQUEST);    
        }
        else
        {
            //$this->load->view('formsuccess');
        }
        die('123');
        $this->response([
            'status' => 1,
            'message' => 'No users were found'
        ], REST_Controller::HTTP_OK);
    }
}