<?php
/**
 * Created by PhpStorm.
 * User: thanhdat
 * Date: 20/10/2017
 * Time: 16:17
 */
Class User extends MY_Controller {

    /**define field for table user */
    public $user_name               = 'usr_vch0'; //user name
    public $user_pass               = 'usr_vch1'; // user pass
    public $user_id                 = 'usr_mid'; // num user's id
    public $delete_at               = 'usr_dlday'; // num user's id
    public $expire_accept_time      = 7200; // num user's id
    /**end define field*/
    public function __construct()
    {
        parent:: __construct();
    }
    protected $methods = [
        'routerFunction_post'       => ['level' => 1,'limit' => 100],
        'routerFunction_get'        => ['level' => 1,'limit' => 100],
        'routerFunction_delete'     => ['level' => 1,'limit' => 100],
    ];

/*==================================
|Router function post
|===================================
*/
    public function routerFunction_post(){
        $call_function = $this->head($this->config->item('x_api_callname'));
        switch ($call_function){
            case 'getLoginToken'    : $this->_getLoginToken(); break;
            default : $this->response([
                $this->config->item('action_name')=>$this->config->item('action_fail'),
                $this->config->item('error_short_message') => $this->lang->line('text_miss_param'),
                $this->config->item('error_name') => [
                    'error'=>[
                    $this->config->item('param_name')           =>  $this->config->item('x_api_callname'),
                    $this->config->item('error_long_message')   =>  $this->lang->line('text_rest_invalid_call_name')
                        ]
                ]
            ], REST_Controller::HTTP_NOT_FOUND);
            break;
        }
    }
/*==================================
|Router function delete // next version have 2 function delete only and delete multi
|===================================
*/
    public function routerFunction_delete(){
        $call_function = $this->head($this->config->item('x_api_callname'));
        switch ($call_function){
            case 'deleteUser'             :   $this->_checkAccessToken(); $this->_deleteUser(); break;
            default : $this->response([
                $this->config->item('action_name')=>$this->config->item('action_fail'),
                $this->config->item('error_short_message') => $this->lang->line('text_miss_param'),
                $this->config->item('error_name') => [
                    'error'=>[
                    $this->config->item('param_name')           =>  $this->config->item('x_api_callname'),
                    $this->config->item('error_long_message')   =>  $this->lang->line('text_rest_invalid_call_name')
                        ]
                ]
            ], REST_Controller::HTTP_NOT_FOUND);
            break;
        }
    }
/*==================================
|Router function get
|===================================
*/
    public function routerFunction_get(){
        $call_function = $this->head($this->config->item('x_api_callname'));
        switch ($call_function){
            case 'getListUsers'             :   $this->_checkAccessToken(); $this->_getUsers(); break;
            case 'getUser'                  :   $this->_checkAccessToken(); $this->_getUser(); break;
            case 'getSearchUsers'           :   $this->_checkAccessToken(); $this->_getSearchUsers(); break;
            default : $this->response([
                $this->config->item('action_name')=>$this->config->item('action_fail'),
                $this->config->item('error_short_message') => $this->lang->line('text_miss_param'),
                $this->config->item('error_name') => [
                    'error'=>[
                        $this->config->item('param_name')           =>  $this->config->item('x_api_callname'),
                        $this->config->item('error_long_message')   =>  $this->lang->line('text_rest_invalid_call_name')
                    ]
                ]
            ], REST_Controller::HTTP_NOT_FOUND);
                break;
        }
    }
    public function addUser()
    {
        $this->response([
            'status' => 1,
            'message' => 'No users were found'
        ], REST_Controller::HTTP_OK);
    }
/*============================================
| This function check account and regist access key and return.
|============================================*/
    public function _getLoginToken()
    {
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        //print_r($this->input->post());
        $this->form_validation->set_rules((string)$this->user_name, 'User name', 'required|min_length[4]');
        $this->form_validation->set_rules((string)$this->user_pass, 'Password', 'required|min_length[6]');
        if ($this->form_validation->run() == FALSE)
        {
            //$data  = $this->validation_errors();
            $error = null;
            if(form_error((string)$this->user_name)){
                $error['error'][] = [
                    $this->config->item('param_name')           =>  (string)$this->user_name,
                    $this->config->item('error_long_message')   =>  form_error((string)$this->user_name)
                ];
            }
            if(form_error((string)$this->user_pass)){
                $error['error'][] = [
                    $this->config->item('param_name')           =>  (string)$this->user_pass,
                    $this->config->item('error_long_message')   =>  form_error((string)$this->user_pass)
                ];
            }
            $this->response([
                $this->config->item('action_name')=>$this->config->item('action_fail'),
                $this->config->item('error_short_message') => $this->lang->line('text_short_message_user'),
                $this->config->item('error_name') => $error
            ], REST_Controller::HTTP_BAD_REQUEST);    
        }
        else
        {
            $this->load->model('users');
            $data[$this->user_name] = (string)$this->input->post($this->user_name);
            $data[$this->user_pass] = $this->_hashPassword((string)$this->input->post($this->user_pass));
            $user = $this->users->getRow($data);
            if(!$user){
                $this->response([
                    $this->config->item('action_name')=>$this->config->item('action_fail'),
                    $this->config->item('error_short_message') => $this->lang->line('text_short_message_user'),
                    $this->config->item('error_name') => [
                        'error'=>[
                            $this->config->item('error_long_message')   =>  $this->lang->line('text_long_message_user')
                            ]
                    ]
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
            if($user){
                $this->load->model('keys');
                $data = null;
                $data['user_mid']       = $user->{$this->user_id};
                $data['user_id']        = $user->{$this->user_name};
                $data['expire']         = $this->expire_accept_time;
                if($this->config->item('token_expire_value')){
                    $data['expire']         = $this->config->item('token_expire_value');
                }
                $token = $this->keys->createKey(1,$data,1);
                if(!$token){
                    $this->response([
                        $this->config->item('action_name')=>$this->config->item('action_fail'),
                        $this->config->item('error_short_message') => $this->lang->line('text_short_message_key'),
                        $this->config->item('error_name') => [
                            'error'=>[
                                $this->config->item('error_long_message')   =>  $this->lang->line('text_long_message_key')
                            ]
                        ]
                    ], REST_Controller::HTTP_BAD_REQUEST);
                }
                if($token){
                    $this->load->model('usas');
                    $group = $this->usas->joinGroupUser($user->{$this->user_id});
                    //pre($group);
                    if(!$group){
                        $this->response([
                            $this->config->item('action_name')=>$this->config->item('action_fail'),
                            $this->config->item('error_short_message') => $this->lang->line('text_short_message_group'),
                            $this->config->item('error_name') => [
                                'error'=>[
                                    $this->config->item('error_long_message')   =>  $this->lang->line('text_long_message_group')
                                ]
                            ]
                        ], REST_Controller::HTTP_BAD_REQUEST);
                    }
                    /*array_push($user,'grp_id',$group->grp_int0);
                    pre($user);*/
                    unset($user->updated_at);
                    unset($user->deleted_at);
                    unset($user->token);
                    unset($user->password);
                    $this->response([
                        $this->config->item('action_name')=>$this->config->item('action_success'),
                        $this->config->item('user_data_return') => [
                            'userResponse'                              =>  $user,
                            $this->config->item('token_name')           =>  $token,
                            $this->config->item('token_expire_name')    =>  $data['expire'],
                            'grp_id'                                    =>  $group->grp_int0
                        ]
                    ], REST_Controller::HTTP_OK);
                }
            }
            $this->response([
                $this->config->item('action_name')=>$this->config->item('action_fail'),
                $this->config->item('error_name') => 'No users were found',
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }
/*============================================
| This function get list user
|============================================*/
    public function _getUsers()
    {
        $this->load->model('users');
        $limit      = (int)$this->get('limit');
        $page       = (int)$this->get('page');
        $dlday      = (int)$this->get('dlday');
        //$litmit = (int)$this->get('limit');
        $where = [
            $this->delete_at=>null
        ];
        if($dlday){
            $where = [$this->delete_at." !="=>null];
        }

        $data = $this->users->getList($limit,$page,$where);
        if(!$data){
            $this->response([
                $this->config->item('action_name')=>$this->config->item('action_fail'),
                $this->config->item('error_short_message') => $this->lang->line('text_short_message_data'),
                $this->config->item('error_name') => [
                    'error'=>[
                        $this->config->item('error_long_message')   =>  $this->lang->line('text_long_message_data')
                    ]
                ]
            ], REST_Controller::HTTP_BAD_REQUEST);
        }

        $this->response([
            $this->config->item('action_name')=>$this->config->item('action_success'),
            $this->config->item('user_list_data_return') => [
                'Items'                              => $data,
            ]
        ], REST_Controller::HTTP_OK);
    }
/*============================================
| This function get list user
|============================================*/
    public function _getSearchUsers()
    {
        $this->load->model('users');
        $limit      = (int)$this->get('limit');
        $page       = (int)$this->get('page');
        $dlday      = (int)$this->get('dlday');
        $keywo      = (string)$this->get('keywords');
        //$litmit = (int)$this->get('limit');
        $like = false;
        if($keywo){
            $like = [
                $this->user_name => $keywo
            ];
        }
        $where = [
            $this->delete_at=>null
        ];
        if($dlday){
            $where = [$this->delete_at." !="=>null];
        }

        $data = $this->users->getSearch($like,$where,$limit,$page);
        if(!$data){
            $this->response([
                $this->config->item('action_name')=>$this->config->item('action_fail'),
                $this->config->item('error_short_message') => $this->lang->line('text_short_message_data'),
                $this->config->item('error_name') => [
                    'error'=>[
                        $this->config->item('error_long_message')   =>  $this->lang->line('text_long_message_data')
                    ]
                ]
            ], REST_Controller::HTTP_BAD_REQUEST);
        }

        $this->response([
            $this->config->item('action_name')=>$this->config->item('action_success'),
            $this->config->item('user_list_data_return') => [
                'Items'                              => $data,
            ]
        ], REST_Controller::HTTP_OK);
    }
/*============================================
| This function get list user
|============================================*/
    public function _deleteUser()
    {
        $this->load->model('users');
        $id      = $this->delete('id');
        $where = [
            $this->user_id=>$id
        ];
        //print_r($where);
        $data = $this->users->getRow($where);
        if(!$data){
            $this->response([
                $this->config->item('action_name')=>$this->config->item('action_fail'),
                $this->config->item('error_short_message') => $this->lang->line('text_short_message_data'),
                $this->config->item('error_name') => [
                    'error'=>[
                        $this->config->item('error_long_message')   =>  $this->lang->line('text_long_message_data')
                    ]
                ]
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
        $flash = $this->users->deleteItem($id);
        if(!$flash){
            $this->response([
                $this->config->item('action_name')=>$this->config->item('action_fail'),
                $this->config->item('error_short_message') => $this->lang->line('text_short_message_data'),
                $this->config->item('error_name') => [
                    'error'=>[
                        $this->config->item('error_long_message')   =>  $this->lang->line('text_long_message_data')
                    ]
                ]
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
        $this->response([
            $this->config->item('action_name')=>$this->config->item('action_success'),
            'messages' => $this->lang->line('text_message_success_delete')
        ], REST_Controller::HTTP_OK);
    }
}