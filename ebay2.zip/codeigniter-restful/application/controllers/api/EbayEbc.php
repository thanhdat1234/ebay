<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @Auth : Nguyen Thanh Dat
 * @email: thanhdat@allgrow-labo.jp
 * @Controller : ebay category
 */
class EbayEbc extends MY_Controller {

    public function __construct()
    {
        parent::__construct();
    }
    protected $methods = [
        'routerFunction_get' => ['level' => 10, 'limit' => 10]
    ];
/*===========================================
 * Begin router function get
  ===========================================*/
    public function routerFunction_get(){
        $call_function = $this->head($this->config->item('x_api_callname'));
        switch ($call_function){
            case 'getCategoriesFromEbay':
                $this->_getCategoriesFromEbay();
            break;

            case 'getSearchCategories':
                $this->_checkAccessToken();
                $this->_getSearchCategories();
            break;

            case 'getListCategory':
                $this->_checkAccessToken();
                $this->_getListCategory();
            break;

            case 'getFirstCategory':
                $this->_checkAccessToken();
                $this->_getFirstCategory();
            break;

            default :
                $this->response([
                    $this->config->item('action_name')=>$this->config->item('action_fail'),
                    $this->config->item('error_short_message') => $this->lang->line('text_miss_param'),
                    $this->config->item('error_name') => [
                        'error'=>[
                            $this->config->item('param_name')           =>  $this->config->item('x_api_callname'),
                            $this->config->item('error_long_message')   =>  $this->lang->line('text_rest_invalid_call_name')
                        ]
                    ]
                ],REST_Controller::HTTP_NOT_FOUND);
            break;
        }
    }
/**
*@Begin function type get
*/
    public function _getCategoriesFromEbay(){
        try{
            $this->load->library('ebaysdk/tradingz');
            $siteID = 0;
            if(!empty($this->get('SiteID'))){
                $siteID = (int)$this->get('SiteID');
            }
            $zData = $this->tradingz->getCategories($siteID);
            if(!empty($zData['error'])){
                $this->_returnBad($this->lang->line('text_long_message_system_ebay'));
            }else{
                $this->load->model('Ebcs');
                /*step one delete All*/
                $whereData = ['ebc_int3'=>$siteID];
                $flash = $this->tb_ebc->deleteAllCategory($whereData);
                if($flash == true){
                    $d = date_create($zData['UpdateTime']);
                    $in_item['ebc_upTime']  = date_format($d,"Y-m-d H:i:s"); // update Time for check get update
                    $in_item['ebc_int3']    = $siteID; // Categories site ID
                    /*pre($zData);
                    return;*/
                    for($i=0;$i <$zData['CategoryCount'];$i++){
                        if($zData['CategoryArray']['Category']){
                            $item = $zData['CategoryArray']['Category'];
                            $in_item['ebc_int0'] = $item[$i]['CategoryID']; // CategoryID
                            $in_item['ebc_int1'] = $item[$i]['CategoryLevel']; // Category Level
                            $in_item['ebc_vch0'] = $item[$i]['CategoryName']; // Category Name
                            $in_item['ebc_int2'] = $item[$i]['CategoryParentID'][0]; // Category Parent ID
                            $in_item['ebc_dat1'] = !empty($item[$i]['BestOfferEnabled'])?$item[$i]['BestOfferEnabled']:null; // Best Offer Enabled
                            $in_item['ebc_dat2'] = !empty($item[$i]['AutoPayEnabled'])?$item[$i]['AutoPayEnabled']:null; // Auto Pay enabled
                            $in_item['ebc_dat3'] = !empty($item[$i]['LeafCategory'])?$item[$i]['LeafCategory']:null; // Leaf category
                            $result_in = $this->tb_ebc->addRowData($in_item);
                            if(!empty($result_in['flash']) && $result_in['flash'] == 0){
                                $this->_returnBad($this->lang->line('text_long_message_system_ebay'));
                            }
                        }
                    }

                }else{
                    $this->_returnBad($this->lang->line('text_long_message_system_ebay'));
                }
            }

        }catch (Exception $exception){
            $this->_returnBad($exception->getMessage());
        }
    }

    public function _getUpdateCategory(){
        try{
            $this->load->library('ebaysdk/tradingz');
            $siteID = 0;
            if(!empty($this->get('SiteID'))){
                $siteID = (int)$this->get('SiteID');
            }

            $zData = $this->tradingz->getCategories($siteID);
            if(!empty($zData['error'])){
                $this->_returnBad($this->lang->line('text_long_message_system_ebay'));
            }else{
                $this->load->model('Ebcs');
                /*step one delete All*/
                $whereData = ['ebc_int3'=>$siteID];
                $flash = $this->tb_ebc->deleteAllCategory($whereData);
                if($flash == true){
                    $d = date_create($zData['UpdateTime']);
                    $in_item['ebc_upTime']  = date_format($d,"Y-m-d H:i:s"); // update Time for check get update
                    $in_item['ebc_int3']    = $siteID; // Categories site ID
                    /*pre($zData);
                    return;*/
                    for($i=0;$i <$zData['CategoryCount'];$i++){
                        if($zData['CategoryArray']['Category']){
                            $item = $zData['CategoryArray']['Category'];
                            $in_item['ebc_int0'] = $item[$i]['CategoryID']; // CategoryID
                            $in_item['ebc_int1'] = $item[$i]['CategoryLevel']; // Category Level
                            $in_item['ebc_vch0'] = $item[$i]['CategoryName']; // Category Name
                            $in_item['ebc_int2'] = $item[$i]['CategoryParentID'][0]; // Category Parent ID
                            $in_item['ebc_dat1'] = !empty($item[$i]['BestOfferEnabled'])?$item[$i]['BestOfferEnabled']:null; // Best Offer Enabled
                            $in_item['ebc_dat2'] = !empty($item[$i]['AutoPayEnabled'])?$item[$i]['AutoPayEnabled']:null; // Auto Pay enabled
                            $in_item['ebc_dat3'] = !empty($item[$i]['LeafCategory'])?$item[$i]['LeafCategory']:null; // Leaf category
                            $result_in = $this->tb_ebc->addRowData($in_item);
                            if(!empty($result_in['flash']) && $result_in['flash'] == 0){
                                $this->_returnBad($this->lang->line('text_long_message_system_ebay'));
                            }
                        }
                    }

                }else{
                    $this->_returnBad($this->lang->line('text_long_message_system_ebay'));
                }
            }

        }catch (Exception $exception){
            $this->_returnBad($exception->getMessage());
        }
    }

    public function _getFirstCategory(){
        $this->load->model('ebcs');
        $where =[
            'ebc_int1'=>1,
        ];
        $data = $this->ebcs->getListAndJoinLang($where);
        if(!$data){
            $this->_returnBad($this->lang->line('text_long_message_system_ebay'));
        }
        $this->response([
            $this->config->item('action_name')=>$this->config->item('action_success'),
            $this->config->item('ebc_list_data_return') => [
                'Items' => $data,
            ]
        ], REST_Controller::HTTP_OK);
    }

    public function _getListCategory(){
        $this->load->model('ebcs');
        $level      = (int)$this->get('level');
        $parent     = (int)$this->get('parent');
        $where =[
            'ebc_int1'=> $level == 0?1:$level,
            'ebc_int2'=> $parent,
        ];
        $data = $this->ebcs->getListAndJoinLang($where);
        if(!$data){
            $this->_returnBad($this->lang->line('text_long_message_system_ebay'));
        }
        $this->response([
            $this->config->item('action_name')=>$this->config->item('action_success'),
            $this->config->item('ebc_list_data_return') => [
                'Items' => $data,
            ]
        ], REST_Controller::HTTP_OK);
    }
/**
 *@Intro : functions return response
 */
    public function _returnBad($e){
        $this->response([
            $this->config->item('action_name')=>$this->config->item('action_fail'),
            $this->config->item('error_short_message') => $this->lang->line('text_short_message_system'),
            $this->config->item('error_name') => [
                'error'=>[
                    $this->config->item('error_long_message')   =>  $e
                ]
            ]
        ], REST_Controller::HTTP_NOT_FOUND);
    }
}
