<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: thanhdat
 * Date: 03/11/2017
 * Time: 15:42
 */

class EbyToken extends My_controller
{
    public function __construct()
    {
        parent::__construct();
    }
    protected $methods = [
        'routerFunction_post'       => ['level' => 1,'limit' => 100],
        'routerFunction_get'        => ['level' => 1,'limit' => 100],
    ];

    /*==================================
    |Router function post
    |===================================
    */
    public function routerFunction_post(){
        $call_function = $this->head($this->config->item('x_api_callname'));
        switch ($call_function){
            //case 'getLoginToken'    : $this->_getLoginToken(); break;
            default : $this->response([
                $this->config->item('action_name')=>$this->config->item('action_fail'),
                $this->config->item('error_short_message') => $this->lang->line('text_miss_param'),
                $this->config->item('error_name') => [
                    'error'=>[
                        $this->config->item('param_name')           =>  $this->config->item('x_api_callname'),
                        $this->config->item('error_long_message')   =>  $this->lang->line('text_rest_invalid_call_name')
                    ]
                ]
            ], REST_Controller::HTTP_NOT_FOUND);
                break;
        }
    }
    /*==================================
    |Router function delete // next version have 2 function delete only and delete multi
    |===================================
    */
    public function routerFunction_delete(){
        $call_function = $this->head($this->config->item('x_api_callname'));
        switch ($call_function){
            //case 'deleteUser'             :   $this->_checkAccessToken(); $this->_deleteUser(); break;
            default : $this->response([
                $this->config->item('action_name')=>$this->config->item('action_fail'),
                $this->config->item('error_short_message') => $this->lang->line('text_miss_param'),
                $this->config->item('error_name') => [
                    'error'=>[
                        $this->config->item('param_name')           =>  $this->config->item('x_api_callname'),
                        $this->config->item('error_long_message')   =>  $this->lang->line('text_rest_invalid_call_name')
                    ]
                ]
            ], REST_Controller::HTTP_NOT_FOUND); break;
        }
    }
    /*==================================
    |Router function get
    |===================================
    */
    public function routerFunction_get(){
        $call_function = $this->head($this->config->item('x_api_callname'));
        switch ($call_function){
            //case 'getListUsers'             :   $this->_checkAccessToken(); $this->_getUsers(); break;
            default : $this->response([
                $this->config->item('action_name')=>$this->config->item('action_fail'),
                $this->config->item('error_short_message') => $this->lang->line('text_miss_param'),
                $this->config->item('error_name') => [
                    'error'=>[
                        $this->config->item('param_name')           =>  $this->config->item('x_api_callname'),
                        $this->config->item('error_long_message')   =>  $this->lang->line('text_rest_invalid_call_name')
                    ]
                ]
            ], REST_Controller::HTTP_NOT_FOUND); break;
        }
    }
/*===============*/
    public function _getTokenUser(){

    }
/*===============*/
    public function _getTokenApplication(){
        $this->load->library('ebaysdk/oauth');
        $this->load->model('Ebts');
        try{
            $data_token = $this->oauth->getAppToken();
            if(!empty($data_token['error'])){
                return $data_token['error_description'].'error 1zzzz';
            }else{
                try{
                    $id = $this->tb_ebt->addRowData($data_token);
                    if(!$id){
                        /*return error*/
                        return false;
                    }else{
                        /*return data*/
                        //return ...
                    }
                }catch (Exception $exception){
                    /*return error*/
                    return $exception->getMessage();
                }
            }
        }catch (Exception $exception){
            /*return error*/
            return $exception->getMessage();
        }

    }
/*===============*/
    public function _getAccessToken(){

    }
}