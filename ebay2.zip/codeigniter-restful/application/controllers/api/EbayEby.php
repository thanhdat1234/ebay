<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @Auth : Nguyen Thanh Dat
 * @email: thanhdat@allgrow-labo.jp
 * @Controller : ebay category
 */
class EbayEby extends MY_Controller {
    /**define field for table eby */
    public $delete_at               = 'eby_dlday'; // num user's id

    public function __construct()
    {
        parent::__construct();
    }
    protected $methods = [
        'routerFunction_get' => ['level' => 10, 'limit' => 10]
    ];
/*===========================================
 * Begin router function get
  ===========================================*/
    public function routerFunction_get(){
        $call_function = $this->head($this->config->item('x_api_callname'));
        switch ($call_function){
            case 'getListAccountEbay'               :   $this->_checkAccessToken(); $this->_getListAccountEbay();    break;
            case 'requestLoginEbay'                 :   $this->_checkAccessToken(); $this->_requestLoginEbay();    break;
            default : $this->response([
                $this->config->item('action_name')=>$this->config->item('action_fail'),
                $this->config->item('error_short_message') => $this->lang->line('text_miss_param'),
                $this->config->item('error_name') => [
                    'error'=>[
                        $this->config->item('param_name')           =>  $this->config->item('x_api_callname'),
                        $this->config->item('error_long_message')   =>  $this->lang->line('text_rest_invalid_call_name')
                    ]
                ]
            ], REST_Controller::HTTP_NOT_FOUND);
                break;
        }
    }
/**
*@Begin function type get
*/
    public function _getListAccountEbay(){
        try{
            $access_token = $this->head($this->config->item('x_api_access_key'));
            $this->load->model('keys');
            $token_info = $this->keys->getUserIDFromAccessKey($access_token);
            if(!$token_info){
                $this->_returnBad('Can\'t find account! Token is invalid.');
            }
            $this->load->model('ebys');
            $limit      = (int)$this->get('limit');
            $page       = (int)$this->get('page');
            $where = [$this->delete_at=>null,'eby_int0'=>$token_info->user_mid];
            $data = $this->ebys->getList($limit,$page,$where);
            if(!$data){
                $this->response([
                    $this->config->item('action_name')=>$this->config->item('action_fail'),
                    $this->config->item('error_short_message') => $this->lang->line('text_short_message_data'),
                    $this->config->item('error_name') => [
                        'error'=>[
                            $this->config->item('error_long_message')   =>  $this->lang->line('text_long_message_data')
                        ]
                    ]
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
            $this->response([
                $this->config->item('action_name')=>$this->config->item('action_success'),
                $this->config->item('eby_list_data_return') => [
                    'Items'                              => $data,
                ]
            ], REST_Controller::HTTP_OK);

        }catch (Exception $exception){
            $this->_returnBad($exception->getMessage());
        }
    }
    public function _requestLoginEbay(){

    }
/**
 *@Intro : functions return response
 */
    public function _returnBad($e){
        $this->response([
            $this->config->item('action_name')=>$this->config->item('action_fail'),
            $this->config->item('error_short_message') => $this->lang->line('text_short_message_system'),
            $this->config->item('error_name') => [
                'error'=>[
                    $this->config->item('error_long_message')   =>  $e
                ]
            ]
        ], REST_Controller::HTTP_NOT_FOUND);
    }
}
