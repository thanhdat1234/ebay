<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @Auth : Nguyen Thanh Dat
 * @email: thanhdat@allgrow-labo.jp
 * @Controller : ebay category
 */
class EbayPlc extends MY_Controller {

    public function __construct()
    {
        parent::__construct();
    }
    protected $methods = [
        'routerFunction_get' => ['level' => 10, 'limit' => 10]
    ];
    /*===========================================
     * Begin router function get
      ===========================================*/
    public function routerFunction_get(){
        $call_function = $this->head($this->config->item('x_api_callname'));
        switch ($call_function){
            case 'getPolicyAllFromEbayFollowAccount':
                $this->_checkAccessToken();
                $this->_getPolicyAllFromEbayFollowAccount();
                break;
            default :
                $this->response([
                    $this->config->item('action_name')=>$this->config->item('action_fail'),
                    $this->config->item('error_short_message') => $this->lang->line('text_miss_param'),
                    $this->config->item('error_name') => [
                        'error'=>[
                            $this->config->item('param_name')           =>  $this->config->item('x_api_callname'),
                            $this->config->item('error_long_message')   =>  $this->lang->line('text_rest_invalid_call_name')
                        ]
                    ]
                ],REST_Controller::HTTP_NOT_FOUND);
                break;
        }
    }
    /**
     *@Begin function type get
     */
    public function _getPolicyAllFromEbayFollowAccount(){
        try{
            if(!empty($this->get('eby_id'))){
                $this->load->model('ebys');
                $this->load->model('plcs');
                if(!$this->get('eby_id')){
                    $this->_returnBad($this->lang->line('text_long_message_param').". eby_id is required");
                }
                if(!$this->get('policy_id')){
                    $this->_returnBad($this->lang->line('text_long_message_param').". policy_id is required");
                }

                $policy_id = (string)$this->get('policy_id');
                $this->checkPolicyType($policy_id);

                $eby_id = (string)$this->get('eby_id');
                /*check account*/
                $where['eby_vch1'] =$eby_id;
                $account = $this->ebys->getRow($where);
                //pre($account);
                if(!$account){
                    $this->_returnBad($this->lang->line('text_long_message_param').". eby_id is invalid");
                }
                unset($where);
                $where['plc_vch3'] = $eby_id;
                $where['plc_vch4'] = $policy_id;
                $data = $this->plcs->getList($limit = false,$page = false,$where);
                if(!$data){
                    $this->_returnBad($this->lang->line('text_long_message_system_ebay'));
                }
                $this->response([
                    $this->config->item('action_name')=>$this->config->item('action_success'),
                    $this->config->item('ebc_list_data_return') => [
                        'Items' => $data,
                    ]
                ], REST_Controller::HTTP_OK);
                /*pre($account);
                die;*/
            }else{
                $this->_returnBad($this->lang->line('text_long_message_param'));
            }


        }catch(Exception $exception){
            $this->_returnBad($exception->getMessage());
        }
    }
    /**
     *@Intro : functions return response
     */
    public function _returnBad($e){
        $this->response([
            $this->config->item('action_name')=>$this->config->item('action_fail'),
            $this->config->item('error_short_message') => $this->lang->line('text_short_message_system'),
            $this->config->item('error_name') => [
                'error'=>[
                    $this->config->item('error_long_message')   =>  $e
                ]
            ]
        ], REST_Controller::HTTP_NOT_FOUND);
    }
}
