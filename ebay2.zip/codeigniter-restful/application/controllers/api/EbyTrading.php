<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: thanhdat
 * Date: 03/11/2017
 * Time: 17:03
 */

class EbyTrading
{
    public function __construct()
    {
        parent::__construct();
    }
    /*===============*/
    public function _getTokenUser(){

    }
    /*===============*/
    public function _getTokenApplication(){
        $this->load->library('ebaysdk/oauth');
        $this->load->model('Ebts');
        try{
            $data_token = $this->oauth->getAppToken();
            if(!empty($data_token['error'])){
                return $data_token['error_description'].'error 1zzzz';
            }else{
                try{
                    $id = $this->tb_ebt->addRowData($data_token);
                    if(!$id){
                        /*return error*/
                        return false;
                    }else{
                        /*return data*/
                        //return ...
                    }
                }catch (Exception $exception){
                    /*return error*/
                    return $exception->getMessage();
                }
            }
        }catch (Exception $exception){
            /*return error*/
            return $exception->getMessage();
        }

    }
    /*===============*/
    public function _getAccessToken(){

    }
}