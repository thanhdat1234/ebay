<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * 
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Ile extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();

        // Configure limits on our controller methods
        // Ensure you have created the 'limits' table and enabled 'limits' within application/config/rest.php
        $this->methods['iles_get']['limit'] = 50000; // 500 requests per hour per user/key
        $this->methods['iles_post']['limit'] = 10000; // 100 requests per hour per user/key
        $this->methods['iles_delete']['limit'] = 5000; // 50 requests per hour per user/key
       
    }

    public function iles_get()
    {
        // iles from a data store e.g. database
            $id = $this->get('id');
 
        // If the id parameter doesn't exist return all the iles

        if ($id === NULL)
        {
            $iles = $this->db->get('tb_ile')->result();
            if ($iles)
            {
                // Set the response and exit
                $this->response($iles, REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
            }
            else
            {
                // Set the response and exit
                $this->response([
                    'status' => FALSE,
                    'message' => 'No iles were found'
                ], REST_Controller::HTTP_NOT_FOUND); // NOT_FOUND (404) being the HTTP response code
            }
        }else{
                    $user = NULL;
                    $check = array('ile_mid'=>$id);
            
                    $user = $this->EbayIle->getRow($check);
                    if (!empty($user))
                    {
                        $this->set_response($user, REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
                    }
                    else
                    {
                        $this->set_response([
                            'status' => FALSE,
                            'message' => 'User could not be found'
                        ], REST_Controller::HTTP_NOT_FOUND); // NOT_FOUND (404) being the HTTP response code
                    }
            }
    }

    public function iles_post()
    {
       
     $type           = (string)$this->post('type');
        $token      = $this->post('token');
        if (empty($this->input->post())) {
            $result = ['status' => true,'message'=>'Input is empty !'];
            $this->set_response($result, REST_Controller::HTTP_BAD_REQUEST);
        }
        unset($_POST['token']);
       if($token !== $this->session->userdata('usr_vch0')){
                $result = [
                    'status' => false,
                    'message'=> 'Token is invalid'
                ];
                 $this->set_response($result, REST_Controller::HTTP_BAD_REQUEST);
        }
        
        if($type == 'listdata'){
            $keywords       = (string)$this->post('keywords');
            $dlday          = (int)$this->post('dlday');
            $limit          = (int)$this->post('limit');
            $page           = (int)$this->post('page');
            if($dlday === 0){

              $where = ['ile_dlday'=>null];
        }else{
              $where = ['ile_dlday !='=>null];
        }
        $like = false;
         if($keywords){
                $like = ['ile_vch0'=>(string)$keywords];
            }
            $dataJson = $this->EbayIle->getSearch($like,$where,$limit,$page);
            if($dataJson){
                 $this->set_response($dataJson, REST_Controller::HTTP_OK);
            }
        }else if($type == 'insert'){
       
             if(!empty($this->post()) ){
            // $this->form_validation->set_rules('ile_vch0', 'ID', 'required|min_length[6]|is_unique[tb_ile.ile_vch0]');
            $this->form_validation->set_rules('ile_vch0', 'user_name', 'required|min_length[6]');
             $this->form_validation->set_rules('ile_vch1', 'itemID', 'required');
              $this->form_validation->set_rules('ile_int1', 'eby_mid', 'integer');
          

             if ($this->form_validation->run() == FALSE)
            {
                $this->form_validation->set_error_delimiters('<div class="dat_error">', '</div>');

                foreach ($this->input->post() as $key=>$item) {
                   if (form_error($key)) {
                        $result = ['status' => false, 'message' => form_error($key),'field'=>$key];
                        $this->set_response($result, REST_Controller::HTTP_BAD_REQUEST);
                    }
                }
            }else{
                $this->load->library('bcrypt');
                $postData = $this->input->post();
                 unset($postData['type']);
               $newId = $postData['ile_mid'] = (int)$this->EbayIle->getMaxID()->ile_mid + 1;
               $postData['ile_upday'] = date('Y-m-d H:i:s');
               $postData['ile_inday'] = date('Y-m-d H:i:s');
                $id_user = $this->EbayIle->save(false,$postData);
                if($id_user){

                    $result = ['status' => true,'message'=>'Add Ile success !','id'=>$newId];
                     $this->set_response($result, REST_Controller::HTTP_CREATED); // CREATED (201) being the HTTP response code
                }else{
                    $result = ['status' => false];
                    $this->set_response($result, REST_Controller::HTTP_BAD_REQUEST);
                }
            }
        }else{
            $result = ['status' => false];
           $this->set_response($result, REST_Controller::HTTP_BAD_REQUEST);
        }

        }else {

         
          if(!empty($this->post()) ){
            //Functions::pre($this->input->post());
            // $id_ile      = $this->input->post('ile_mid');
             $id_ile = $this->get('id');
            if(empty($id_ile)){

            $result = ['status' => false];
            $this->set_response($result, REST_Controller::HTTP_BAD_REQUEST);
              die();
            }
             $dlday          = (int)$this->post('dlday');
                 unset($_POST['dlday']);
                 if($dlday == 0){
                  
                    $unremoveData['ile_dlday'] = null;
                     //echo (int)$id_ile;
                         $id_ile = $this->EbayIle->save($id_ile,$unremoveData);
                        if($id_ile){
                            $result = ['status' => true,'message'=>'Undelete ile success !'];
                            $this->set_response($result, REST_Controller::HTTP_OK);
                        }else{
                            $result = ['status' => false,'message'=>'Undelete Error'];
                          $this->set_response($result, REST_Controller::HTTP_BAD_REQUEST);
                        }
                 }


             $this->form_validation->set_rules('ile_vch0', 'user_name', 'required|min_length[6]');
             $this->form_validation->set_rules('ile_vch1', 'itemID', 'required');
              $this->form_validation->set_rules('ile_int1', 'eby_mid', 'integer');

             if ($this->form_validation->run() == FALSE)
            {
                $this->form_validation->set_error_delimiters('<div class="dat_error">', '</div>');

                foreach ($this->input->post() as $key=>$item) {
                   if (form_error($key)) {
                        $result = ['status' => false, 'message' => form_error($key),'field'=>$key];
                        $this->set_response($result, REST_Controller::HTTP_BAD_REQUEST);
                    }
                }
            } else{ 

            $postWhere['ile_mid'] = $id_ile;
            $dataJson = $this->EbayIle->getRow($postWhere);

            if(!$dataJson){
                $result = [
                    'status' => false,
                    'message'=> 'USER is invalid'
                ];
                $this->set_response($result, REST_Controller::HTTP_BAD_REQUEST);
            }

                $this->load->library('bcrypt');
                 $postData = $this->input->post();
                 $postData['ile_upday'] = date('Y-m-d H:i:s');
                 $dlday          = (int)$this->post('dlday');
                 if($dlday == 0){
                    $postData['ile_dlday'] = null;
                 }
              
                unset($postData['type']);
                //echo (int)$id_ile;
                $id_user = $this->EbayIle->save($id_ile,$postData);
                if($id_user){
                    $result = ['status' => true,'message'=>'Edit Ile success !'];
                    $this->set_response($result, REST_Controller::HTTP_OK);
                }else{
                    $result = ['status' => false,'message'=>'Edit Error'];
                  $this->set_response($result, REST_Controller::HTTP_BAD_REQUEST);
                }
            }
            

        }else{
            $result = ['status' => false];
           $this->set_response($result, REST_Controller::HTTP_BAD_REQUEST);
        }
            

        
        }
    }




    public function iles_delete()
    {
        $id = $this->get('id');
        if(empty($id)){
             $message = ["status"=>false,"message"=>'Dont Have any ID'];
         $this->set_response($message, REST_Controller::HTTP_BAD_REQUEST); 

        }
        // $this->so
        // me_model->delete_something($id);
        $this->EbayIle->deleteItem($id);
        $message = ["status"=>true,"message"=>'Deleted Ile'];
        $this->set_response($message, REST_Controller::HTTP_OK); // NO_CONTENT (204) being the HTTP response code
    }

}
