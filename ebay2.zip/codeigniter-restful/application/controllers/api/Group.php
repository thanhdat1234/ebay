<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * This is an example of a few basic grp interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * 
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Group extends MY_Controller{

    public function __construct()
    {
        parent:: __construct();
    }

    protected $methods = [
        'routerFunction_post' => ['level' => 1,'limit' => 100],
        'routerFunction_get' => ['level' => 1,'limit' => 100],
    ];

    /*==================================
    |Router function post
    |===================================
    */
    public function routerFunction_post()
    {
        $call_function = $this->head($this->config->item('x_api_callname'));
        switch ($call_function) {
            case 'getLoginToken':
                $this->_getLoginToken();
                break;
            default :
                $this->response([
                    $this->config->item('action_name')=>$this->config->item('action_fail'),
                    $this->config->item('error_short_message') => $this->lang->line('text_miss_param'),
                    $this->config->item('error_name') => [
                        'error'=>[
                            $this->config->item('param_name')           =>  $this->config->item('x_api_callname'),
                            $this->config->item('error_long_message')   =>  $this->lang->line('text_rest_invalid_call_name')
                        ]
                    ]
                ], REST_Controller::HTTP_NOT_FOUND);
                break;
        }
    }

    /*==================================
    |Router function get
    |===================================
    */
    public function routerFunction_get()
    {
        $call_function = $this->head($this->config->item('x_api_callname'));

        switch ($call_function) {
            case 'getGroups':
                $this->_checkAccessToken();
                $this->_getGroups();
                break;
            case 'getGroup':
                $this->_checkAccessToken();
                $this->_getUser();
                break;

            default:
                $this->response([
                    $this->config->item('action_name')=>$this->config->item('action_fail'),
                    $this->config->item('error_short_message') => $this->lang->line('text_miss_param'),
                    $this->config->item('error_name') => [
                        'error'=>[
                            $this->config->item('param_name')           =>  $this->config->item('x_api_callname'),
                            $this->config->item('error_long_message')   =>  $this->lang->line('text_rest_invalid_call_name')
                        ]
                    ]
                ], REST_Controller::HTTP_NOT_FOUND);
                break;
        }
    }

    public function addGroup()
    {
        $this->response([
            'status' => 1,
            'message' => 'No Group were found'
        ], REST_Controller::HTTP_OK);
    }

    /*============================================
    | This function check account and regist access key and return.
    |============================================*/
    public function _getLoginToken()
    {
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');

        $this->form_validation->set_rules('user_name', 'Username', 'required|min_length[4]');
        $this->form_validation->set_rules('user_pass', 'Password', 'required|min_length[6]');
        if ($this->form_validation->run() == FALSE) {

            $error = null;
            if(form_error('user_name')) {
                $error['error'][] = [
                    $this->config->item('param_name')           =>  'user_name',
                    $this->config->item('error_long_message')   =>  form_error('user_name')
                ];
            }

            if(form_error('user_pass')) {
                $error['error'][] = [
                    $this->config->item('param_name')           =>  'user_pass',
                    $this->config->item('error_long_message')   =>  form_error('user_pass')
                ];
            }

            $this->response([
                $this->config->item('action_name')=>$this->config->item('action_fail'),
                $this->config->item('error_short_message') => $this->lang->line('text_short_message_user'),
                $this->config->item('error_name') => $error
            ], REST_Controller::HTTP_BAD_REQUEST);

        } else {

            $this->load->model('user');
            $data['user_id'] = (string)$this->input->post('user_name');
            $data['password'] = $this->_hashPassword((string)$this->input->post('user_pass'));
            $user = $this->user->getRow($data);

            if(!$user) {
                $this->response([
                    $this->config->item('action_name')=>$this->config->item('action_fail'),
                    $this->config->item('error_short_message') => $this->lang->line('text_short_message_user'),
                    $this->config->item('error_name') => [
                        'error'=>[
                            $this->config->item('error_long_message')   =>  $this->lang->line('text_long_message_user')
                        ]
                    ]
                ], REST_Controller::HTTP_BAD_REQUEST);
            }

            if($user) {
                $this->load->model('Keys');
                $data = null;
                $data['user_mid']   = $user->mid;
                $data['user_id']    = $user->user_id;
                $data['expire']     = 7200;
                if($this->config->item('token_expire_value')) {
                    $data['expire']     = $this->config->item('token_expire_value');
                }
                $token = $this->key->createKey(1,$data,1);

                if(!$token) {
                    $this->response([
                        $this->config->item('action_name')=>$this->config->item('action_fail'),
                        $this->config->item('error_short_message') => $this->lang->line('text_short_message_key'),
                        $this->config->item('error_name') => [
                            'error'=>[
                                $this->config->item('error_long_message')   =>  $this->lang->line('text_long_message_key')
                            ]
                        ]
                    ], REST_Controller::HTTP_BAD_REQUEST);
                }

                if($token) {
                    unset($user->updated_at);
                    unset($user->deleted_at);
                    unset($user->token);
                    unset($user->password);
                    $this->response([
                        $this->config->item('action_name')=>$this->config->item('action_success'),
                        $this->config->item('user_data_return') => [
                            'userResponse'                              => $user,
                            $this->config->item('token_name')           =>  $token,
                            $this->config->item('token_expire_name')    =>  $data['expire'],
                        ]
                    ], REST_Controller::HTTP_OK);
                }
            }

            $this->response([
                $this->config->item('action_name')=>$this->config->item('action_fail'),
                $this->config->item('error_name') => 'No users were found',
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    /*============================================
    | This function get list user
    |============================================*/
    public function _getGroups()
    {
        $this->load->model('groups');
        $where = [
            'deleted_at'=>null
        ];
        $data = $this->groups->getList($limit = false,$page = false,$where = NUll);

        if(!$data) {
            $this->response([
                $this->config->item('action_name') => $this->config->item('action_fail'),
                $this->config->item('error_short_message') => $this->lang->line('text_short_message_data'),
                $this->config->item('error_name') => [
                    'error'=>[
                        $this->config->item('error_long_message') => $this->lang->line('text_long_message_data')
                    ]
                ]
            ], REST_Controller::HTTP_BAD_REQUEST);
        }

        $this->response([
            $this->config->item('action_name')=>$this->config->item('action_success'),
            $this->config->item('group_list_data_return') => [
                'Items' => $data,
            ]
        ], REST_Controller::HTTP_OK);

    }

}
