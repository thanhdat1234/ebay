<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 *
 * @author	    :	Nguyen Thanh Dat
 * @copyright   :   PHP TEAM
 * @since	    :	Version 1.0
 * @intro       :   tb_ebc is table stored all category from Ebay. It have Site ID so
 *
 */
class Ebc2s extends MY_Model
{
    public $table   = 'tb_ebc2';
    public $key     = 'ebc_mid';
    protected $_field = [
        'c_mid'                 => 'ebc_mid',
        'c_categoryID'          => 'ebc_int0',
        'c_categoryLevel'       => 'ebc_int1',
        'c_categoryName'        => 'ebc_vch0',
        'c_siteID'              => 'ebc_int3',
        'c_upTime'              => 'ebc_upTime',
        'c_categoryParentID'    => 'ebc_int2',
        'c_bestOfferEnabled'    => 'ebc_dat1',
        'c_autoPayEnabled'      => 'ebc_dat2',
        'c_leafCategory'        => 'ebc_dat3',
        'c_inday'               => 'ebc_inday',
        'c_upday'               => 'ebc_upday',
        'c_dlday'               =>'ebc_dlday'
    ];
    protected $_deleted_day     = '';
    protected $_created_day     = '';
    protected $_update_day      = '';

    public function __construct()
    {
        parent:: __construct();
        $this->_setParameter(0);
    }
    /**
     * @Intro : This function is set parameter .
     */
    public function _setParameter($param){
        $this->_deleted_day = $this->_created_day = $this->_update_day = date('Y-m-d H:i:s');
    }
    /**
     * @Intro : This function is add new data to database
     */
    public function addRowData($data){
        if(!$data == true || is_array($data) == false || $data == null){
            return false;
        }
        if(!empty($data[$this->key])){
            unset($data[$this->key]);
        }
        $data[$this->_field['c_inday']] = $this->_created_day;
        $data[$this->_field['c_upday']] = null;
        $data[$this->_field['c_dlday']] = null;
        $data[$this->_field['c_mid']]   = $this->getMaxID();
        try{
            $id = $this->save(false,$data);
            if(!$id) {
                $result['flash'] = 0;
                return $result;
            }
            return $id;
        }catch (Exception $exception){
            $result['message']  = $exception->getMessage();
            $result['flash']    = 0;
            return $result;
        }
    }
    public function updateDatas($data,$mid){
        if(!$data == true || is_array($data) == false || $data == null){
            return false;
        }
        if(!empty($data[$this->key])){
            unset($data[$this->key]);
        }
        $data[$this->_field['c_upday']] = $this->_update_day;
        $data[$this->_field['c_dlday']] = null;
        try{
            $id = $this->save($mid,$data);
            if(!$id) {
                $result['flash'] = 0;
                return $result;
            }
            return $id;
        }catch (Exception $exception){
            $result['message']  = $exception->getMessage();
            $result['flash']    = 0;
            return $result;
        }
    }
    public function getRow($data){
        $data = $this->find_by($data,'*',true,null,null,null);
        return $data;
    }
    public function getList($limit = false,$page = false,$where = NUll){
        $start = 0;
        $data = $this->find_by($where,'*',false,null,null,null);
        if(!$limit){
            return $data;
        }
        $total_item = count($data);
        if(!$limit){
            $limit = 10;
        }
        if(!$page){
            $page = 1;
        }
        /*$start =*/
        (int)$total_page = ceil((int)$total_item/(int)$limit);
        $start = ($page - 1) * $limit;
        $dataz['data']           = $this->find_by($where,'*',false,null,(int)$limit,(int)$start);
        $dataz['total_page']     = (int)$total_page;
        $dataz['total_item']     = (int)$total_item;
        $dataz['current_page']   = (int)$page;
        $dataz['limit']          = (int)$limit;
        $dataz['start']          = (int)$start;
        return $dataz;
    }
    public function getListAndJoinLang($where = false){
        $this->db->select('*');
        $this->db->from('tb_ebc');
        $this->db->join('tb_dic', 'tb_ebc.ebc_vch0 = tb_dic.dic_vch1');
        $this->db->group_by('tb_ebc.ebc_vch0');
        if($where) {
            $this->db->where($where);
        }
        $query = $this->db->get();
        //echo $this->db->last_query();
        $data = $query->result();
        return $data;
        //pre($data);
    }

    public function getSearch($like,$where,$limit = false,$page = false){
        $start = 0;
        //$where = [];
        $data = $this->find_like($like,$where,'*',false,null,null,null);
        $total_item = count($data);
        if(!$limit){
            $limit = 10;
        }
        if(!$page){
            $page = 1;
        }
        /*$start =*/
        (int)$total_page = ceil((int)$total_item/(int)$limit);
        $start = ($page - 1) * $limit;
        $dataz['data']           = $this->find_like($like,$where,'*',false,null,(int)$limit,(int)$start);
        $dataz['total_page']     = (int)$total_page;
        $dataz['total_item']     = (int)$total_item;
        $dataz['current_page']   = (int)$page;
        $dataz['limit']          = (int)$limit;
        $dataz['start']          = (int)$start;
        return $dataz;
    }
    /**
     * @Intro : This is function physical delete, It delete all categories . *Note : DELETE ALL STORED CATEGORIES FROM DATABASE.
     */
    public function deleteAllCategory($where = false){
        if($where){
            if($this->db->where($where)->delete($this->table)){
                return TRUE;
            }else{
                return FALSE;
            }
        }else{
            if($this->db->empty_table($this->table)){
                return TRUE;
            }else{
                return FALSE;
            }
        }
    }
    /**
     *@Intro: This is function make mapping path category
     */
    public function getArrayCategory($level = false,$where = false){
        if(!$level){
            $level = 1;
        }
        if(!$where){
            $where = ['ebc_int1'=>$level];
            $data = $this->getListAndJoinLang($where);
        }else{
            $data = $this->getListAndJoinLang($where);
        }
        if($data){
            //$category['category'] = $data;
            $i=0;
            if($level == 1){
                $level = 2;
            }else{
                $level = $level + 1;
            }
            foreach ($data as $item){
                $wherez = [
                    'ebc_int1'=>$level,
                    'ebc_int2'=>$item->ebc_int0,
                ];

                $category[$i]           = (array)$item;
                $arr_child              = $this->getListAndJoinLang($wherez);
                $data_child             = $this->getChildCategory($arr_child);
                $category[$i]['child']  = (array)$data_child;
                $i++;
            }
            return $category;
        }else{
            return false;
        }
    }
    public function getChildCategory($arr = false,$data = false){
        if($arr){
            $category = $data;
            $i=0;
            foreach ($arr as $item){
                $wherez = [
                    'ebc_int1'=>$item->ebc_int1 + 1,
                    'ebc_int2'=>$item->ebc_int0,
                ];
                $zdata                  = $this->getListAndJoinLang($wherez);
                $category[$i]           = (array)$item;
                if(count($zdata) > 0){
                    $category[$i]['child']  = (array)$this->getChildCategory($zdata);
                }
                $i++;
            }
            return $category;
        }else{
            return false;
        }
    }
    /**
     *@Intro: This is function make mapping path category
     */
    public function buidPathCategory($arr,$path = false){
        //return;
        //$data = $this->getArrayCategory();
        //pre($arr);
        $i=0;
        $pathz[$i] = '';
        //$pathz[$i] = '';
        $path_arr = null;
        if(!$arr){
            return false;
        }else{
            foreach ($arr as $item){
                $pathz = $item['dic_vch2'];
                if(!empty($item['child'])){
                    $pathz = $this->buidTextCategory($item['child'],$pathz);
                    //return $pathz;
                }
                $path_arr[$item['ebc_vch0']][] = $pathz;

                //echo $pathz;
                //echo "<br> =-==============================<br> <hr>";
            }
            return $path_arr;
        }
    }
    public function buidTextCategory($arr,$path = false){
        //pre($arr);
        $pathx = [];
        $pathxx = $path;

        foreach ($arr as $item) {
            //pre($item);
            $pathxx = $path . '::' . $item['dic_vch2'];
            if (!empty($item['child'])) {
                $pathxz = $this->buidTextCategory($item['child'], $pathxx);
                $pathx = array_merge($pathx,$pathxz);
            }else{
                $pathx[] = $pathxx;
            }
        }
        return $pathx;
    }
}