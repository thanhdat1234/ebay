<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 *
 * @author		Nguyen Thanh Dat
 * @copyright   PHP TEAM
 * @since		Version 1.0
 *
 */
class Users extends MY_Model
{
    public $table = 'tb_usr';
    public $key = 'usr_mid';

    public function __construct()
    {
        parent:: __construct();
    }

    public function getRow($data){
        $data = $this->find_by($data,'*',true,null,null,null);
        //echo $this->db->last_query();
        return $data;
    }
    public function getList($limit = false,$page = false,$where = NUll){
        $start = 0;
        $data = $this->find_by($where,'*',false,null,null,null);
        $total_item = count($data);
        if(!$limit){
            $limit = 10;
        }
        if(!$page){
            $page = 1;
        }
        /*$start =*/
        (int)$total_page = ceil((int)$total_item/(int)$limit);
        $start = ($page - 1) * $limit;
        $dataz['data']           = $this->find_by($where,'*',false,null,(int)$limit,(int)$start);
        $dataz['total_page']     = (int)$total_page;
        $dataz['total_item']     = (int)$total_item;
        $dataz['current_page']   = (int)$page;
        $dataz['limit']          = (int)$limit;
        $dataz['start']          = (int)$start;
        return $dataz;
    }

    public function getSearch($like,$where,$limit = false,$page = false){
        $start = 0;
        //$where = [];
        $data = $this->find_like($like,$where,'*',false,null,null,null);
        $total_item = count($data);
        if(!$limit){
            $limit = 10;
        }
        if(!$page){
            $page = 1;
        }
        /*$start =*/
        (int)$total_page = ceil((int)$total_item/(int)$limit);
        $start = ($page - 1) * $limit;
        $dataz['data']           = $this->find_like($like,$where,'*',false,null,(int)$limit,(int)$start);
        $dataz['total_page']     = (int)$total_page;
        $dataz['total_item']     = (int)$total_item;
        $dataz['current_page']   = (int)$page;
        $dataz['limit']          = (int)$limit;
        $dataz['start']          = (int)$start;
        return $dataz;
    }
    public function deleteItem($id_user){
        /*check user empty*/
        $user = $this->find_by($where = ['usr_mid'=>(int)$id_user],'*',true,null,null,null);
        $data = ['usr_dlday'=>date('Y-m-d H:i:s')];
        $user_id = $this->save((int)$id_user,$data);
        if($user_id){
            return true;
        }


    }

}