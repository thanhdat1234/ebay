<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 *
 * @author		Phạm Minh Cảnh
 * @copyright   PHP TEAM
 * @since		Version 1.0
 *
 */
class Usas extends MY_Model
{
    public $table = 'tb_usa';
    public $key = 'usa_mid';

    public function __construct()
    {
        parent:: __construct();
    }

    public function getRow($data)
    {
        $data = $this->find_by($data,'*',true,null,null,null);
        //echo $this->db->last_query();
        return $data;
    }

    public function getMaxId()
    {
        $maxid = 0;
        $row = $this->db->query('SELECT MAX(usa_mid) AS `usa_mid` FROM `tb_usa`')->row();

        if ($row) {
            $maxid = $row->usa_mid; 
        }

        return $maxid;
    }

    public function getList($limit = false,$page = false,$where = NUll)
    {
        $start = 0;
        //todo: join table
        //$data = $this->find_by($where,'*',false,null,null,null);

        $this->db->select('*');
        
        $this->db->from('tb_usa a');

        $this->db->join('tb_grp g', 'a.usa_int1 = g.grp_mid', 'left');

        $this->db->join('tb_usr u', 'a.usa_int0 = u.usr_mid', 'left');

        if(!$limit) {
            $limit = 10;
        }

        if(!$page) {
            $page = 1;
        }

        $this->db->limit($limit, $start);

        $this->db->where($where);

        $data = $this->db->get();
        
        $data = $data->result_array();
                
        $total_item = count($data);

        /*$start =*/
        (int)$total_page = ceil((int)$total_item/(int)$limit);
        $start = ($page - 1) * $limit;

        //$dataz['data']           = $this->find_by($where,'*',false,null,(int)$limit,(int)$start);
        $dataz['data']           = $data;

        $dataz['total_page']     = (int)$total_page;
        $dataz['total_item']     = (int)$total_item;
        $dataz['current_page']   = (int)$page;
        $dataz['limit']          = (int)$limit;
        $dataz['start']          = (int)$start;
        return $dataz;
    }

    public function search($like,$where,$limit = false,$page = false)
    {
        $start = 0;
        //$where = [];
        $data = $this->find_like($like,$where,'*',false,null,null,null);
        $total_item = count($data);

        if(!$limit) {
            $limit = 10;
        }

        if(!$page) {
            $page = 1;
        }

        /*$start =*/
        (int)$total_page = ceil((int)$total_item/(int)$limit);
        $start = ($page - 1) * $limit;
        $dataz['data']           = $this->find_like($like,$where,'*',false,null,(int)$limit,(int)$start);
        $dataz['total_page']     = (int)$total_page;
        $dataz['total_item']     = (int)$total_item;
        $dataz['current_page']   = (int)$page;
        $dataz['limit']          = (int)$limit;
        $dataz['start']          = (int)$start;
        return $dataz;
    }

    public function deleteItem($id_usa)
    {
        /*check user empty*/
        $usa = $this->find_by($where = ['usa_mid'=>(int)$id_usa],'*',true,null,null,null);

        $data = ['usa_dlday'=>date('Y-m-d H:i:s')];

        $usa_id = $this->save((int)$id_usa,$data);

        if($usa_id) {
            return true;
        }
    }
    /**
     * @Intro : This function will return menu id in tb_grp
     */
    public $grp         = 'tb_grp';
    public $grp_mid     = 'grp_mid';
    public $usr         = 'tb_usr';
    public $usr_mid     = 'usr_mid';
    public $usa_int1    = 'usa_int1';
    public function joinGroupUser($id_user){
        $this->load->database();
        $query = $this->db->select('*')
            ->from($this->grp)
            ->join($this->table,$this->table.'.'.$this->usa_int1.'='.$this->grp.'.'.$this->grp_mid)->where($this->table.'.usa_int0',$id_user)
            ->get();
        $data = $query->row();
        //echo $this->db->last_query();
        if(!$data){
            return false;
        }
        return $data;
    }

    public function addItem($data)
    {
        return $this->db->insert($this->table, $data);
    }

}