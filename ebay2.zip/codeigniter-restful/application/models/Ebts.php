<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 *
 * @author	    :	Nguyen Thanh Dat
 * @copyright   :   PHP TEAM
 * @since	    :	Version 1.0
 * @intro       :   tb_ebt is table save history get token from ebay :application token ;user token
 *
 */
class Ebts extends MY_Model
{
    public $table = 'Ebts';
    public $key = 'id';
    protected $_field = [
        'mid'           => 'id',
        'a_token'       => 'access_token',
        't_type'        => 'token_type',
        'e_in'          => 'expires_in',
        'r_token'       => 'refresh_token',
        'c_day'         => 'created_day',
        'u_day'         => 'update_day',
        'd_day'         =>'deleted_day'
    ];
    protected $_deleted_day     = '';
    protected $_created_day     = '';
    protected $_update_day      = '';

    public function __construct()
    {
        parent:: __construct();
        $this->_setParameter(0);
    }
    /*====================================
     * This function is set parameter .
     */
    public function _setParameter($param){
        $this->_deleted_day = $this->_created_day = $this->_update_day = date('Y-m-d H:i:s');
    }
    /*=====================================
     * This function is add new data to database
     */
    public function addRowData($data){
        if(!$data == true || is_array($data) == false || $data == null){
            return false;
        }
        if(!empty($data[$this->key])){
            unset($data[$this->key]);
        }
        $data[$this->_field['c_day']] = $this->_created_day;
        $data[$this->_field['u_day']] = null;
        $data[$this->_field['d_day']] = null;
        try{
            $id = $this->save(false,$data);
            if(!$id) {
                $result['flash'] = false;
                return $result;
            }
            return $id;
        }catch (Exception $exception){
            $result['message']  = $exception->getMessage();
            $result['flash']    = false;
            return $result;
        }
    }
    public function updateData($data){

    }
    public function getRow($data){
        $data = $this->find_by($data,'*',true,null,null,null);
        return $data;
    }
    public function getList($limit = false,$page = false,$where = NUll){
        $start = 0;
        $data = $this->find_by($where,'*',false,null,null,null);
        $total_item = count($data);
        if(!$limit){
            $limit = 10;
        }
        if(!$page){
            $page = 1;
        }
        /*$start =*/
        (int)$total_page = ceil((int)$total_item/(int)$limit);
        $start = ($page - 1) * $limit;
        $dataz['data']           = $this->find_by($where,'*',false,null,(int)$limit,(int)$start);
        $dataz['total_page']     = (int)$total_page;
        $dataz['total_item']     = (int)$total_item;
        $dataz['current_page']   = (int)$page;
        $dataz['limit']          = (int)$limit;
        $dataz['start']          = (int)$start;
        return $dataz;
    }

    public function getSearch($like,$where,$limit = false,$page = false){
        $start = 0;
        //$where = [];
        $data = $this->find_like($like,$where,'*',false,null,null,null);
        $total_item = count($data);
        if(!$limit){
            $limit = 10;
        }
        if(!$page){
            $page = 1;
        }
        /*$start =*/
        (int)$total_page = ceil((int)$total_item/(int)$limit);
        $start = ($page - 1) * $limit;
        $dataz['data']           = $this->find_like($like,$where,'*',false,null,(int)$limit,(int)$start);
        $dataz['total_page']     = (int)$total_page;
        $dataz['total_item']     = (int)$total_item;
        $dataz['current_page']   = (int)$page;
        $dataz['limit']          = (int)$limit;
        $dataz['start']          = (int)$start;
        return $dataz;
    }
    public function deleteItem($id_user){
        /*check user empty*/
        $user = $this->find_by($where = ['ebc_mid'=>$id_user],'*',true,null,null,null);
        $data = ['ebc_dlday'=>date('Y-m-d H:i:s')];
        $user_id = $this->save($id_user,$data);
        if($user_id){
            return true;
        }
    }
    public function GetCatelogy(){
        $AppID = 'ShumaTak-Allgrowo-PRD-9b7edec1b-0ba9587d'; //YOUR EBAY APP ID
        $CertID = 'PRD-b7edec1bbf10-a4ca-4b8c-97d9-0386'; //YOUR EBAY CERT ID
        $RUNAME = 'Shuma_Takeda-ShumaTak-Allgro-yywyufkw'; //YOUR EBAY RUNAME
        $url = "https://api.ebay.com/ws/api.dll";

        $headers = [
            'Content-Type: application/xml',
            'X-EBAY-API-DEV-NAME: ' . $CertID,
            'X-EBAY-API-APP-NAME: ' . $AppID,
            'X-EBAY-API-SITEID: 0',
            'X-EBAY-API-COMPATIBILITY-LEVEL:967',
            'X-EBAY-API-CALL-NAME:GetCategories',
        ];
        $body = '<?xml version="1.0" encoding="utf-8"?>
        <GetCategoriesRequest xmlns="urn:ebay:apis:eBLBaseComponents">
          <RequesterCredentials>
            <eBayAuthToken>AgAAAA**AQAAAA**aAAAAA**lwRvWQ**nY+sHZ2PrBmdj6wVnY+sEZ2PrA2dj6AHmYuoCpOHqAydj6x9nY+seQ**1sIDAA**AAMAAA**lN0D9p//S2LtdjMLeNiFVmu6Yt4EJ225XPHA4tiOcCiCP0P0qhT43CEtu7BFK4Cfwc1XAlJLaEirwmhfLwwGfYOBNQJ6fd9qOdjW9G4B1f6rDpVhOYtL3QF85AFcauigmukapqH35WwwiS95j681Xsp9rEl8ZkgeI0VsGxc6U1Oq6+kdETiRifAYXC2XBMBTJLTyBglNKxDapD/g6pow3uSXe0ljOR60zuzkt+m/1xdK9ZAj3NDPec2L/leJhh93J0I8pytauiv0CcO07qwVl8kU9OxVKeUfTFSB7gXu1jqZrZ7KaRN6iB80ERO/W5oLKCKlQRpYZAQCdqnjM64OTdvxZawTkSETpnrgphzW8Vq1rnAM6nO5Yehm0gq+TNRGywFgRCqETSJxue9PmXd6Rf3PXvSSSHu9LYEXzb+KZUjCEaTQhsFKhJnyJBOks/dnf+QzxfTDRmlO5VW5+7Gb1dnHUPSVjXDJycP6euRnrPLsBY+vR6scd6oBqHnwyKlYEIhBQkOvKvmrMm8eA+1fGR/klcoN8svdD4CRPHI/vcn/FSeViCPtmbR2S/RHchFFbGkWXCX1T5TV0+3dFYxuGnJ/pB+CHF0sCW7bAirIa6Jcd3SLJ7hy/Yfojb3wlMTapWW8JKT73aAhjDCurckPiALGYd02CAfeMuX6nTawCvGhLD/fxbo3F7EYrMBuEFR5Vh5lblR8SSCcGv8OkRNQW/b2gpmTVl2EoejUqWwNsdCEy10zVkIuThIMCa0/OgCa</eBayAuthToken>
          </RequesterCredentials>
            <ErrorLanguage>en_US</ErrorLanguage>
            <WarningLevel>High</WarningLevel>
             <!--Ensure that site ID, in the Header, is set to the site you want-->
          <DetailLevel>ReturnAll</DetailLevel>
          <ViewAllNodes>true</ViewAllNodes>
        </GetCategoriesRequest> ';
        $curl = curl_init();
        //echo $url;
        curl_setopt_array($curl, array(
            CURLOPT_URL            => $url,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_POSTFIELDS     => $body,
            CURLOPT_RETURNTRANSFER => true,
            //CURLOPT_CUSTOMREQUEST  => 'POST',
            CURLOPT_POST        => true,
            CURLOPT_SSL_VERIFYPEER =>0,
            CURLOPT_SSL_VERIFYHOST =>0
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        $cate_xml = new SimpleXMLElement($response);
        $num        = $cate_xml->CategoryCount;
        $num_test   = count($cate_xml->CategoryArray->Category);
        //pre($cate_xml);
        if(!empty($cate_xml->Ack) && $cate_xml->Ack == "Success"){
            $total = 0;
            for ($i=0;$i< $num;$i++){
                $postData = [];
                $category = $cate_xml->CategoryArray->Category[$i];
                $category = json_decode(json_encode($category,true));
                $id = (int)$this->getMaxID()->ebc_mid ;
                $postData['ebc_mid'] = $id == 0 ? 1000001:$id+1;
                $postData['ebc_int0'] = $category->CategoryID;
                $postData['ebc_int1'] = $category->CategoryLevel;
                $postData['ebc_vch0'] = $category->CategoryName;
                $postData['ebc_int2'] = $category->CategoryParentID;
                $postData['ebc_inday'] =  date('Y-m-d H:i:s');
                $postData['ebc_upday'] =  date('Y-m-d H:i:s');
                if(!empty($category->BestOfferEnabled) && $category->BestOfferEnabled == true) {
                    $postData['ebc_dat1'] = 1;
                }
                if(!empty($category->AutoPayEnabled) && $category->AutoPayEnabled == true) {
                    $postData['ebc_dat2'] = 1;
                }
                if(!empty($category->LeafCategory) && $category->LeafCategory == true) {
                    $postData['ebc_dat3'] = 1;
                }

                $check = $this->getRow(['ebc_int0'=>$category->CategoryID]);
                if(empty($check)){
                      $id_user = $this->save(false,$postData);
                      $total += 1;
                }


            }
            return $total;
        }
        return 0;
    }

}