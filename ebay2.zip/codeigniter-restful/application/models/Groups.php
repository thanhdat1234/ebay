<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 *
 * @author		Phạm Minh Cảnh
 * @copyright   PHP TEAM
 * @since		Version 1.0
 *
 */
class Groups extends MY_Model
{
    public $table = 'tb_grp';
    public $key = 'grp_mid';

    public function __construct()
    {
        parent:: __construct();
    }

    //can use for getting group by ID
    public function getRow($data)
    {
        $data = $this->find_by($data,'*',true,null,null,null);
        //echo $this->db->last_query();
        return $data;
    }

    public function getList($limit = false,$page = false,$where = NUll)
    {
        $start = 0;
        
        $data = $this->find_by($where,'*',false,null,null,null);
        $total_item = count($data);

        if(!$limit) {
            $limit = 10;
        }

        if(!$page) {
            $page = 1;
        }
        
        /*$start =*/
        (int)$total_page = ceil((int)$total_item/(int)$limit);
        $start = ($page - 1) * $limit;

        $dataz['data']           = $this->find_by($where,'*',false,null,(int)$limit,(int)$start);

        $dataz['total_page']     = (int)$total_page;
        $dataz['total_item']     = (int)$total_item;
        $dataz['current_page']   = (int)$page;
        $dataz['limit']          = (int)$limit;
        $dataz['start']          = (int)$start;

        return $dataz;
    }

    public function search($like,$where,$limit = false,$page = false)
    {
        $start = 0;
        //$where = [];
        $data = $this->find_like($like,$where,'*',false,null,null,null);
        $total_item = count($data);

        if(!$limit) {
            $limit = 10;
        }

        if(!$page) {
            $page = 1;
        }

        /*$start =*/
        (int)$total_page = ceil((int)$total_item/(int)$limit);
        $start = ($page - 1) * $limit;
        $dataz['data']           = $this->find_like($like,$where,'*',false,null,(int)$limit,(int)$start);
        $dataz['total_page']     = (int)$total_page;
        $dataz['total_item']     = (int)$total_item;
        $dataz['current_page']   = (int)$page;
        $dataz['limit']          = (int)$limit;
        $dataz['start']          = (int)$start;

        return $dataz;
    }

    public function deleteItem($id_group)
    {
        /*check user empty*/
        $group = $this->find_by($where = ['grp_mid'=>(int)$id_group],'*',true,null,null,null);

        $data = ['grp_dlday'=>date('Y-m-d H:i:s')];

        $group_id = $this->save((int)$id_group,$data);

        if($group_id) {
            return true;
        }
    }

    public function editItem($data)
    {
        $group_id = $this->save($data['grp_mid'], $data);

        if ($group_id) {
            return true;
        }
    }

}