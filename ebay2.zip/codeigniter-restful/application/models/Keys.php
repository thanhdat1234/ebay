<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 *
 * @author		Nguyen Thanh Dat
 * @copyright   PHP TEAM
 * @since		Version 1.0
 *
 */
class Keys extends MY_Model{
    public $table       = 'keys';
    public $key         = 'id';
    public $key_token   = 'key';

    public function createKey($level = false,$user_info = false,$ignore_limits = false)
    {
        // Build a new key
        $key = $this->_generate_key();
        if(!$user_info['user_id']){
            return false;
        }
        if(!$user_info['user_mid']){
            return false;
        }
        if(empty($user_info['expire']) || $user_info['expire'] == ''){
            $expire = 7200;
        }else{
            $expire = $user_info['expire'];
        }
        // If no key level provided, provide a generic key
        $level = $level?$level:1;
        $ignore_limits = $ignore_limits?$ignore_limits:1;
        // Insert the new key
        $data = [
                    'level' => $level,
                    'ignore_limits' => $ignore_limits,
                    'user_id'=>$user_info['user_id'],
                    'user_mid'=>$user_info['user_mid'],
                    'expire'=>$expire,
                ];
        if ($this->_insert_key($key, $data))
        {
            return $key;
        }
        else
        {
            return false;
        }
    }
    public function checkTimeKey($user_token){
        $isset_key = $this->_key_exists($user_token);
        if($isset_key<1){
            return false;
        }
        $info_key = $this->_get_key($user_token);
        /*checkTime*/
        $time_now       = time();
        $unix_date      = $info_key->date_created;
        $time_check     = (int)$time_now - (int)$unix_date;
        if($time_check <= (int)$info_key->expire){
            return true;
        }else{
            $this->_delete_key($user_token);
            return false;
        }
    }

    private function _get_key($key)
    {
        return $this->db
            ->where($this->key_token, $key)
            ->get($this->table)
            ->row();
    }

    private function _generate_key()
    {
        do
        {
            // Generate a random salt
            $salt = base_convert(bin2hex($this->security->get_random_bytes(128)), 16, 36);

            // If an error occurred, then fall back to the previous method
            if ($salt === FALSE)
            {
                $salt = hash('sha256', time() . mt_rand());
            }

            $new_key = substr($salt, 0, config_item('rest_key_length'));
        }
        while ($this->_key_exists($new_key));

        return $new_key;
    }
    private function _key_exists($key)
    {
        return $this->db
                ->where($this->key_token, $key)
                ->count_all_results($this->table) > 0;
    }

    private function _insert_key($key, $data)
    {
        $data[$this->key_token] = $key;
        $data['date_created'] = function_exists('now') ? now() : time();

        return $this->db
            ->set($data)
            ->insert($this->table);
    }

    private function _update_key($key, $data)
    {
        return $this->db
            ->where($this->key_token, $key)
            ->update($this->table, $data);
    }

    private function _delete_key($key)
    {
        return $this->db
            ->where($this->key_token, $key)
            ->delete($this->table);
    }
    public function getUserIDFromAccessKey($token_key){
        $data = $this->_get_key($token_key);
        return $data;
    }

}