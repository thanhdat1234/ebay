<?php defined('BASEPATH') OR exit('No direct script access allowed');
require __DIR__.'/vendor/autoload.php';
use \DTS\eBaySDK\Constants;
use \DTS\eBaySDK\Trading\Services;
use \DTS\eBaySDK\Trading\Types;
use \DTS\eBaySDK\Trading\Enums;
use \DTS\eBaySDK\Ebaysdk\Ebay;
use \DTS\eBaySDK\Sdk;


Class Account extends Ebay
{
    protected $_service = '';
    protected $head     = '';
    protected $body     = '';
    public function __construct()
    {
        parent::__construct();
    }
/**
*@Auth: Nguyen Thanh Dat
*@mail: thanhdat@allgrow-labo.jp
*@Intro: Begin All function for Fulfillment policy
*/
/*1.Get Fulfillment*/
    public function getFulfillmentPolicy($header,$body){
        $data = null;
        return $data;
    }
/*2. Create Fulfillment*/
    public function createFulfillment($head,$body){
        $data = null;
        if($data){
            return true;
        }else{
            return false;
        }
    }
/*3. Delete Fulfillment*/
    public function deleteFulfillment($head,$body){
        $data = null;
        if($data){
            return true;
        }else{
            return false;
        }
    }
/*4.Update a Fulfillment*/
    public function updateFulfillment($head,$body){
        $data = null;
        if($data){
            return true;
        }else{
            return false;
        }
    }
/**
*@Auth: Nguyen Thanh Dat
*@mail: thanhdat@allgrow-labo.jp
*@Intro: Begin All function for Payment policy
*/
    /*1.Get Payment*/
    public function getPaymentPolicy($header,$body){
        $data = null;
        return $data;
    }
    /*2. Create Payment*/
    public function createPayment($head,$body){
        $data = null;
        if($data){
            return true;
        }else{
            return false;
        }
    }
    /*3. Delete Payment*/
    public function deletePayment($head,$body){
        $data = null;
        if($data){
            return true;
        }else{
            return false;
        }
    }
    /*4.Update a Payment*/
    public function updatePayment($head,$body){
        $data = null;
        if($data){
            return true;
        }else{
            return false;
        }
    }
/**
*@Auth: Nguyen Thanh Dat
*@mail: thanhdat@allgrow-labo.jp
*@Intro: Begin All function for Return policy
*/
    /*1.Get Return*/
    public function getReturnPolicy($header,$body){
        $data = null;
        return $data;
    }
    /*2. Create Return*/
    public function createReturn($head,$body){
        $data = null;
        if($data){
            return true;
        }else{
            return false;
        }
    }
    /*3. Delete Return*/
    public function deleteReturn($head,$body){
        $data = null;
        if($data){
            return true;
        }else{
            return false;
        }
    }
    /*4.Update a Return*/
    public function updateReturn($head,$body){
        $data = null;
        if($data){
            return true;
        }else{
            return false;
        }
    }


}

?>