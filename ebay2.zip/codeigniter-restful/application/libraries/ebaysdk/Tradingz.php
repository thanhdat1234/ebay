<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: thanhdat
 * Date: 02/11/2017
 * Time: 14:47
 */
require __DIR__.'/vendor/autoload.php';
use \DTS\eBaySDK\Constants;
use \DTS\eBaySDK\Trading\Services;
use \DTS\eBaySDK\Trading\Types;
use \DTS\eBaySDK\Trading\Enums;
use \DTS\eBaySDK\Ebaysdk\Ebay;
use \DTS\eBaySDK\Sdk;
use \DTS\eBaySDK\FileTransfer;
use \DTS\eBaySDK\Trading;

class Tradingz extends Ebay
{
    protected $_devId           = '00551562-49cc-4e3e-b50b-356badb5ea73';
    protected $_appId           = 'ShumaTak-Allgrowo-PRD-9b7edec1b-0ba9587d';
    protected $_certId          = 'PRD-b7edec1bbf10-a4ca-4b8c-97d9-0386';
    protected $_authToken       = 'AgAAAA**AQAAAA**aAAAAA**pcb6WQ**nY+sHZ2PrBmdj6wVnY+sEZ2PrA2dj6AHmYuoCpOHqAydj6x9nY+seQ**qNADAA**AAMAAA**vFe+aNK8gwpvK4vX91B7gkOtN9mE8XjlpclPfGptr/6cnJ++fv6je2x+yo/5/YsRdHAL9TcoDFHs9fUBoxHx+HLSXMMvqH6obH8r0nmUwNiZcHA9zxJO8UwQHkZhb2iHuz7jf3mJPAGGlIsi1yghQhNYhRvgP3+AXd3bA8jN/qit6PyUFyucEHfNyCRwAUa7B/blDc8R645Hqs5l4jEiw/FqyVF3UI4tdaSscUDy9xLYpxTZUzIa4aOsZNtrW47KBf9v+xOOHsbhUDaUE0zBLmtRUJQcMW5YeP5z4cNeBswkDISEemAzas4m5wXQN6JD0RyXCB8ZNkcMLCWswCxt/prlBrDEKlf65RmaPCKsatncMkWx9+2kyiit7wsIg0tm6h1m9wPngPiMb/aPR7Wb3FvrLuWqtWY6NZyvY24Qhg1NPtE06aPFcKbZHPPinery42qrqGy0Sp+vdQmp9EDjuDFfKihoM4pJds6PTzM0WHqwro2BsefN/KwO1KNSTV1DK9RVYT5ejoXQM29OlAank0r1pLxosbMQ2s1PrLMG3tbWVKj9ZiwT9d4eDawv5HRTxfh7S8hQmqo/Cg5pN29vQ2o/9F8/RVOodpv4fdXTMwUH04sPXKSng1uzUf+dyMXWXGbk1fpmq7lW8idd/95YkBVQp1L5Hh9p5e4ZrBO6xHNxssb4QdZms3ZQ0eZsDihY0r8Pn1zMxUZ4T6QGkrblCJz5AowY+9qKaHuGoBa6la2Yiu6S0AiAuNEJWNfHawQ9';

    protected $_product         = null;
    protected $_sanbox          = null;
    public function __construct()
    {
        parent::__construct();
    }
/*alpha b */
/*
 * A================================
*/
    public function addItems(){
        /**
         * Specify the numerical site id that we want the listing to appear on.
         *
         * This determines the validation rules that eBay will apply to the request.
         * For example, it will determine what categories can be specified, the values
         * allowed as shipping services, the visibility of the item in some searches and other
         * information.
         *
         * Note that due to the risk of listing fees been raised this example will list the item
         * to the sandbox site.
         */
        $siteId = Constants\SiteIds::US;

        /**
         * Create the service object.
         */
        $service = new Services\TradingService([
            'credentials' => $config['sandbox']['credentials'],
            'sandbox'     => true,
            'siteId'      => $siteId
        ]);

        /**
         * Create the request object.
         */
        $request = new Types\AddItemsRequestType();

        /**
         * An user token is required when using the Trading service.
         */
        $request->RequesterCredentials = new Types\CustomSecurityHeaderType();
        $request->RequesterCredentials->eBayAuthToken = $config['sandbox']['authToken'];

        /**
         * Begin creating the fixed price item.
         */
        $item = new Types\ItemType();

        /**
         * The item that will be listed is the audiobook of a well known novel.
         */
        $item->Title = "Harry Potter and the Philosopher's Stone";
        $item->Description = 'Audiobook of the wizard novel';

        /**
         * Since the item is an audio book list in the Books > Audiobooks (29792) category.
         */
        $item->PrimaryCategory = new Types\CategoryType();
        $item->PrimaryCategory->CategoryID = '29792';

        /**
         * Item specifics describe the aspects of the item and are specified using a name-value pair system.
         * For example:
         *
         *  Color=Red
         *  Size=Small
         *  Gemstone=Amber
         *
         * The names and values that are available will depend upon the category the item is listed in.
         * Before specifying your item specifics you would normally call GetCategorySpecifics to get
         * a list of names and values that are recommended by eBay.
         * Showing how to do this is beyond the scope of this example but it can be assumed that
         * a call has previously been made and the following names and values were returned.
         *
         * Subject=Fiction & Literature
         * Topic=Fantasy
         * Format=MP3 CD
         * Length=Unabridged
         * Language=English
         *
         * In addition to the names and values that eBay has recommended this item will list with
         * its own custom item specifics.
         *
         * Bit rate=320 kbit/s
         * Narrated by=Stephen Fry
         *
         * Note that some categories allow multiple values to be specified for each name.
         * This example will only use one value per name.
         */
        $item->ItemSpecifics = new Types\NameValueListArrayType();

        $specific = new Types\NameValueListType();
        $specific->Name = 'Subject';
        $specific->Value[] = 'Fiction & Literature';
        $item->ItemSpecifics->NameValueList[] = $specific;

        /**
         * This shows an alternative way of adding a specific.
         */
        $item->ItemSpecifics->NameValueList[] = new Types\NameValueListType([
            'Name' => 'Topic',
            'Value' => ['Fantasy']
        ]);

        $specific = new Types\NameValueListType();
        $specific->Name = 'Format';
        $specific->Value[] = 'MP3 CD';
        $item->ItemSpecifics->NameValueList[] = $specific;

        $specific = new Types\NameValueListType();
        $specific->Name = 'Length';
        $specific->Value[] = 'Unabrided';
        $item->ItemSpecifics->NameValueList[] = $specific;

        $specific = new Types\NameValueListType();
        $specific->Name = 'Language';
        $specific->Value[] = 'English';
        $item->ItemSpecifics->NameValueList[] = $specific;

        /**
         * Add the two custom item specifics.
         * Notice they are no different to eBay recommended item specifics.
         */
        $specific = new Types\NameValueListType();
        $specific->Name = 'Bit rate';
        $specific->Value[] = '320 kbit/s';
        $item->ItemSpecifics->NameValueList[] = $specific;

        $specific = new Types\NameValueListType();
        $specific->Name = 'Narrated by';
        $specific->Value[] = 'Stephen Fry';
        $item->ItemSpecifics->NameValueList[] = $specific;

        /**
         * Provide enough information so that the item is listed.
         * It is beyond the scope of this example to go into any detail.
         */
        $item->ListingType = Enums\ListingTypeCodeType::C_FIXED_PRICE_ITEM;
        $item->Quantity = 99;
        $item->ListingDuration = Enums\ListingDurationCodeType::C_GTC;
        $item->StartPrice = new Types\AmountType(['value' => 19.99]);
        $item->Country = 'US';
        $item->Location = 'Beverly Hills';
        $item->Currency = 'USD';
        $item->ConditionID = 1000;
        $item->PaymentMethods[] = 'PayPal';
        $item->PayPalEmailAddress = 'example@example.com';
        $item->DispatchTimeMax = 1;
        $item->ShipToLocations[] = 'None';
        $item->ReturnPolicy = new Types\ReturnPolicyType();
        $item->ReturnPolicy->ReturnsAcceptedOption = 'ReturnsNotAccepted';

        $container = new Types\AddItemRequestContainerType();
        $container->MessageID = '123';
        $container->Item = $item;

        /**
         * Finish the request object.
         */
        $request->AddItemRequestContainer[] = $container;

        /**
         * Send the request.
         */
        $response = $service->addItems($request);

        /**
         * Output the result of calling the service operation.
         */
        if (isset($response->Errors)) {
            foreach ($response->Errors as $error) {
                printf(
                    "%s: %s\n%s\n\n",
                    $error->SeverityCode === Enums\SeverityCodeType::C_ERROR ? 'Error' : 'Warning',
                    $error->ShortMessage,
                    $error->LongMessage
                );
            }
        }

        if ($response->Ack !== 'Failure') {
            foreach ($response->AddItemResponseContainer as $container) {
                if (isset($container->Errors)) {
                    foreach ($container->Errors as $error) {
                        printf(
                            "%s: %s\n%s\n\n",
                            $error->SeverityCode === Enums\SeverityCodeType::C_ERROR ? 'Error' : 'Warning',
                            $error->ShortMessage,
                            $error->LongMessage
                        );
                    }
                }

                if ($response->Ack !== 'Failure') {
                    printf(
                        "The item was listed to the eBay Sandbox with the Item number %s\n",
                        $container->ItemID
                    );
                }
            }
        }

    }
/*
 * C================================
 */
/*
 * D================================
 */
/*
 * E================================
 *
 */
    public function endItem(){
        /**
         * Create the service object.
         */
        $service = new Services\TradingService([
            'credentials' => $config['sandbox']['credentials'],
            'sandbox'     => true,
            'siteId'      => Constants\SiteIds::US
        ]);

        /**
         * Create the request object.
         */
        $request = new Types\EndItemRequestType();

        /**
         * An user token is required when using the Trading service.
         */
        $request->RequesterCredentials = new Types\CustomSecurityHeaderType();
        $request->RequesterCredentials->eBayAuthToken = $config['sandbox']['authToken'];

        /**
         * Tell eBay which item we are ending.
         */
        $request->ItemID = '1234567890';

        /**
         * Give a reason as to why.
         */
        $request->EndingReason = Enums\EndReasonCodeType::C_NOT_AVAILABLE;


        /**
         * Send the request.
         */
        $response = $service->endItem($request);

        /**
         * Output the result of calling the service operation.
         */
        if (isset($response->Errors)) {
            foreach ($response->Errors as $error) {
                printf(
                    "%s: %s\n%s\n\n",
                    $error->SeverityCode === Enums\SeverityCodeType::C_ERROR ? 'Error' : 'Warning',
                    $error->ShortMessage,
                    $error->LongMessage
                );
            }
        }

        if ($response->Ack !== 'Failure') {
            printf("The item was ended at: %s\n", $response->EndTime->format('H:i (\G\M\T) \o\n l jS F Y'));
        }
    }
    public function endItems(){
        $service = new Services\TradingService([
            'credentials' => $config['sandbox']['credentials'],
            'sandbox'     => true,
            'siteId'      => Constants\SiteIds::US
        ]);

        /**
         * Create the request object.
         */
        $request = new Types\EndItemsRequestType();

        /**
         * An user token is required when using the Trading service.
         */
        $request->RequesterCredentials = new Types\CustomSecurityHeaderType();
        $request->RequesterCredentials->eBayAuthToken = $config['sandbox']['authToken'];

        /**
         * Tell eBay which items we are ending and why.
         */
        $endItem = new Types\EndItemRequestContainerType();
        $endItem->MessageID = '1ABC';
        $endItem->ItemID = '1111111111';
        $endItem->EndingReason = Enums\EndReasonCodeType::C_NOT_AVAILABLE;
        $request->EndItemRequestContainer[] = $endItem;

        $endItem = new Types\EndItemRequestContainerType();
        $endItem->MessageID = '2DEF';
        $endItem->ItemID = '2222222222';
        $endItem->EndingReason = Enums\EndReasonCodeType::C_INCORRECT;
        $request->EndItemRequestContainer[] = $endItem;

        $endItem = new Types\EndItemRequestContainerType();
        $endItem->MessageID = '3GHI';
        $endItem->ItemID = '3333333333';
        $endItem->EndingReason = Enums\EndReasonCodeType::C_LOST_OR_BROKEN;
        $request->EndItemRequestContainer[] = $endItem;

        /**
         * Send the request.
         */
        $response = $service->endItems($request);

        /**
         * Output the result of calling the service operation.
         */
        if (isset($response->Errors)) {
            foreach ($response->Errors as $error) {
                printf(
                    "%s: %s\n%s\n\n",
                    $error->SeverityCode === Enums\SeverityCodeType::C_ERROR ? 'Error' : 'Warning',
                    $error->ShortMessage,
                    $error->LongMessage
                );
            }
        }

        foreach ($response->EndItemResponseContainer as $endItem) {
            if (isset($endItem->Errors)) {
                foreach ($endItem->Errors as $error) {
                    printf(
                        "[%s] %s: %s\n%s\n\n",
                        $endItem->CorrelationID,
                        $error->SeverityCode === Enums\SeverityCodeType::C_ERROR ? 'Error' : 'Warning',
                        $error->ShortMessage,
                        $error->LongMessage
                    );
                }
            } else {
                printf("[%s] The item was ended at: %s\n", $endItem->EndTime->format('H:i (\G\M\T) \o\n l jS F Y'));
            }
        }
    }
/*
 * F================================
 *
 */
/*
 * G================================
 *
 */
    public function getCategories($siteID = false,$limit_level = false){
        $service = new Services\TradingService([
            'credentials' => $this->_product['credentials'],
            'siteId'      => $siteID
        ]);

        /*'credentials' => $config['production']['credentials'],*/

        /**
         * Create the request object.
         */
        $request = new Types\GetCategoriesRequestType();

        /**
         * An user token is required when using the Trading service.
         */
        $request->RequesterCredentials = new Types\CustomSecurityHeaderType();
        $request->RequesterCredentials->eBayAuthToken = $this->_product['authToken'];

        /**
         * By specifying 'ReturnAll' we are telling the API return the full category hierarchy.
         * List DetailLevel
         * 1 : ItemReturnAttributes
         * 2 : ItemReturnCategories
         * 3 : ItemReturnDescription
         * 4 : ReturnAll
         * 5 : ReturnHeaders
         * 6 : ReturnMessages
         * 7 : ReturnSummary
         */
        $request->DetailLevel = ['ReturnAll'];
        if($limit_level){
            $request->LevelLimit = $limit_level;
        }

        /**
         * OutputSelector can be used to reduce the amount of data returned by the API.
         * http://developer.ebay.com/DevZone/XML/docs/Reference/ebay/GetCategories.html#Request.OutputSelector
         */
        /*$request->OutputSelector = [
            'CategoryArray.Category.CategoryID',
            'CategoryArray.Category.CategoryParentID',
            'CategoryArray.Category.CategoryLevel',
            'CategoryArray.Category.CategoryName'
        ];*/
        /**
         * Send the request.
         */
        $response = $service->getCategories($request);

        /**
         * Output the result of calling the service operation.
         */
        if (isset($response->Errors)) {
            $result['status'] = false;
            $result['error']  = $response->Errors;
            return $result;
        }

        if ($response->Ack !== 'Failure') {
            $data = json_decode($response,true);
            return $data;
            /*echo "<pre>";
            print_r($data);
            echo "</pre>";*/
        }
    }
    public function getUpdateTimeCategories($siteID = false){
        $service = new Services\TradingService([
            'credentials' => $this->_product['credentials'],
            'siteId'      => $siteID
        ]);
        /**
         * Create the request object.
         */
        $request = new Types\GetCategoriesRequestType();

        /**
         * An user token is required when using the Trading service.
         */
        $request->RequesterCredentials = new Types\CustomSecurityHeaderType();
        $request->RequesterCredentials->eBayAuthToken = $this->_product['authToken'];

        /**
         * By specifying 'ReturnAll' we are telling the API return the full category hierarchy.
         * List DetailLevel
         * 1 : ItemReturnAttributes
         * 2 : ItemReturnCategories
         * 3 : ItemReturnDescription
         * 4 : ReturnAll
         * 5 : ReturnHeaders
         * 6 : ReturnMessages
         * 7 : ReturnSummary
         */
        $request->DetailLevel = ['ReturnHeaders'];
        $response = $service->getCategories($request);
        if (isset($response->Errors)) {
            $result['status'] = false;
            $result['error']  = $response->Errors;
            return $result;
        }
        if ($response->Ack !== 'Failure') {
            $data = json_decode($response,true);
            return $data;
        }
    }
    public function getCategorySpecifics(){
        $siteId = Constants\SiteIds::US;
        $sdk = new Sdk([
            'credentials' => $config['production']['credentials'],
            'authToken'   => $config['production']['authToken'],
            'siteId'      => $siteId
        ]);

        /**
         * Create the service object.
         */
        $service = $sdk->createTrading();

        /**
         * Create the request object.
         */
        $request = new Trading\Types\GetCategorySpecificsRequestType();

        /**
         * Request the FileReferenceID and TaskReferenceID from eBay.
         */
        $request->CategorySpecificsFileInfo = true;

        /**
         * Send the request.
         */
        $response = $service->getCategorySpecifics($request);

        /**
         * Output the result of calling the service operation.
         */
        if (isset($response->Errors)) {
            foreach ($response->Errors as $error) {
                printf(
                    "%s: %s\n%s\n\n",
                    $error->SeverityCode === Trading\Enums\SeverityCodeType::C_ERROR ? 'Error' : 'Warning',
                    $error->ShortMessage,
                    $error->LongMessage
                );
            }
        }

        if ($response->Ack !== 'Failure') {
            /**
             * Get the values that will be passed to the File Transfer service.
             */
            $fileReferenceId = $response->FileReferenceID;
            $taskReferenceId = $response->TaskReferenceID;

            printf(
                "FileReferenceID [%s] TaskReferenceID [%s]\n",
                $fileReferenceId,
                $taskReferenceId
            );

            print("Downloading file...\n");

            $service = $sdk->createFileTransfer();

            $request = new FileTransfer\Types\DownloadFileRequest();

            $request->fileReferenceId = $fileReferenceId;
            $request->taskReferenceId = $taskReferenceId;

            $response = $service->downloadFile($request);

            if (isset($response->errorMessage)) {
                foreach ($response->errorMessage->error as $error) {
                    printf(
                        "%s: %s\n\n",
                        $error->severity === FileTransfer\Enums\ErrorSeverity::C_ERROR ? 'Error' : 'Warning',
                        $error->message
                    );
                }
            }

            if ($response->ack !== 'Failure') {
                /**
                 * Check that the response has an attachment.
                 */
                if ($response->hasAttachment()) {
                    $attachment = $response->attachment();

                    /**
                     * Save the attachment to file system's temporary directory.
                     */
                    $tempFilename = tempnam(sys_get_temp_dir(), 'category-specifics-').'.zip';
                    $fp = fopen($tempFilename, 'wb');
                    if (!$fp) {
                        printf("Failed. Cannot open %s to write!\n", $tempFilename);
                    } else {
                        fwrite($fp, $attachment['data']);
                        fclose($fp);

                        printf("File downloaded to %s\nUnzip this file to obtain the category item specifics.\n\n", $tempFilename);
                    }
                } else {
                    print("Unable to locate attachment\n\n");
                }
            }
        }
    }
/*
 * I================================
 *
 */
/*
 * L================================
 *
 */
/*
 * M================================
 *
 */
/*
 * P================================
 *
 */
/*
* R================================
*
*/
    public function reviseFixedPriceItem(){
        /**
         * Create the request object.
         */
        $request = new Types\ReviseFixedPriceItemRequestType();

        /**
         * An user token is required when using the Trading service.
         */
        $request->RequesterCredentials = new Types\CustomSecurityHeaderType();
        $request->RequesterCredentials->eBayAuthToken = $config['sandbox']['authToken'];

        /**
         * Begin creating the fixed price item.
         */
        $item = new Types\ItemType();

        /**
         * Tell eBay which item we are revising.
         */
        $item->ItemID = '1234567890';

        /**
         * Remove some existing information.
         */
        $request->DeletedField[] = 'Item.SKU';

        /**
         * Change title to an audiobook of a well known novel.
         */
        $item->Title = "Harry Potter and the Philosopher's Stone";
        $item->Description = 'Audiobook of the wizard novel';

        /**
         * Change the category to Books > Audiobooks (29792) category.
         */
        $item->PrimaryCategory = new Types\CategoryType();
        $item->PrimaryCategory->CategoryID = '29792';

        /**
         * Item specifics describe the aspects of the item and are specified using a name-value pair system.
         * For example:
         *
         *  Color=Red
         *  Size=Small
         *  Gemstone=Amber
         *
         * The names and values that are available will depend upon the category the item is listed in.
         * Before specifying your item specifics you would normally call GetCategorySpecifics to get
         * a list of names and values that are recommended by eBay.
         * Showing how to do this is beyond the scope of this example but it can be assumed that
         * a call has previously been made and the following names and values were returned.
         *
         * Subject=Fiction & Literature
         * Topic=Fantasy
         * Format=MP3 CD
         * Length=Unabridged
         * Language=English
         *
         * In addition to the names and values that eBay has recommended this item will list with
         * its own custom item specifics.
         *
         * Bit rate=320 kbit/s
         * Narrated by=Stephen Fry
         *
         * Note that some categories allow multiple values to be specified for each name.
         * This example will only use one value per name.
         */
        $item->ItemSpecifics = new Types\NameValueListArrayType();

        $specific = new Types\NameValueListType();
        $specific->Name = 'Subject';
        $specific->Value[] = 'Fiction & Literature';
        $item->ItemSpecifics->NameValueList[] = $specific;

        /**
         * This shows an alternative way of adding a specific.
         */
        $item->ItemSpecifics->NameValueList[] = new Types\NameValueListType([
            'Name' => 'Topic',
            'Value' => ['Fantasy']
        ]);

        $specific = new Types\NameValueListType();
        $specific->Name = 'Format';
        $specific->Value[] = 'MP3 CD';
        $item->ItemSpecifics->NameValueList[] = $specific;

        $specific = new Types\NameValueListType();
        $specific->Name = 'Length';
        $specific->Value[] = 'Unabrided';
        $item->ItemSpecifics->NameValueList[] = $specific;

        $specific = new Types\NameValueListType();
        $specific->Name = 'Language';
        $specific->Value[] = 'English';
        $item->ItemSpecifics->NameValueList[] = $specific;

        /**
         * Add the two custom item specifics.
         * Notice they are no different to eBay recommended item specifics.
         */
        $specific = new Types\NameValueListType();
        $specific->Name = 'Bit rate';
        $specific->Value[] = '320 kbit/s';
        $item->ItemSpecifics->NameValueList[] = $specific;

        $specific = new Types\NameValueListType();
        $specific->Name = 'Narrated by';
        $specific->Value[] = 'Stephen Fry';
        $item->ItemSpecifics->NameValueList[] = $specific;

        /**
         * Finish the request object.
         */
        $request->Item = $item;

        /**
         * Send the request.
         */
        $response = $service->reviseFixedPriceItem($request);

        /**
         * Output the result of calling the service operation.
         */
        if (isset($response->Errors)) {
            foreach ($response->Errors as $error) {
                printf(
                    "%s: %s\n%s\n\n",
                    $error->SeverityCode === Enums\SeverityCodeType::C_ERROR ? 'Error' : 'Warning',
                    $error->ShortMessage,
                    $error->LongMessage
                );
            }
        }

        if ($response->Ack !== 'Failure') {
            print("The item was successfully revised on the eBay Sandbox.");
        }
    }
/*
* S================================
*
*/
/*
* U================================
*
*/
/*
* V================================
*
*/
    public function __destruct()
    {
    }
}