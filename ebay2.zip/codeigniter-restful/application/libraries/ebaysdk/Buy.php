<?php
/**
 * Created by PhpStorm.
 * User: thanhdat
 * Date: 02/11/2017
 * Time: 16:10
 */

class Buy
{

}