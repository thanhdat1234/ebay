<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: thanhdat
 * Date: 02/11/2017
 * Time: 16:09
 */
require __DIR__.'/vendor/autoload.php';
use \DTS\eBaySDK\Constants;
use \DTS\eBaySDK\Finding\Services;
use \DTS\eBaySDK\Finding\Types;
use \DTS\eBaySDK\Finding\Enums;
use \DTS\eBaySDK\Ebaysdk\Ebay;

class Finding extends Ebay
{
    protected $_CI              = null;
    protected $_product         = null;
    protected $_sanbox          = null;
    protected $_service         = null;
    /**
     * function is __construct
     * it have parameter config : 1 header
     *
     */
    public function __construct()
    {
        parent::__construct();
        $this->_setHeader();
    }
    public function _setHeader(){
        $this->_service = new Services\FindingService([
            'credentials' => $this->_product['credentials'],
            'globalId'    => Constants\GlobalIds::US
        ]);
    }
    public function findItemsByKeywords(){

        /**
         * Create the request object.
         */
        $request = new Types\FindItemsByKeywordsRequest();

        /**
         * Assign the keywords.
         */
        $request->keywords = 'Harry Potter';

        /**
         * Send the request.
         */
        $response = $this->_service->findItemsByKeywords($request);

        /**
         * Output the result of the search.
         */
        if (isset($response->errorMessage)) {
            foreach ($response->errorMessage->error as $error) {
                printf(
                    "%s: %s\n\n",
                    $error->severity=== Enums\ErrorSeverity::C_ERROR ? 'Error' : 'Warning',
                    $error->message
                );
            }
        }

        if ($response->ack !== 'Failure') {
            foreach ($response->searchResult->item as $item) {
                printf(
                    "(%s) %s: %s %.2f\n",
                    $item->itemId,
                    $item->title,
                    $item->sellingStatus->currentPrice->currencyId,
                    $item->sellingStatus->currentPrice->value
                );
            }
        }
    }
}