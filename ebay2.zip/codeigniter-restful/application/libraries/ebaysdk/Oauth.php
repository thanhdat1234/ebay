<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: thanhdat
 * Date: 02/11/2017
 * Time: 16:09
 */
require __DIR__.'/vendor/autoload.php';
/**
 * The namespaces provided by the SDK.
 */
use \DTS\eBaySDK\OAuth\Services;
use \DTS\eBaySDK\OAuth\Types;
use \DTS\eBaySDK\Ebaysdk;
class Oauth extends DTS\eBaySDK\Ebaysdk\Ebay
{
    protected $_devId           = '00551562-49cc-4e3e-b50b-356badb5ea73';
    protected $_appId           = 'ShumaTak-Allgrowo-PRD-9b7edec1b-0ba9587d';
    protected $_certId          = 'PRD-b7edec1bbf10-a4ca-4b8c-97d9-0386';
    protected $_authToken       = 'AgAAAA**AQAAAA**aAAAAA**pcb6WQ**nY+sHZ2PrBmdj6wVnY+sEZ2PrA2dj6AHmYuoCpOHqAydj6x9nY+seQ**qNADAA**AAMAAA**vFe+aNK8gwpvK4vX91B7gkOtN9mE8XjlpclPfGptr/6cnJ++fv6je2x+yo/5/YsRdHAL9TcoDFHs9fUBoxHx+HLSXMMvqH6obH8r0nmUwNiZcHA9zxJO8UwQHkZhb2iHuz7jf3mJPAGGlIsi1yghQhNYhRvgP3+AXd3bA8jN/qit6PyUFyucEHfNyCRwAUa7B/blDc8R645Hqs5l4jEiw/FqyVF3UI4tdaSscUDy9xLYpxTZUzIa4aOsZNtrW47KBf9v+xOOHsbhUDaUE0zBLmtRUJQcMW5YeP5z4cNeBswkDISEemAzas4m5wXQN6JD0RyXCB8ZNkcMLCWswCxt/prlBrDEKlf65RmaPCKsatncMkWx9+2kyiit7wsIg0tm6h1m9wPngPiMb/aPR7Wb3FvrLuWqtWY6NZyvY24Qhg1NPtE06aPFcKbZHPPinery42qrqGy0Sp+vdQmp9EDjuDFfKihoM4pJds6PTzM0WHqwro2BsefN/KwO1KNSTV1DK9RVYT5ejoXQM29OlAank0r1pLxosbMQ2s1PrLMG3tbWVKj9ZiwT9d4eDawv5HRTxfh7S8hQmqo/Cg5pN29vQ2o/9F8/RVOodpv4fdXTMwUH04sPXKSng1uzUf+dyMXWXGbk1fpmq7lW8idd/95YkBVQp1L5Hh9p5e4ZrBO6xHNxssb4QdZms3ZQ0eZsDihY0r8Pn1zMxUZ4T6QGkrblCJz5AowY+9qKaHuGoBa6la2Yiu6S0AiAuNEJWNfHawQ9';

    protected $_CI              = null;
    protected $_product         = null;
    protected $_sanbox          = null;
    protected $_service         = null;
    /**
     * function is __construct
     * it have parameter config : 1 header
     *
     */
    public function __construct()
    {
        parent::__construct();
    }
/*
 * This function is get application token.
 *
 */
    public function getAppToken(){
        $service = new Services\OAuthService([
            'credentials' => $this->_product['credentials'],
            'ruName'      => $this->_product['ruName'],
        ]);

        /**
         * Send the request.
         */
        $response = $service->getAppToken();
        /**
         * Output the result of calling the service operation.
         */
        if ($response->getStatusCode() !== 200) {
            $result['error'] =$response->error;
            $result['error_description'] =$response->error_description;
            return $result;
        } else {
            $result['access_token'] = $response->access_token;
            $result['token_type'] = $response->token_type;
            $result['expires_in'] = $response->expires_in;
            $result['refresh_token'] = $response->refresh_token;
            return $result;
        }
    }

    public function getUserToken(){
        $service = new Services\OAuthService([
            'credentials' => $this->_product['credentials'],
            'ruName'      => $this->_product['ruName'],
        ]);

        /**
         * Create the request object.
         */
        $request = new Types\GetUserTokenRestRequest();
        $request->code = '<AUTHORIZATION CODE>';

        /**
         * Send the request.
         */
        $response = $service->getUserToken($request);

        /**
         * Output the result of calling the service operation.
         */
        printf("\nStatus Code: %s\n\n", $response->getStatusCode());
        if ($response->getStatusCode() !== 200) {
            printf(
                "%s: %s\n\n",
                $response->error,
                $response->error_description
            );
        } else {
            printf(
                "%s\n%s\n%s\n%s\n\n",
                $response->access_token,
                $response->token_type,
                $response->expires_in,
                $response->refresh_token
            );
        }
    }
    public function refreshToken(){
        $service = new Services\OAuthService([
            'credentials' => $this->_product['credentials'],
            'ruName'      => $this->_product['ruName'],
            'sandbox'     => true
        ]);

        /**
         * Create the request object.
         */
        $request = new Types\RefreshUserTokenRestRequest();
        $request->refresh_token = '<REFRESH TOKEN>';
        $request->scope = [
            'https://api.ebay.com/oauth/api_scope/sell.account',
            'https://api.ebay.com/oauth/api_scope/sell.inventory'
        ];

        /**
         * Send the request.
         */
        $response = $service->refreshUserToken($request);

        /**
         * Output the result of calling the service operation.
         */
        printf("\nStatus Code: %s\n\n", $response->getStatusCode());
        if ($response->getStatusCode() !== 200) {
            printf(
                "%s: %s\n\n",
                $response->error,
                $response->error_description
            );
        } else {
            printf(
                "%s\n%s\n%s\n%s\n\n",
                $response->access_token,
                $response->token_type,
                $response->expires_in,
                $response->refresh_token
            );
        }
    }
}