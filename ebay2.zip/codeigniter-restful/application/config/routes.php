<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
| example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
| https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
| $route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
| $route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
| $route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples: my-controller/index -> my_controller/index
|   my-controller/my-method -> my_controller/my_method
*/
$route['default_controller'] = 'welcome';
$route['404_override'] = '';
$route['translate_uri_dashes'] = TRUE;
$route['setup-db'] = 'migrate';
/*
| -------------------------------------------------------------------------
| Sample REST API Routes
| -------------------------------------------------------------------------
*/
$route['api/example/users/(:num)'] = 'api/example/users/id/$1/dat/2'; // Example 4
$route['api/example/users/(:num)(\.)([a-zA-Z0-9_-]+)(.*)'] = 'api/example/users/id/$1/format/$3$4'; // Example 8
/*try*/
$route['api/test_get'] = 'research/users/id';
/*token*/
$route['api/token'] = 'api/key/index'; // Example 8

/*user*/
$route['api/usr.dll'] = 'api/user/routerFunction';

/*apiebayaccount/ebays/ 2*/


/*apiile/iles/ 3*/

/*apimse/mses/ 4*/

/*apigroup/groups/ 5*/
$route['api/group.dll'] = 'api/Group/routerFunction';
/*apiusa/usas/ 6*/
$route['api/usa.dll'] = 'api/Usa/routerFunction';
/*apiebc/ebcs/ 7*/
/*
|-------------------------------------------------------------------------
| Router for ebay
|-------------------------------------------------------------------------
*/
$route['api/eby.dll'] = 'api/EbayEby/routerFunction';
$route['api/ebc.dll'] = 'api/EbayEbc/routerFunction';
$route['api/plc.dll'] = 'api/EbayPlc/routerFunction';

/*get token user*/
$route['login-ebay/token-(:any)/eby-(:num)']   = 'ebay/EbayToken/indexToken/$1/$2';
$route['getIndexToken']   = 'ebay/EbayToken/getIndexToken';

/*
| -------------------------------------------------------------------------
| Sample test function Routes
| -------------------------------------------------------------------------
*/
$route['test-pass/(:any)'] = 'Test/index/pass/$1';
//$route['test.dll'] = 'Test/index';