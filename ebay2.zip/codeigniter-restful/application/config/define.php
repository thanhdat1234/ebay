<?php

defined('BASEPATH') OR exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| define all head request
| -------------------------------------------------------------------------
*/

$config['x_api_lang']        = 'X-AGL-API-ACCEPT-LANGUAGE'; //optional
$config['x_api_callname']    = 'X-AGL-API-USER-CALL-NAME'; //required
$config['x_api_access_key']  = 'X-AGL-API-ACCESS-KEY';//optional
$config['x_api_user_token']  = 'X-AGL-API-TOKEN-AUTHOR'; // after login is required
/*
| -------------------------------------------------------------------------
|   1.action name
|   2 value action: success:fail:warning
| -------------------------------------------------------------------------
|*/
$config['action_name']          = 'ack';
$config['action_success']       = 'success';
$config['action_fail']          = 'fail';
$config['action_warning']       = 'warning';
/*
| -------------------------------------------------------------------------
|   1.time token
|   2. token name
| -------------------------------------------------------------------------
|*/
$config['token_name']           = 'user_token';
$config['token_expire_name']    = 'expire_time';
$config['token_expire_value']   = 7200;
$config['token_protection']     = FALSE;
/*
| -------------------------------------------------------------------------
|   Define error
| -------------------------------------------------------------------------
|*/
$config['error_name']                   = 'errors';
$config['error_short_message']          = 'shortMessage';
$config['error_long_message']           = 'longMessage';
$config['error_write_log']              = false;
/*
| -------------------------------------------------------------------------
|   Define warning
| -------------------------------------------------------------------------
|*/
$config['warning_name']                   = 'warning';
$config['warning_short_message']          = 'shortMessage';
$config['warning_long_message']           = 'longMessage';
$config['warning_write_log']              = false;

/*
| -------------------------------------------------------------------------
|   Define param
| -------------------------------------------------------------------------
|*/
$config['param_name']                   = 'param';

/*
| -------------------------------------------------------------------------
|   Define data return
| -------------------------------------------------------------------------
|*/
$config['user_data_return']              = 'AccountResponse';
$config['user_list_data_return']         = 'ListUserResponse';
$config['eby_list_data_return']          = 'ListUserEbyResponse';
$config['group_list_data_return']        = 'ListGroupResponse';

$config['usa_list_data_return']          = 'ListUsaResponse';
$config['ebc_list_data_return']          = 'ListCategory';

/*note fulfillment_policy = shipping policy*/
$config['policy_id']          = ['payment_policy','fulfillment_policy','return_policy'];