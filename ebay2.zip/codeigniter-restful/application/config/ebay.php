<?php
/**
 * Created by PhpStorm.
 * User: thanhdat
 * Date: 02/11/2017
 * Time: 15:50
 */
$config['sandbox'] = [
    'credentials' => [
        'devId' => '00551562-49cc-4e3e-b50b-356badb5ea73',
        'appId' => 'ShumaTak-Allgrowo-SBX-d0f1ff760-ac9441a3',
        'certId' => 'SBX-0f1ff7608e59-61b2-473f-869f-7fe3',
    ],
    'authToken' => 'YOUR_SANDBOX_USER_TOKEN_APPLICATION_KEY',
    'oauthUserToken' => 'AgAAAA**AQAAAA**aAAAAA**bMX6WQ**nY+sHZ2PrBmdj6wVnY+sEZ2PrA2dj6wFk4GnCpCEpgqdj6x9nY+seQ**X0UEAA**AAMAAA**pQJtmbdb7jJdu2skImC/EJK4RFTdOPuAqIOjWit9dkoSZ1NhmVNTtgUciD8XpERD99bAi11qunrSR6PuSUJTEVS5PgBSe80Uo4Uofqq5SqVOkAhuw7qaY5BHr5kV6iVzfOeuBS6uRgkyiO4c5E+R8doN9T0evLFaHlbi05BBSLYZNMWysQA+sPFRADMdZzZ6BdK0l9RO13AFxkQqS0hORilA0bLVBnEkk63XyYzBV8GIZrgLIvkW6Ff+5kzHPYRcJcFn5oJ5xuuKMUtm5GhhJjlRjU54ZJMZ+q2uGy+cMZrRjYn3sZxs9K2TAfCZXQTMOl80L18monRFHsSj5HFl41EALRKfu5IAuvn/ZajfHTVr4yHWjzbOur9YCRhMaQP6ekPj9rUlX/X2BvRsFjHCQAg9/q7u1racVXbbbk6x7RCBNlCgrLcpGFyybpNGxTx7HS3yBbgFNIfNchTdRTX+eam/48jaql03Ff8+WImf/XsCDvm93gvGni6tUXcX9QXIWFuHgSJessZ9cVYGUy58/ZOJT5Uu2/zGeLEVp2GeMnqC3hTx3X1nwrmaYj/RTPxAE2KNlMQ1+g4Csl+f01+0X36NXbEOEcVUaM8GHsKc1jEedh6sdR8SnPbhgi3dyJROdUtqhN45txAsVHblgFReo2X+XrP2/jxpjjOdAddXVGSzTXTelLp0X+bBBlKphOy3c0SjDDoA9CnrfVn308oCyj6dmfoNsLOCw5YX59GNxGDRQpccUgHBCbv36Uae5lZZ',
    'ruName' => 'Shuma_Takeda-ShumaTak-Allgro-spxjb'
];
$config['production'] = [
    'credentials' => [
        'devId' => 'c17adcb3-c85c-4134-8358-017f1fac551b',
        'appId' => 'NguyenDa-NguyenTh-PRD-d134e8f72-90256627',
        'certId' => 'PRD-134e8f72af71-c888-4baa-a28e-21a1',
    ],
    'authToken' => 'AgAAAA**AQAAAA**aAAAAA**pcb6WQ**nY+sHZ2PrBmdj6wVnY+sEZ2PrA2dj6AHmYuoCpOHqAydj6x9nY+seQ**qNADAA**AAMAAA**vFe+aNK8gwpvK4vX91B7gkOtN9mE8XjlpclPfGptr/6cnJ++fv6je2x+yo/5/YsRdHAL9TcoDFHs9fUBoxHx+HLSXMMvqH6obH8r0nmUwNiZcHA9zxJO8UwQHkZhb2iHuz7jf3mJPAGGlIsi1yghQhNYhRvgP3+AXd3bA8jN/qit6PyUFyucEHfNyCRwAUa7B/blDc8R645Hqs5l4jEiw/FqyVF3UI4tdaSscUDy9xLYpxTZUzIa4aOsZNtrW47KBf9v+xOOHsbhUDaUE0zBLmtRUJQcMW5YeP5z4cNeBswkDISEemAzas4m5wXQN6JD0RyXCB8ZNkcMLCWswCxt/prlBrDEKlf65RmaPCKsatncMkWx9+2kyiit7wsIg0tm6h1m9wPngPiMb/aPR7Wb3FvrLuWqtWY6NZyvY24Qhg1NPtE06aPFcKbZHPPinery42qrqGy0Sp+vdQmp9EDjuDFfKihoM4pJds6PTzM0WHqwro2BsefN/KwO1KNSTV1DK9RVYT5ejoXQM29OlAank0r1pLxosbMQ2s1PrLMG3tbWVKj9ZiwT9d4eDawv5HRTxfh7S8hQmqo/Cg5pN29vQ2o/9F8/RVOodpv4fdXTMwUH04sPXKSng1uzUf+dyMXWXGbk1fpmq7lW8idd/95YkBVQp1L5Hh9p5e4ZrBO6xHNxssb4QdZms3ZQ0eZsDihY0r8Pn1zMxUZ4T6QGkrblCJz5AowY+9qKaHuGoBa6la2Yiu6S0AiAuNEJWNfHawQ9',
    'oauthUserToken' => 'AgAAAA**AQAAAA**aAAAAA**pcb6WQ**nY+sHZ2PrBmdj6wVnY+sEZ2PrA2dj6AHmYuoCpOHqAydj6x9nY+seQ**qNADAA**AAMAAA**vFe+aNK8gwpvK4vX91B7gkOtN9mE8XjlpclPfGptr/6cnJ++fv6je2x+yo/5/YsRdHAL9TcoDFHs9fUBoxHx+HLSXMMvqH6obH8r0nmUwNiZcHA9zxJO8UwQHkZhb2iHuz7jf3mJPAGGlIsi1yghQhNYhRvgP3+AXd3bA8jN/qit6PyUFyucEHfNyCRwAUa7B/blDc8R645Hqs5l4jEiw/FqyVF3UI4tdaSscUDy9xLYpxTZUzIa4aOsZNtrW47KBf9v+xOOHsbhUDaUE0zBLmtRUJQcMW5YeP5z4cNeBswkDISEemAzas4m5wXQN6JD0RyXCB8ZNkcMLCWswCxt/prlBrDEKlf65RmaPCKsatncMkWx9+2kyiit7wsIg0tm6h1m9wPngPiMb/aPR7Wb3FvrLuWqtWY6NZyvY24Qhg1NPtE06aPFcKbZHPPinery42qrqGy0Sp+vdQmp9EDjuDFfKihoM4pJds6PTzM0WHqwro2BsefN/KwO1KNSTV1DK9RVYT5ejoXQM29OlAank0r1pLxosbMQ2s1PrLMG3tbWVKj9ZiwT9d4eDawv5HRTxfh7S8hQmqo/Cg5pN29vQ2o/9F8/RVOodpv4fdXTMwUH04sPXKSng1uzUf+dyMXWXGbk1fpmq7lW8idd/95YkBVQp1L5Hh9p5e4ZrBO6xHNxssb4QdZms3ZQ0eZsDihY0r8Pn1zMxUZ4T6QGkrblCJz5AowY+9qKaHuGoBa6la2Yiu6S0AiAuNEJWNfHawQ9',
    'ruName' => 'Nguyen_Dat-NguyenDa-Nguyen-zevzjofyh',
    'appToken' =>  ''
];
/*$config['production'] = [
    'credentials' => [
        'devId' => '00551562-49cc-4e3e-b50b-356badb5ea73',
        'appId' => 'ShumaTak-Allgrowo-PRD-9b7edec1b-0ba9587d',
        'certId' => 'PRD-b7edec1bbf10-a4ca-4b8c-97d9-0386',
    ],
    'authToken' => 'AgAAAA**AQAAAA**aAAAAA**pcb6WQ**nY+sHZ2PrBmdj6wVnY+sEZ2PrA2dj6AHmYuoCpOHqAydj6x9nY+seQ**qNADAA**AAMAAA**vFe+aNK8gwpvK4vX91B7gkOtN9mE8XjlpclPfGptr/6cnJ++fv6je2x+yo/5/YsRdHAL9TcoDFHs9fUBoxHx+HLSXMMvqH6obH8r0nmUwNiZcHA9zxJO8UwQHkZhb2iHuz7jf3mJPAGGlIsi1yghQhNYhRvgP3+AXd3bA8jN/qit6PyUFyucEHfNyCRwAUa7B/blDc8R645Hqs5l4jEiw/FqyVF3UI4tdaSscUDy9xLYpxTZUzIa4aOsZNtrW47KBf9v+xOOHsbhUDaUE0zBLmtRUJQcMW5YeP5z4cNeBswkDISEemAzas4m5wXQN6JD0RyXCB8ZNkcMLCWswCxt/prlBrDEKlf65RmaPCKsatncMkWx9+2kyiit7wsIg0tm6h1m9wPngPiMb/aPR7Wb3FvrLuWqtWY6NZyvY24Qhg1NPtE06aPFcKbZHPPinery42qrqGy0Sp+vdQmp9EDjuDFfKihoM4pJds6PTzM0WHqwro2BsefN/KwO1KNSTV1DK9RVYT5ejoXQM29OlAank0r1pLxosbMQ2s1PrLMG3tbWVKj9ZiwT9d4eDawv5HRTxfh7S8hQmqo/Cg5pN29vQ2o/9F8/RVOodpv4fdXTMwUH04sPXKSng1uzUf+dyMXWXGbk1fpmq7lW8idd/95YkBVQp1L5Hh9p5e4ZrBO6xHNxssb4QdZms3ZQ0eZsDihY0r8Pn1zMxUZ4T6QGkrblCJz5AowY+9qKaHuGoBa6la2Yiu6S0AiAuNEJWNfHawQ9',
    'oauthUserToken' => 'AgAAAA**AQAAAA**aAAAAA**pcb6WQ**nY+sHZ2PrBmdj6wVnY+sEZ2PrA2dj6AHmYuoCpOHqAydj6x9nY+seQ**qNADAA**AAMAAA**vFe+aNK8gwpvK4vX91B7gkOtN9mE8XjlpclPfGptr/6cnJ++fv6je2x+yo/5/YsRdHAL9TcoDFHs9fUBoxHx+HLSXMMvqH6obH8r0nmUwNiZcHA9zxJO8UwQHkZhb2iHuz7jf3mJPAGGlIsi1yghQhNYhRvgP3+AXd3bA8jN/qit6PyUFyucEHfNyCRwAUa7B/blDc8R645Hqs5l4jEiw/FqyVF3UI4tdaSscUDy9xLYpxTZUzIa4aOsZNtrW47KBf9v+xOOHsbhUDaUE0zBLmtRUJQcMW5YeP5z4cNeBswkDISEemAzas4m5wXQN6JD0RyXCB8ZNkcMLCWswCxt/prlBrDEKlf65RmaPCKsatncMkWx9+2kyiit7wsIg0tm6h1m9wPngPiMb/aPR7Wb3FvrLuWqtWY6NZyvY24Qhg1NPtE06aPFcKbZHPPinery42qrqGy0Sp+vdQmp9EDjuDFfKihoM4pJds6PTzM0WHqwro2BsefN/KwO1KNSTV1DK9RVYT5ejoXQM29OlAank0r1pLxosbMQ2s1PrLMG3tbWVKj9ZiwT9d4eDawv5HRTxfh7S8hQmqo/Cg5pN29vQ2o/9F8/RVOodpv4fdXTMwUH04sPXKSng1uzUf+dyMXWXGbk1fpmq7lW8idd/95YkBVQp1L5Hh9p5e4ZrBO6xHNxssb4QdZms3ZQ0eZsDihY0r8Pn1zMxUZ4T6QGkrblCJz5AowY+9qKaHuGoBa6la2Yiu6S0AiAuNEJWNfHawQ9',
    'ruName' => 'Shuma_Takeda-ShumaTak-Allgro-yywyufkw',
    'appToken' =>  ''
];*/