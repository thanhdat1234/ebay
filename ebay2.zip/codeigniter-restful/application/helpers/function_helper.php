<?php
/**
 * @author   Nguyen Thanh Dat <thanhdat@allgrow-labo.jp>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

if(! function_exists('createKeyAccess'))
{
    function createKeyAccess($byte){
        if(!$byte)
            $byte = 128;
        $key = strtoupper(bin2hex($this->security->get_random_bytes($byte)));
        var_dump($key);
        $new_key = substr($key, 0, (int)config_item('rest_key_length') - 5);
        var_dump($new_key);
        return "$".$new_key."AA==";
    }
}

if(! function_exists('pre'))
{
    function pre($val){
        echo "<pre>";
        print_r($val);
        echo "</pre>";
    }
}