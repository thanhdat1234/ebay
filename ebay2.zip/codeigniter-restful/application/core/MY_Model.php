<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 *
 * @author		Nguyen Thanh Dat
 * @copyright   PHP TEAM
 * @since		Version 1.0
 *
 */
class MY_Model extends CI_Model{
    public $table = '';
    public $key   = '';
    public function __construct(){
        parent:: __construct();
        $this->load->database();
    }
    /*
        * This is function Insert data
    */
    public function save($id=false,$data=array()){
        if(!$id){
            $id = $this->insert($data);
            return $id;
        }
        $result = $this->update($id,$data);
        if($result){
            return $id;
        }
        return false;
    }

    public function insert($data){
        if($data != NULL){
            $daz = $this->db->insert($this->table,$data);
            //Functions::pre($this->db->get_compiled_insert());
            return $daz;
        }else{
            return FALSE;
        }
    }
    /*
        * This is function update_bath rule data
        * Variable where is an array conditions
        * example array("id" => $id)
    */
    public function update($id,$data){
        if(!$id){
            return FALSE;
        }
        $where = array();
        $where[''.$this->key.''] = $id;
        return $this->update_rule($where,$data);
    }
    /*
        * This is function update rule data
        * Variable where is an array conditions
        * example array("field" => $data)
    */
    public function update_rule($where,$data){
        if(!$where){
            return FALSE;
        }
        $this->db->where($where);
        if($this->db->update($this->table,$data)){
            return TRUE;
        }else{
            return FALSE;
        }
    }

    /*
        * This is function delete_rule data
        * Variable where is an array conditions
        * example array("where" => data)
    */
    public function delete_rule($where){
        if(!$where){
            return FALSE;
        }
        $this->db->where($where);
        if($this->db->delete($this->table)){
            return TRUE;
        }else{
            return FALSE;
        }
    }
    /*
        * This is function delete data
        * Variable where is an array conditions
        * example array("id" => $id)
    */
    public function delete($id){
        if(!$id){
            return FALSE;
        }
        if(is_numeric($id)){
            $where = array($this->key=>$id);
        }else{
            $where = ''.$this->key.' IN ('.$id.')';
        }
        return $this->delete_rule($where);
    }

    public function find_by($where = FALSE, $select = "*", $is_single_result = FALSE, $order_by = NULL, $limit = NULL,$offset = NULL) {
        $this->db->cache_off();
        $this->db->select($select);
        if ($order_by != NULL) {
            $query = $this->db->order_by($order_by['Keys'], $order_by['value']);
        }

        if($offset){
            $this->db->limit($limit,$offset);
        }else if($limit){
            $this->db->limit($limit);
        }

        if ($where != FALSE) {
            $where_values = array_values($where);
            $where_key = array_keys($where);
            if (is_array($where_values[0])) {
                $this->db->where_in($where_key[0], $where_values[0]);
                $query = $this->db->get($this->table);
            } else {
                $query = $this->db->get_where($this->table, $where);
            }
        } else {
            $query = $this->db->get($this->table);
        }
        return $is_single_result ? $query->row() : $query->result();
    }

    public function find_like($like=false,$where = FALSE, $select = "*", $is_single_result = FALSE, $order_by = NULL, $limit = NULL,$offset = NULL)
    {
        $this->db->cache_off();
        $this->db->select($select);
        if ($order_by != NULL) {
            $query = $this->db->order_by($order_by['Keys'], $order_by['value']);
        }
        if ($offset) {
            $this->db->limit($limit, $offset);
        } else if ($limit) {
            $this->db->limit($limit);
        }
        if ($like != FALSE) {
            $like_values = array_values($like);
            $like_key = array_keys($like);
            if (is_array($like_values[0])) {
                $this->db->like($like_key[0], $like_values[0]);
            } else {
                $this->db->like($like);
            }
        }

        if ($where != FALSE) {
            if (is_array($where)) {
                $where_values = array_values($where);
                $where_key = array_keys($where);
                if (is_array($where_values[0])) {
                    $this->db->where_in($where_key[0], $where_values[0]);
                    $query = $this->db->get($this->table);
                } else {
                    $query = $this->db->get_where($this->table, $where);
                }
            } else {
                $query = $this->db->get_where($this->table, $where);
            }
        } else {
            $query = $this->db->get($this->table);
        }
        //echo $this->db->last_query();
        //return;
        return $is_single_result ? $query->row() : $query->result();
    }
    public function getMaxID(){
        $this->db->select_max($this->key);
        $query = $this->db->get($this->table);
        $data =$query->row();
        if((int)$data->{$this->key} == 0){
            return 1000001;
        }
        return (int)$data->{$this->key} + 1;
    }
}
