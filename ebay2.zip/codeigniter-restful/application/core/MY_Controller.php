<?php
require APPPATH . 'libraries/REST_Controller.php';
/**
 *
 * @package		Adminpro
 * @author		Nguyễn Thành Đạt (ntdat.tb@gmail.com)
 * @copyright   PHP TEAM
 * @since		Version 1.0
 * @phone       0936070409
 *
 */
class My_controller extends REST_Controller{

    public function __construct(){
        parent:: __construct();
        $lang = $this->head($this->config->item('x_api_lang'));
        $this->_setLanguage($lang);
    }

    public function return_array_creat_file($folder,$file,$data = '')
    {
        if (!is_dir($folder)) {

            mkdir($folder);
            $fp = fopen($folder."/".$file,"wb");
            fwrite($fp,$data);
            fclose($fp);
        } else {
            $fp = fopen($folder."/".$file,"wb");
            fwrite($fp,$data);
            fclose($fp);
            
        }
    }

    public function _hashPassword($pass)
    {
        $new_pass = base64_encode(base64_encode(base64_encode($pass)));

        return '$21$'.$new_pass;
    }

    public function _dePassword($pass){
        $pass = substr($pass,4);
        $new_pass = base64_decode(base64_decode(base64_decode($pass)));
        return $new_pass;
    }

    public function _accessToken($byte = false){
        if(!$byte)
            $byte = 128;
        $key = strtoupper(bin2hex($this->security->get_random_bytes($byte)));
        var_dump($key);
        $new_key = substr($key, 0, (int)config_item('rest_key_length') - 5);
        var_dump($new_key);
        return "$".$new_key."AA==";
    }

    public function _setLanguage($lang){
        if(!$lang){
            $lang = 'english';
        }
        $this->lang->load('rest_controller_lang',$lang);
        $this->config->set_item('language', $lang);
        $this->config->set_item('rest_language', $lang);
    }
    public function _checkAccessToken()
    {
        $access_token = $this->head($this->config->item('x_api_access_key'));
        $this->load->model('keys');
        $flash = $this->keys->checkTimeKey($access_token);
        if(!$flash){
            $this->response([
                $this->config->item('action_name')=>$this->config->item('action_fail'),
                $this->config->item('error_short_message') => $this->lang->line('text_short_message_expire'),
                $this->config->item('error_name') => [
                    'error'=>[
                        $this->config->item('param_name')           =>  $this->config->item('x_api_access_key'),
                        $this->config->item('error_long_message')   =>  $this->lang->line('text_long_message_expire')
                    ]
                ]
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }
    public function checkPolicyType($policy_id){
        if(!$policy_id){
            $this->__returnBad($this->lang->line('text_long_message_param').". plc_id is required");
        }
        if(!in_array($policy_id,$this->config->item('policy_id'))){
            $this->__returnBad($this->lang->line('text_long_message_param').". plc_id is invalid, plc_id = 'payment_policy'|'fulfillment_policy'|'return_policy' ");
        }
    }
    protected function __returnBad($e){
        $this->response([
            $this->config->item('action_name')=>$this->config->item('action_fail'),
            $this->config->item('error_short_message') => $this->lang->line('text_short_message_system'),
            $this->config->item('error_name') => [
                'error'=>[
                    $this->config->item('param_name')           =>  $this->config->item('x_api_access_key'),
                    $this->config->item('error_long_message')   =>  $e
                ]
            ]
        ], REST_Controller::HTTP_NOT_FOUND);
    }
}
