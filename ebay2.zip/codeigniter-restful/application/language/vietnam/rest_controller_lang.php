<?php

/*
 * English language
 */

$lang['text_rest_invalid_api_key'] = 'Invalid API key %s'; // %s is the REST API key
$lang['text_rest_invalid_credentials'] = 'Invalid credentials';
$lang['text_rest_ip_denied'] = 'IP denied';
$lang['text_rest_ip_unauthorized'] = 'IP unauthorized';
$lang['text_rest_unauthorized'] = 'Unauthorized';
$lang['text_rest_ajax_only'] = 'Only AJAX requests are allowed';
$lang['text_rest_api_key_unauthorized'] = 'This API key does not have access to the requested controller';
$lang['text_rest_api_key_permissions'] = 'This API key does not have enough permissions';
$lang['text_rest_api_key_time_limit'] = 'This API key has reached the time limit for this method';
$lang['text_rest_ip_address_time_limit'] = 'This IP Address has reached the time limit for this method';
$lang['text_rest_unknown_method'] = 'Unknown method';
$lang['text_rest_unsupported'] = 'Unsupported protocol';
/*nguyen dat define*/
$lang['text_rest_invalid_call_name']                = 'Hàm không hợp lệ .';
$lang['text_short_message_user']                    = 'Không tìm thấy người dùng.';
$lang['text_long_message_user']                     = 'Không tìm thấy người dùng phù hợp. Sai mật khẩu hoặc tên đăng nhập.';
$lang['text_miss_param']                            = "Did not find the request.";
$lang['text_short_message_key']                    = 'Can\'t create key.';
$lang['text_long_message_key']                     = 'Server is error. So can\'t create key. Please call to admin.';
$lang['text_short_message_expire']                  = 'Invalid access key.';
$lang['text_long_message_expire']                   = 'Invalid access key.Please login or get new access key.';
$lang['text_short_message_data']                    = 'No data!';
$lang['text_long_message_data']                     = 'No data! Please add new data item.';
$lang['text_message_success_delete']                = 'Thanks you.Your action is success.';
$lang['text_short_message_param']                   = 'miss parameter!';
$lang['text_long_message_param']                    = 'miss parameter! Can\'t find parameter required.Please check parameter ! thanks you.';
$lang['text_long_message_param_item']               = 'miss parameter! Can\'t find parameter required.Please check {field} ! thanks you.';
$lang['text_short_message_system']                  = 'System not found !';
$lang['text_long_message_system_ebay']              = 'Server is error. So can\'t find request to you. Please call to admin.';
$lang['text_short_message_group']                   = 'Error system!.';
$lang['text_long_message_group']                    = 'Can\'t find User account ! please call to admin. Thanks you!';