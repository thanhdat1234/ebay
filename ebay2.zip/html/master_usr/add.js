var $token = checkLogin();

$(document).ready(function () {
    //getListData(1);
    showPage();
});

function showPage() {
    var html_content = $("#result_content").html();
    var re = new RegExp(/\<\!\-\-usr\_(.*.)\-\-\>/g, 'g');
    //paging2 = paging2.replace(re,i);
    html_content = html_content.replace(re,'');
    html_content = html_content.replace('style2','style="display:none"');
    // console.log(html_content);
    $("#result_content").html(html_content);
    functionMain();
}

function functionMain() {

    $("#button4").click(function () {
        location = "./list.html";
    });

    $("#button1").click(function () {

        var dataz = $("#myForm").serialize()+"&token="+token+"&type=insert";
        //dataz['token'] = token;

        $.ajax({
            type: "POST",
            url: base_url+"api/apiusers/users",
            data: dataz,

            success: function(data) {

                alert(data.message);
                location.reload();

            },

            error: function(data){
                var dataz = JSON.parse(data.responseText);

                if(dataz.field) {

                    $(".dat_error").remove();
                    $("#"+dataz.field).after(dataz.message);

                }
            }

        });

    });
}