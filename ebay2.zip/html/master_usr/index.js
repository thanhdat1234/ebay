// Define the `phonecatApp` module
//var $ = require('jquery');
var indexz = angular.module('indexz', []);

indexz.controller('IndexzController', function IndexzController($scope,$http) {
    console.log('ok');
  /*$http.get("test.json")
      .then( function(response) {
          $scope.item = response.data[0];
        console.log(response.data);
        console.log(response.status);
        console.log(response.headers);
        console.log(response.config);
        //$scope.o= response;
      },function (error){
        console.log(error);
        $("#tex").text('can\'t sent request !'+error.statusText);
      });*/

    $scope.list = [
    {
      name: 'Nexus S',
      snippet: 'Fast just got faster with Nexus S.'
    }, {
      name: 'Motorola XOOM™ with Wi-Fi',
      snippet: 'The Next, Next Generation tablet.'
    }, {
      name: 'MOTOROLA XOOM™',
      snippet: 'The Next, Next Generation tablet.'
    }
    ];
    $("#tex").unbind().bind('click',function () {
      //alert('ok');
      $http.get("test.json")
          .then( function(response) {
              $scope.item = response.data[0];
              console.log(response.data);
              console.log(response.status);
              console.log(response.headers);
              console.log(response.config);
              //$scope.o= response;
          },function (error){
              console.log(error);
              $("#tex").text('can\'t sent request !'+error.statusText);
          });
    });
    $.ajax({
        url: "http://remake.dev/codeigniter-restful/api/usr.dll",
        data: { signature: 1 },
        type: "POST",
        beforeSend: function(xhr){
            xhr.setRequestHeader('X-Test-Header','test-value');
            xhr.setRequestHeader('X-AGL-API-ACCEPT-LANGUAGE', 'english');
            xhr.setRequestHeader('X-AGL-API-CALL-NAME','addUser');
        },
        success: function(res) { console.log(res); }
    });
});