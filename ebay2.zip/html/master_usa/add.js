var $token = checkLogin();
if($token == false) {
    location = $app_url+"/login/index.html";
}

$(document).ready(function () {
    //checkLoginz();
    //getListData(1);
    showPage();
});

function showPage(page) {

    var html_content = $("#result_content").html();
    var re = new RegExp(/\<\!\-\-usa\_(.*.)\-\-\>/g, 'g');

    //paging2 = paging2.replace(re,i);
    html_content = html_content.replace(re,'');
    html_content = html_content.replace('style2','style="display:none"');
    // console.log(html_content);
    $("#result_content").html(html_content);

    getMaxId();
    functionMain();
}

function getMaxId() 
{
    $.ajax({
        url: $api_url+"api/usa.dll",
        type: "GET",
        dataType: "JSON",
        beforeSend: function(xhr) {
            xhr.setRequestHeader($x_api_access_key,$token);
            xhr.setRequestHeader($x_api_callname,'getMaxId');
            xhr.setRequestHeader($x_api_lang,$language);
        },

        error: function (request, error, res) {

        },

        success: function(res,status) {
            $("input[name='usa_mid']").val(parseInt(res.ListUsaResponse.Items) + 1);
        }

    });
}

function functionMain() {

    $("#button4").click(function () {
        location = "./list.html";
    });

    $("#button1").click(function () {

        alert($token);

        var dataz = $("#myForm").serialize();
        //dataz['token'] = token;
        $.ajax({

            url: $api_url+"api/usa.dll",
            data: dataz,
            type: "POST",

            dataType: "JSON",
            beforeSend: function(xhr) {

                xhr.setRequestHeader($x_api_access_key,$token);
                xhr.setRequestHeader($x_api_callname,'addUsa');
                xhr.setRequestHeader($x_api_lang,$language);

            },
            success: function(data) {

                alert(data.message);
                //location.reload();

            },

            error: function(data) {

                var dataz = JSON.parse(data.responseText);

                if(dataz.field) {
                    $(".dat_error").remove();
                    $("#"+dataz.field).after(dataz.message);
                }
                
            }

        });

    });

    /*$('button[data-act="del"]').click(function () {
        if(confirm("Are you sure ?")) {
            var parent = $(this).parent().parent('tr');
            var token = getCookie('token');
            var id = $(this).attr('data-id');
            $.post("/master_usr/delItem", {token: token, id_usr: id}, function (data, status) {
                if (status === 'success') {
                    var dataz = JSON.parse(data);
                    if (dataz.status === 1) {
                        parent.remove();
                        window.refresh('');
                    }
                }
            });
        }
    });*/
}
/*check login */

/*
function checkLoginz() {
    var token = getCookie('token');
    $.ajax({
        type:'POST',
        url:base_url+"check-login",
        data:{token:token},
        success:function(data){
            // console.log(data);
        },
        error:function(data){
            location = '/html/login/index.html';
            console.log(data.responseText);
        }
    });
}
*/
