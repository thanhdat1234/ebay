$(document).ready(function () {

var url = document.URL;
var id = url.substring(url.lastIndexOf('id=') + 3);
checkLoginz();

htmlEditFunction(id);

});
function htmlEditFunction(id_usa) {
     var token = getCookie('token');
     var html = $("#result_content").html();

     $.ajax({ type: 'GET',url: base_url+'api/apiusa/usas/'+id_usa, success: function(data){
     
        if(data){
            // console.log(data);
                    var html_show = '';
                    var items = data[0];
                
                    html2 = html;
                    for(var key in items){
                        var re = new RegExp('<!--'+key+'-->', 'g');
                        var value = items[key] ? items[key]:'';
                        var html2 = html2.replace(re,value);
                    }
                   
                    $("#result_content").html(html2);
                     if(items['usa_dlday']){
                        console.log(items['usa_dlday']);
                           mainFunctionEdit(id_usa,true);
                    }else{

                           mainFunctionEdit(id_usa,false);
                     }


                }
    }, error:function(data){
         location = "./list.html";
       
     }
});
   
 
  
}
function mainFunctionEdit(id_usa,dlday) {
      if(dlday == false){
         $('#button3').hide();
         $('#button2').show();
        }else{
          $('#button3').show();
         $('#button2').hide();
    }
    $("#button3").click(function () {

        var token = getCookie('token');
       
        //dataz['token'] = token;
        // console.log(dataz);
        $.ajax({
            type:"POST",
            url:base_url+"api/apiusa/usas/"+id_usa,
            data:{token:token,type:"update",dlday:0},
            success:function(data){
                    alert(data.message);
                    location.reload();
            },
            error:function(data){
       
                console.log(data.responseText);
                
            }


        });

    });
  
    $('#button2').click(function(){

         if(confirm("Are you sure ?")) {
            var parent = $(this).parent().parent('tr');
            var token = getCookie('token');
            let id = $('#usa_mid').val();
            $.ajax({
                type:"DELETE",
                url:base_url+"api/apiusa/usas/"+id,
                success: function(data){
                   
                        parent.remove();
                         location.reload();
                    
                }

            });
          
        }
    });

    // $("#button1").click(function () {
    //     var token = getCookie('token');
    //     var dataz = $("#myForm").serialize()+"&token="+token+"&type=update";
    //     //dataz['token'] = token;
    //     console.log(dataz);
    //     $.ajax({
    //         type:"POST",
    //         url:base_url+"api/apiusa/usas/"+id_usa,
    //         data:dataz,
    //         success:function(data){
    //                 location.reload();
    //         },
    //         error:function(data){
    //                 field = JSON.parse(data.responseText);
    //                 if(field.field){
    //                     $(".dat_error").remove();
    //                     $("#"+field.field).after(field.message);
    //                 }
                   
                
    //         }


    //     });
        
    // });
}
function checkLoginz() {
    var token = getCookie('token');
    $.ajax({
        type:'POST',
        url:base_url+"check-login",
        data:{token:token},
        success:function(data){
            // console.log(data);
        },
        error:function(data){
            location = '/html/login/index.html';
            console.log(data.responseText);
        }


    });
   
}