var $token = checkLogin();
if($token == false) {
    location = $app_url+"/login/index.html";
}

$(document).ready(function () {

    var html_paging = $(".pagination").html();
    var html_code   = $(".content_data").html();
    getListData(1);
    $("#addItem").click(function () {
        location = "../master_usr/add.html";
    });
    $('#searchKey').keyup(function() {
        var keywords    = $(this).val();
        var dlday       = $('input[name="usr_dlday"]:checked').val();
        getSearchData(1,keywords,dlday,html_code,html_paging);
    });
    $('form[name="searchForm"]').unbind().bind('submit',function() {
             var keywords    = $('#searchKey').val();
            var dlday       = $('input[name="usr_dlday"]:checked').val();
         getSearchData(1,keywords,dlday,html_code,html_paging);
    });
    $('input[type=radio][name=usr_dlday]').unbind().bind('change',function() {
        var keywords    = $('#searchKey').val();
         var dlday       = $('input[name="usr_dlday"]:checked').val();
         getSearchData(1,keywords,dlday,html_code,html_paging);
    });

});

function getListData(page) {
    $('button[name="showall"]').hide();
    var next_page = 1;
    if (page){
        next_page = page;
    }
    
    dispLoading("処理中...");
    //console.log(next_page);
    //var token = getCookie('user_token');
    var data = {limit:10,page:next_page,dlday:false};

    $.ajax({
        
        url: $api_url+"api/usa.dll",
        data: data,
        type: "GET",
        dataType: "JSON",
        beforeSend: function(xhr) {

            xhr.setRequestHeader($x_api_access_key,$token);
            xhr.setRequestHeader($x_api_callname,'getUsas');
            xhr.setRequestHeader($x_api_lang,$language);

        },
        error: function (request, error, res) {

            if(res != "Not Found") {
                console.log('fail');
            } else {
                console.log('fail');
                $.removeCookie('user_token', { path: '/' });
                location = '../login/index.html';
                location = $app_url+"/login/index.html";
            }

        },
        success: function(res,status){
            if(status == 'success'){
                if(res.ack == 'success'){
                    var html_code   = $(".content_data").html();
                    
                    var html        = '';
                    /*show data*/
                    var data = res.ListUsaResponse.Items;
                    for(var i =0;i< data.data.length;i++) {

                        var items = data.data[i];

                        var html2 = html_code;

                        if(items['usr_dlday']){
                            var re = new RegExp('{style-del}', 'g');
                            var display = "display:none;";
                            html2 =   html2.replace(re, display);
                        }

                        for(var key in items){
                            if(!items[key]){
                                continue;
                            }
                            var re = new RegExp('<!--'+key+'-->', 'g');
                            var html2 = html2.replace(re,items[key]);
                        }
                        html += html2;

                    }
                    
                    $(".content_data").html(html);
                    /*show pagination*/
                    var html_paging     = $(".pagination").html();
                    var paging          = '';
                    for(var i =1;i<= data.total_page;i++){
                        var paging2 = html_paging;
                        var re = new RegExp('{page}', 'g');
                        paging2 = paging2.replace(re,i);
                        if(data.current_page === i){
                            paging2 = paging2.replace('active_code','active');
                        }
                        paging += paging2;
                        /*<li class=""><a href="#" data-page = '{page}'>1<!--page--></a></li>*/
                    }
                    if(data.current_page < data.total_page){
                        var to = data.current_page * data.limit;
                    }else{
                        var to = data.total_item;
                    }
                    if(to == 0){
                        to = to + 1;
                    }
                    $('.pagination_text').html(data.start+' to '+ to +" item ( of "+data.total_item + ')');
                    $(".pagination").html(paging);
                    pagination(html_code,html_paging);
                    functionMain(html_code,html_paging);
                }else{
                    console.log('fail');
                }
            }else{
                console.log('fail');
            }
            removeLoading();
        }

    });
    
    /*$.post(base_url+"api/apiusers/users/", {token: token,limit:10,page:next_page,type:"listdata"}, function (data, status) {
        if(status === 'success'){

        }
    });*/

}

function pagination(html_code,html_paging){
    $('.pagination>li').click(function () {
        var page = $(this).children('a').attr('data-page');
        $(".content_data").html(html_code);
        $(".pagination").html(html_paging);
        getListData(page);
    });
}

/*search-item*/
function getSearchData(page,keywords,dlday,html_code,html_paging) {
    $('button[name="showall"]').show();
    var next_page = 1;
    if (page){
        next_page = page;
    }

    dispLoading("処理中...");
    var data = {limit:10,page:next_page,keywords:keywords,dlday:dlday};
    $.ajax({
        url: $api_url+"api/usr.dll",
        data: data,
        type: "GET",
        dataType: "JSON",
        beforeSend: function(xhr){
            xhr.setRequestHeader($x_api_access_key,$token);
            xhr.setRequestHeader($x_api_callname,'getSearchUsers');
            xhr.setRequestHeader($x_api_lang,$language);
        },
        error: function (request, error, res) {
            var error_list = arguments[0].responseJSON.errors.error;
            if(Array.isArray(error_list)){
                console.log('fail');
                /*for(var i=0;i< error_list.length;i++){
                    $("#error").append(error_list[i]['longMessage']+"<br>");
                }*/
            }else{
                console.log('fail');
                /*$("#error").append(error_list['longMessage']);*/
            }
        },
        success: function(res,status){
            if(status == 'success'){
                if(res.ack == 'success'){
                    var html        = '';
                    /*show data*/
                    var data = res.ListUserResponse.Items;
                    for(var i =0;i< data.data.length;i++){
                        var items = data.data[i];

                        var html2 = html_code;
                        if(items['usr_dlday']){
                            var re = new RegExp('{style-del}', 'g');
                            var display = "display:none;";
                            html2 =   html2.replace(re, display);
                        }
                        for(var key in items){
                            if(!items[key]){
                                continue;
                            }
                            var re = new RegExp('<!--'+key+'-->', 'g');
                            var html2 = html2.replace(re,items[key]);
                        }
                        html += html2;
                    }
                    $(".content_data").html(html);
                    /*show pagination*/
                    var paging          = '';
                    for(var i =1;i<= data.total_page;i++){
                        var paging2 = html_paging;
                        var re = new RegExp('{page}', 'g');
                        paging2 = paging2.replace(re,i);
                        if(data.current_page === i){
                            paging2 = paging2.replace('active_code','active');
                        }
                        paging += paging2;
                        /*<li class=""><a href="#" data-page = '{page}'>1<!--page--></a></li>*/
                    }
                    if(data.current_page < data.total_page){
                        var to = data.current_page * data.limit;
                    }else{
                        var to = data.total_item;
                    }
                    if(to == 0 ){
                        to = to + 1;
                    }
                    $('.pagination_text').html(data.start+' to '+ to +" item ( of "+data.total_item + ')');
                    $(".pagination").html(paging);
                    paginationSearch(html_code,html_paging,keywords,dlday);
                    functionMain(html_code,html_paging);
                }else{
                    console.log('fail');
                }
            }else{
                console.log('fail');
            }
            removeLoading();
        }

    });
}

function paginationSearch(html_code,html_paging,keywords,dlday){
    $('.pagination>li').click(function () {
        var page = $(this).children('a').attr('data-page');
        $(".content_data").html(html_code);
        $(".pagination").html(html_paging);
        getSearchData(page,keywords,dlday,html_code,html_paging);
    });
}
/*end search*/

function functionMain(html_code,html_paging) {

    $('button[name="showall"]').click(function () {
        location.reload();
    });

    $('button[data-act="del"]').click(function () {

        if(confirm("Are you sure ?")) {
            var parent = $(this).parent().parent('tr');
            var id = $(this).attr('data-id');

            dispLoading("処理中...");
            var data = {id:id};
            $.ajax({
                
                url: $api_url+"api/usa.dll",
                data: data,
                type: "DELETE",
                dataType: "JSON",
                beforeSend: function(xhr){
                    xhr.setRequestHeader($x_api_access_key,$token);
                    xhr.setRequestHeader($x_api_callname,'deleteUsa');
                    xhr.setRequestHeader($x_api_lang,$language);
                },
                error: function (request, error,res) {
                    var error_list = arguments[0].responseJSON.errors.error;
                    if(Array.isArray(error_list)){
                        console.log('fail');
                        /*for(var i=0;i< error_list.length;i++){
                            $("#error").append(error_list[i]['longMessage']+"<br>");
                        }*/
                    }else{
                        console.log('fail');
                        /*$("#error").append(error_list['longMessage']);*/
                    }
                },
                success: function(res,status){
                    if(status == 'success'){
                        if(res.ack == 'success'){
                            parent.remove();
                            location.reload();
                        }else{
                            console.log('fail');
                        }
                    }else{
                        console.log('fail');
                    }
                    removeLoading();
                }

            });

        }
    });
    /*function edit user*/
    $('button[data-act="edit"]').click(function () {
        var id = $(this).attr('data-id');
        if(id == 0) {
            return false;
        }
        window.location = 'edit.html?id='+id;
    });
    /*end function edit user*/
    /*search function*/
}


/*check login */

/*
function checkLoginz() {
    var token = getCookie('token');
    if(!token){
             location = '/html/login/index.html';
    }
    $.ajax({
        type:'POST',
        url:base_url+"check-login",
        data:{token:token},
        success:function(data){
            // console.log(data);
        },
        error:function(data){
            location = '/html/login/index.html';
            // console.log(data.responseText);
        }


    });

}
*/
