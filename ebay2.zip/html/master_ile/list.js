$(document).ready(function () {
    checkLoginz();
    var html_paging     = $(".pagination").html();
    var html_code   = $(".content_data").html();
    getListData(1);
    $("#addItem").click(function () {
        location = "../master_ile/add.html";
    });
    $('#searchKey').keyup(function() {
             var keywords    = $(this).val();
            var dlday       = $('input[name="ile_dlday"]:checked').val();
         getSearchData(1,keywords,dlday,html_code,html_paging);
    });
    $('#btn-search').click(function() {
             var keywords    = $('#searchKey').val();
            var dlday       = $('input[name="ile_dlday"]:checked').val();
         getSearchData(1,keywords,dlday,html_code,html_paging);
    });
    $('input[type=radio][name=ile_dlday]').change(function() {
        var keywords    = $('#searchKey').val();
         var dlday       = $('input[name="ile_dlday"]:checked').val();
         getSearchData(1,keywords,dlday,html_code,html_paging);
    });
   
});

function getListData(page) {
    $('button[name="showall"]').hide();
    var next_page = 1;
    if (page){
        next_page = page;
    }
    //console.log(next_page);
    dispLoading("処理中...");
    var token = getCookie('token');
    $.post(base_url+"api/apiile/iles/", {token: token,limit:30,page:next_page,type:"listdata"}, function (data, status) {
        if(status === 'success'){
            var html_code   = $(".content_data").html();
            var html        = '';
                /*show data*/
                for(var i =0;i< data.data.length;i++){
                    var items = data.data[i];
          
                    var html2 = html_code;
                     if(items['ile_dlday']){
                         var re = new RegExp('{style-del}', 'g');
                         var display = "display:none;";
                          html2 =   html2.replace(re, display);
                         
                    
                    }
                    for(var key in items){
                        if(!items[key]){
                            continue;
                        }
                    
                        var re = new RegExp('<!--'+key+'-->', 'g');
                         html2 = html2.replace(re,items[key]);
                    }
       
                   
                    html += html2;
                }
                $(".content_data").html(html);

                /*show pagination*/
                var html_paging     = $(".pagination").html();
             
                var paging          = '';
                   var temp = parseInt(page);
                
                var numberpage = temp + 5 < data.total_page ? temp+5:data.total_page;
                var start = temp - 5 >1 ? (temp -5>= 1 ? parseInt(temp-5):1 ):1;
       
                for(var i =start;i<= numberpage;i++){
                    var paging2 = html_paging;
                    var re = new RegExp('{page}', 'g');
           
                    paging2 = paging2.replace(re,i);
                    if(data.current_page === i){
                        paging2 = paging2.replace('active_code','active');
                    }
                    paging += paging2;
                    /*<li class=""><a href="#" data-page = '{page}'>1<!--page--></a></li>*/
                }
                if(data.current_page < data.total_page){
                    var to = data.current_page * data.limit;
                }else{
                    var to = data.total_item;
                }
                $('.pagination_text').html(data.start+' to '+ to +" item ( of "+data.total_item + ')');
    
                $(".pagination").html(paging);
                pagination(html_code,html_paging);
                functionMain(html_code,html_paging);

            
        }
          removeLoading();
    });
}

function pagination(html_code,html_paging){
    $('.pagination>li').click(function () {
        var page = $(this).children('a').attr('data-page');
        $(".content_data").html(html_code);
        $(".pagination").html(html_paging);
        getListData(page);

    });
}
/*search-item*/
function getSearchData(page,keywords,dlday,html_code,html_paging) {
    $('button[name="showall"]').show();
    var next_page = 1;
    if (page){
        next_page = page;
    }
        dispLoading("処理中...");
    //console.log(next_page);
    var token = getCookie('token');
    $.post(base_url+"api/apiile/iles/", {token: token,limit:30,page:next_page,keywords:keywords,dlday:dlday,type:"listdata"}, function (data, status) {
        if(status === 'success'){
            //var html_code   = $(".content_data").html();
            var html        = '';
          
            //$(".content_data").html(html);
            // console.log(html_code);
           
                /*show data*/
                for(var i =0;i< data.data.length;i++){
                    var items = data.data[i];
                    var html2 = html_code;
                    if(items['ile_dlday']){
                         var re = new RegExp('{style-del}', 'g');
                         var display = "display:none;";
                          html2 =   html2.replace(re, display);
                    
                    
                    }
                    for(var key in items){
                        if(!items[key]){
                            continue;
                        }
                        var re = new RegExp('<!--'+key+'-->', 'g');
                          html2 = html2.replace(re,items[key]);
                    }
                  
                    html += html2;

                }
                $(".content_data").html(html);

                /*show pagination*/
                //var html_paging     = $(".pagination").html();
                var paging          = '';
                  var temp = parseInt(page);
                var start = temp - 10 >1 ? temp-5:1;
                var numberpage = temp + 10 < data.total_page ? temp+5:data.total_page;
            
                current_page = '';
                for(var i =start;i<= numberpage;i++){
                    var paging2 = html_paging;
                    var re = new RegExp('{page}', 'g');
                    paging2 = paging2.replace(re,i);
                    if(data.current_page === i){
                        paging2 = paging2.replace('active_code','active');
                    }
                    paging += paging2;
                    /*<li class=""><a href="#" data-page = '{page}'>1<!--page--></a></li>*/
                }
                if(data.current_page < data.total_page){
                    var to = data.current_page * data.limit;
                }else{
                    var to = data.total_item;
                }
                $('.pagination_text').html(data.start+' to '+ to +" item ( of "+data.total_item + ')');
                $(".pagination").html(paging);
                paginationSearch(html_code,html_paging,keywords,dlday);
                functionMain(html_code,html_paging);
            }
        removeLoading();
    });
}

function paginationSearch(html_code,html_paging,keywords,dlday){
    $('.pagination>li').click(function () {
        var page = $(this).children('a').attr('data-page');
        $(".content_data").html(html_code);
        $(".pagination").html(html_paging);
        getSearchData(page,keywords,dlday,html_code,html_paging);
    });
}
/*end search*/
function functionMain(html_code,html_paging) {
    $('button[name="showall"]').click(function () {
        location.reload();
    });
    $('button[data-act="del"]').click(function () {
        if(confirm("Are you sure ?")) {
            var parent = $(this).parent().parent('tr');
            var token = getCookie('token');
            var id = $(this).attr('data-id');
            $.ajax({
                type:"DELETE",
                url:base_url+"api/apiile/iles/"+id,
                success: function(data){
                    
                        parent.remove();
                        location.reload();
                    
                }

            });
          
        }
    });
    /*function edit user*/
    $('button[data-act="edit"]').click(function () {
        var id = $(this).attr('data-id');
        if(id == 0) {
            return false;
        }

        /*show html*/
        $.get('./add.html',function (data) {
            var out_html = $($.parseHTML(data));//parse
            //console.log(out_html);
            var html_content  = out_html.filter('.container-fluid').children('.row-fluid').children('#result_content');//this #menu1 is in menu.html
            var re = new RegExp(/\<\!\-\-ile\_(.*.)\-\-\>/g, 'g');
            /*html_content = html_content.replace(re,'');
            html_content = html_content.replace('style2','style="display:none"');*/
            //console.log(html_content);
            $("#result_content").html(html_content);
            htmlEditFunction(id);

        });
    });
    /*end function edit user*/
    /*search function*/
}

/*edit function run after*/
function htmlEditFunction(id_ile) {
    var token = getCookie('token');
    var html = $("#result_content").html();
     $.ajax({ type: 'GET',url: base_url+'api/apiile/iles/'+id_ile, success: function(data){
     
        if(data){
                    var html_show = '';
                    var items = data;
                
                    html2 = html;
                    for(var key in items){
                        var html2 = html2.replace('<!--ile_vch1-->','');

                        var re = new RegExp('<!--'+key+'-->', 'g');
                        var html2 = html2.replace(re,items[key]);
                       

                    }
                   
                    $("#result_content").html(html2);
                     if(items['ile_dlday']){
                        console.log(items['ile_dlday']);
                           mainFunctionEdit(id_ile,true);
                    }else{

                           mainFunctionEdit(id_ile,false);
                     }


                }
    },
    error:function(data){
         location = "./list.html";
    }
    });
    // $.get(base_url+'api/apiile/iles/'+id_ile,function(data,status){
    //     if (status === 'success') {
  
           
    //         if (data.status === 1) {
    //             if(data){
    //                 var html_show = '';
    //                 var items = data;
    //                 console.log(items);
    //                 html2 = html;
    //                 for(var key in items){
    //                     var html2 = html2.replace('<!--ile_vch1-->','');

    //                     var re = new RegExp('<!--'+key+'-->', 'g');
    //                     var html2 = html2.replace(re,items[key]);
    //                 }
    //                 $("#result_content").html(html2);
    //                 //console.log(html2);
    //                 mainFunctionEdit(id_ile);

    //             }
    //         }
    //     }else{
    //         alert("error");
    //         console.log("error");
    //     }
    // });
}
function mainFunctionEdit(id_ile,dlday) {
      if(dlday == false){
         $('#button3').hide();
         $('#button2').show();
        }else{
          $('#button3').show();
         $('#button2').hide();
    }
    $("#button3").click(function () {

        var token = getCookie('token');
       
        //dataz['token'] = token;
        console.log(dataz);
        $.ajax({
            type:"POST",
            url:base_url+"api/apiile/iles/"+id_ile,
            data:{token:token,type:"update",dlday:0},
            success:function(data){
                    alert(data.message);
                    location.reload();
            },
            error:function(data){
       
                console.log(data.responseText);
                
            }


        });

    });
    $("#button4").click(function () {
        location = "./list.html";
    });
    $('#button2').click(function(){

         if(confirm("Are you sure ?")) {
            var parent = $(this).parent().parent('tr');
            var token = getCookie('token');
            let id = $('#ile_mid').val();
            $.ajax({
                type:"DELETE",
                url:base_url+"api/apiile/iles/"+id,
                success: function(data){
                   
                        parent.remove();
                         location.reload();
                    
                }

            });
          
        }
    });

    $("#button1").click(function () {
        var token = getCookie('token');
        var dataz = $("#myForm").serialize()+"&token="+token+"&type=update";
        //dataz['token'] = token;
        console.log(dataz);
        $.ajax({
            type:"POST",
            url:base_url+"api/apiile/iles/"+id_ile,
            data:dataz,
            success:function(data){
                    location.reload();
            },
            error:function(data){
                    field = JSON.parse(data.responseText);
                    if(field.field){
                        $(".dat_error").remove();
                        $("#"+field.field).after(field.message);
                    }
                   
                
            }


        });
        
    });
}
function checkLoginz() {
    var token = getCookie('token');
    if(!token){
             location = '/html/login/index.html';
    }
    $.ajax({
        type:'POST',
        url:base_url+"check-login",
        data:{token:token},
        success:function(data){
            // console.log(data);
        },
        error:function(data){
            location = '/html/login/index.html';
            // console.log(data.responseText);
        }


    });
   
}
