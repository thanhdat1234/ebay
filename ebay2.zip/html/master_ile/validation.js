$(document).ready(function() {

  $("#myForm").validate({
    rules: {
     // <!-- 検索キーワード -->
      searchKey: {
        required: false,
        minlength: 0,
      },
    //  <!-- ID -->
      usr_mid: {
        required: true,
        alphanum: true,
        maxlength: 10
      },
  //    <!-- Name -->
      usr_vch0: {
        required: true,
        minlength: 1,
        maxlength: 200
      },
   //   <!--Nick Name-->
      usr_vch1: {
        required: true,
        minlength: 1,
        maxlength: 200,
      },
    //  <!--Notes-->
      usr_vch2: {
        maxlength: 20
      },

     // <!-- MenuID -->
      usr_int0: {
        required: true,
        number: 10
      },
    //  <!-- SalesCategory -->
      usr_int1: {
        required: true,
        number: 10
      },
     // <!-- ParentID -->
      usr_int2: {
        required: true,
        number: 10
      },
    }
  });

 // <!-- Additional Method (Unuse) -->
  jQuery.validator.addMethod(
    "usrVch0ValidateCheck",
    function(val, elem){
      var result = false;

      if (val !== '') {
          result = true;
      } else {
          result = false;
      }

      return result;
    },
    '組織コートを確認してください。'
  );
});
