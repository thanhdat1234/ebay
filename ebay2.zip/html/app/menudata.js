// menu on top for admin
var menuAminTop = [
    /*{ "title_JP": "ReMake", "title_US": "MasterMaintenance", "title_VN": "Dữ liệu chủ", "link": "#"},
    { "title_JP": "ReMake", "title_US": "SwitchAuth", "title_VN": "Chuyển đổi", "link": "#"}*/
];
//menu on second rakuten for admin
var menuAdminSecondRakuten = [
    {
        "title_JP": "マスタ管理",
        "title_US": "Master",
        "title_VN": "Dữ liệu chủ",
        "list":[
            { "title_JP": "ユーザ", "title_US": "User", "title_VN": "Người dùng", "link": $app_url+"/master_usr/list.html", "target": "_blank"},
            { "title_JP": "部署", "title_US": "Department", "title_VN": "Bộ phận", "link": $app_url+"/master_grp/list.html", "target": "_blank"},
            { "title_JP": "所属", "title_US": "Department", "title_VN": "Bộ phận", "link": $app_url+"/master_usa/list.html", "target": "_blank"},
            { "title_JP": "アイテム", "title_US": "Item", "title_VN": "Danh mục", "link": $app_url+"/master_itm/list.html", "target": "_blank"}
            //,{ "title_JP": "操作ログ照会", "title_US": "Display operation log", "title_VN": "Hiển thị lịch sử hoạt động", "link": "system_log/list.html", "target": "_blank"}
        ]
    }
];
//menu on second config for admin
var menuAdminSecondConfig = [
    {
        "title_JP": "楽天",
        "title_US": "Rakuten",
        "title_VN": "Rakuten",
        "list":[
            { "title_JP": "カテゴリ", "title_US": "Category", "title_VN": "Thể loại", "link": "set_rakuten/list.html", "target": "_blank"}
        ]
    },
    {
        "title_JP": "Yahoo",
        "title_US": "Yahoo",
        "title_VN": "Yahoo",
        "list":[
            { "title_JP": "カテゴリ", "title_US": "Category", "title_VN": "Thể loại", "link": "set_yahoo/list.html", "target": "_blank"}
        ]
    },
];
//menu on second master for admin
var menuAdminSecondMaster = [
    {
        "title_JP": "マスタ管理",
        "title_US": "Master",
        "title_VN": "Dữ liệu chủ",
        "list":[
            { "title_JP": "ユーザ", "title_US": "User", "title_VN": "Người dùng", "link": "master_usr/list.html", "target": "_blank"},
            { "title_JP": "部署", "title_US": "Department", "title_VN": "Bộ phận nhóm", "link": "master_grp/list.html", "target": "_blank"},
            { "title_JP": "所属", "title_US": "Department", "title_VN": "Bộ phận", "link": "master_usa/list.html", "target": "_blank"},
            //,{ "title_JP": "操作ログ照会", "title_US": "Display operation log", "title_VN": "Hiển thị lịch sử hoạt động", "link": "system_log/list.html", "target": "_blank"}
        ]
    }
];


//menu on top for master
var menuMasterTop = [
    { 
        "title_JP": "ユーザー追加", 
        "title_US": "Add Customer", 
        "title_VN": "Add Customer", 
        "link": "manager_usr/list.php",
        "list": [],
        "target": "_blank"
    }
];

//menu on second master for Master
var menuMasterSecondMaster = [
    {
        "title_JP": "マスタ管理",
        "title_US": "Master",
        "title_VN": "Dữ liệu chủ",
        "list":[
            { "title_JP": "ユーザ", "title_US": "User", "title_VN": "Người dùng", "link": "master_usr/list.html", "target": "_blank"}
        ]
    }
];


//menu on top for user 
var menuUserTop = [
    { "title_JP": "ebayアカウント設定",   "title_US": "ebay Account", "title_VN": "Đường dẫn", "link": "usr_eby/index.html", "target": ""},
    { "title_JP": "販売アイテム",       "title_US": "Selling Item", "title_VN": "Đường dẫn", "link": "usr_ile/index.html", "target": ""},
    { "title_JP": "カテゴリー",       "title_US": "Category", "title_VN": "Danh Mục", "link": "usr_ebc/index.html", "target": ""},
    { "title_JP": "ポリシー",       "title_US": "Policy", "title_VN": "Chính sách", "link": "usr_plc/index.html", "target": ""},
    { "title_JP": "住所",       "title_US": "Address", "title_VN": "Địa chỉ", "link": "usr_plc/index.html", "target": ""},
    { "title_JP": "その他", "title_US": "Link", "title_VN": "Đường dẫn", "link": "usr_minfo/index.html", "target": ""}
];
//menu on second rakuten for user
var menuUserSecondShoplist = [{
        "title_JP": "Rakuten(楽天)",  
        "title_US": "Rakuten",           
        "title_VN": "Rakuten", 
        "list":[
            { "title_JP": "新規店舗", "title_US": "NewArraival", "title_VN": "Sản phẩm mới", "link": "list_rakuten02/index.html", "target": "_blank"},
            { "title_JP": "検索", "title_US": "Search", "title_VN": "Tìm kiếm", "link": "list_rakuten03/index.html", "target": "_blank"},
            { "title_JP": "PRSearch", "title_US": "PRSearch", "title_VN": "PRSearch", "link": "list_rakuten04/index.html", "target": "_blank"},
            { "title_JP": "PRSearch2", "title_US": "PRSearch2", "title_VN": "PRSearch2", "link": "list_rakuten05/index.html", "target": "_blank"}
        ]
    }
];

//menu on second link for User
var menuUserSecondLink = [
    {
        "title_JP": "その他", 
        "title_US": "Etc",          
        "title_VN": "Etc",
        "list":[
            { "title_JP": "アカウント設定", "title_US": "Account", "title_VN": "Account", "link": "usr_minfo/index.html", "target": ""},
            { "title_JP": "ebay APITest", "title_US": "ebay APITest", "title_VN": "ebay APITest", "link": "usr_api/index.html", "target": ""}, 
            { "title_JP": "ebay APITest2", "title_US": "ebay APITest2", "title_VN": "ebay APITest2", "link": "usr_api2/index.html", "target": ""},
            { "title_JP": "Fullfilment Policy", "title_US": "Fullfilment Policy", "title_VN": "Fullfilment Policy", "link": "usr_ffp/index.html", "target": ""}    
        ]
    }
];

// config other text by lang - account -login ...menu lang
var confLang = [
    {
        "code": "001",
        "titlefield": "title_JP",
        "text": "JP",
        "auth": "アカウント",
        "logout": "ログアウト"
    },
    {
        "code": "002",
        "titlefield": "title_US",
        "text": "US",
        "auth": "Account",
        "logout": "Logout"
    },
    {
        "code": "003",
        "text": "VN",
        "titlefield": "title_VN",
        "auth": "Tài khoản",
        "logout": "đăng xuất"
    }
];
/*
pageid is path url of parent page will show this menu (show on parent page and it's child page), if not exist, mean show on all page
such as shoplist have pageid = list/index
 */
var configMenu = new Object();
//configMenu.menuMode = "PHP"; // php or html or "" if html => all link such as master.php => master.html if "" no change extension file
configMenu.menuMode = "html"; // php or html or "" if html => all link such as master.php => master.html if "" no change extension file
configMenu.confMenu = [
    // Admin
    {"author": "102", "position": "01", "Menu": menuAminTop},
    {"author": "102", "position": "02", "pageid": "rakuten/index", "Menu": menuAdminSecondRakuten},
    {"author": "102", "position": "02", "pageid": "manage/index", "Menu": menuAdminSecondConfig},
    {"author": "102", "position": "02", "pageid": "master/index", "Menu": menuAdminSecondMaster},
    
    // Master
    {"author": "200", "position": "01", "Menu": menuMasterTop},
    {"author": "200", "position": "02", "pageid": "rakuten/index", "Menu": menuAdminSecondRakuten},
    
    //User
    {"author": "201", "position": "01", "Menu": menuUserTop},
    {"author": "201", "position": "02", "pageid": "usr_sye/1st", "Menu": menuUserSecondShoplist},
    {"author": "201", "position": "02", "pageid": "usr_sye/2st", "Menu": menuUserSecondShoplist},
    {"author": "201", "position": "02", "pageid": "usr_sye/3st", "Menu": menuUserSecondShoplist},
    {"author": "201", "position": "02", "pageid": "usr_minfo/index", "Menu": menuUserSecondLink}
];

//define author value - 102 is admin, 200 is master, 201 is user
var authorDebug = '102';
var parentPageIdDebug = 'master/index';
var ownPageIdDebug = 'master/index';
var defaultLangCode = "001";