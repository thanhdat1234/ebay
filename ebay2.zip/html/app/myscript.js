//var base_url = 'http://ebay.local/';
/**
    * Auth : Nguyen Thanh Dat
    * Mail : thanhdat@allgrow-labo.jp
 * * */
$("#logout").click(function(){
    getLogout();
});
function setCookie(cname, cvalue, expires) {
    var expiresz = '';
    if(!expires){
        var d = new Date();
        d.setTime(d.getTime() + (1*24*60*60*1000));
        expiresz = "expires="+ d.toUTCString();
    }else{
        expiresz = "expires="+ expires;
    }
    document.cookie = cname + "=" + cvalue + ";" + expiresz + ";path=/";
}
function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
function deleteCookie(cname,cvalue) {
    document.cookie = cname+"="+cvalue+"; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
}
function deleteAllCookie() {
    var cookies = document.cookie.split(";");
    for (var i = 0; i < cookies.length; i++)
        eraseCookie(cookies[i].split("=")[0]);
}
function checkLogin() {
    var $token = getCookie('user_token');
    
    if($token) {
        //location = '../top/index.html';
        return $token;

    } else {
        return false;
        location = $app_url+'/login/index.html';
        return false;
    }

}
function getLogout() {
    if(confirm('Are you sure?')){
        console.log('ok');
        $.removeCookie('user_token', {path: '/'});
        $.removeCookie('group_id', { path: '/' });
        //deleteCookie('token',token);
        location = $app_url+'/login/index.html';
    }
}
/*function html*/
/*function show option*/
function showOptionData($data,$element_html,$text){
    if(!$data){
        alert('undefine data !');
        console.log('fail');
        return;
    }
    if(!$element_html){
        alert('undefine element !');
        console.log('fail');
        return;
    }
    var $html_optionx = $html_optionz.html();
    var html = '';
    for(var i =0;i< data.length;i++){
        var items = data[i];

        var html2 = $html_optionx;
        for(var key in items){
            if(!items[key]){
                continue;
            }
            var re = new RegExp('<!--'+key+'-->', 'g');
            var html2 = html2.replace(re,items[key]);
        }
        html += html2;
    }
    $html_optionz.html(html);
    voidMain();
}
/*function show data*/
