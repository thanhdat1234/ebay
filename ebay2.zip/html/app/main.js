function setCookie(cname, cvalue, expires) {
    var expiresz = '';
    if(!expires){
        var d = new Date();
        d.setTime(d.getTime() + (1*24*60*60*1000));
        expiresz = "expires="+ d.toUTCString();
    }else{
        expiresz = "expires="+ expires;
    }
    document.cookie = cname + "=" + cvalue + ";" + expiresz + ";path=/";
}

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function deleteCookie(cname,cvalue) {
    document.cookie = cname+"="+cvalue+"; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
}

function deleteAllCookie() {
    var cookies = document.cookie.split(";");
    for (var i = 0; i < cookies.length; i++)
        eraseCookie(cookies[i].split("=")[0]);
}

function checkLogin(){
    var $token = getCookie('user_token');
    if($token){
        //location = '../top/index.html';
        return $token;
    }else{
        return false;
        location = $app_url+'/login/index.html';
        return false;
    }
}