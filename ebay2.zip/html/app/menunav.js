$(document).ready(function () {

    var topPositionCode = "01";
    var secondPositionCode = "02";
    var topMenuId = "#infonav";
    var secondMenuId = "#menu23";
    var lang = getCurrentLanguage();
    console.log(lang);

    if ($("#menuscreentop2").length > 0) {
        //top position on admin screen (in case update.php, edit.php)
        topPositionCode = "11";
        topMenuId = "#menuscreentop2";
    }
    
	if (author == "<!—menuAuth—>") {
	    author = authorDebug;
	}
    if(getCookie('group_id')){
        author = getCookie('group_id');
    }
	if (parentPageId == '<!--parentPageId-->') {
		parentPageId = parentPageIdDebug;
	}

	if (ownPageId == '<!--ownPageId-->') {
		ownPageId = ownPageIdDebug;
	}

    //language and account
    var templateMenuLangLi = '<li><a href="#" id="lang_{code}" data-lang="{code}">{text}</a></li>';
    $("#list-menu-lang").html('');
    $.each(confLang, function(index, value){
        var htmlLi = templateMenuLangLi;
        htmlLi = htmlLi.replace(/{code}/g, value.code);
        htmlLi = htmlLi.replace(/{text}/g, value.text);
        $("#list-menu-lang").append(htmlLi);
    });   
    console.log(author);
    //render menu lang by lang when first load
    getAndSetTextWhenChangeLang(lang, confLang);
    renderTopMenu(author, topPositionCode, confLang, configMenu, topMenuId);
    renderSecondMenu(author, secondPositionCode, confLang, parentPageId, configMenu, secondMenuId);
    addActiveClassTopMenu(topMenuId, ownPageId, parentPageId);
    addActiveClassSecondMenu(secondMenuId, ownPageId, parentPageId);

    //re render menu when click change lang
    $(document).on('click', "a[id*='lang_']", function(){
        var lang = $(this).attr('data-lang');
        setCookieLang(lang);
        getAndSetTextWhenChangeLang(lang, confLang);
        renderTopMenu(author, topPositionCode, confLang, configMenu, topMenuId);
        renderSecondMenu(author, secondPositionCode, confLang, parentPageId, configMenu, secondMenuId);
        addActiveClassTopMenu(topMenuId, ownPageId, parentPageId);
        addActiveClassSecondMenu(secondMenuId, ownPageId, parentPageId);
    });
});

function addActiveClassTopMenu(objElm, ownPageId, parentPageId){
    $(objElm).find('a').each(function(){
        var liHref = $(this).attr('href');
        if (typeof(liHref) !== 'undefined') {
            if ((liHref.match(ownPageId) && ownPageId!= "") || (liHref.match(parentPageId) && parentPageId != "")) {
                //add active to current url
                $(this).parent('li').addClass('active');

                //add active class to parent li
                $(this).parent('li').parent('ul').parent('li').addClass('active');
            }
        }
    });
}
function addActiveClassSecondMenu(objElm, ownPageId, parentPageId){
    if (ownPageId != '') {        
        $(objElm).find('a').each(function(){
            var liHref = $(this).attr('href');
            if (typeof(liHref) !== 'undefined') {
                if (liHref.match(ownPageId)) {
                    $(this).parent('li').addClass('active');
                }
            }            
        });
    }
}

//set cookie for lang
function setCookieLang(lang){
    $.removeCookie('language', { path: '/' });
    $.cookie('language', lang, { path: '/' });
}
//function get current lang
function getCurrentLanguage() {
    var lang = $.cookie('language');
    if (lang == null) {
        lang = defaultLangCode;
    }
    return lang;
}

//change text language
function getAndSetTextWhenChangeLang(codeLang, configText){  
    $.each(configText, function(index, value){
        if (value.code == codeLang) {
            $('#lang').html(value.text + '<span class="caret"></span>');
            $('#auth').text(value.auth);
            $('#logout').text(value.logout);
        }
    });      
}

//render top menu
function renderTopMenu(authorCode, positionCode, confLang, config, parentElm){
    var lang = getCurrentLanguage();
    var confCurrlang = getLangByCode(lang, confLang);
    var titleFieldName = "title";
    if (typeof(confCurrlang.titlefield) !== 'undefined') {
        titleFieldName = confCurrlang.titlefield;
    }
    
    var listMenu = getMenuByLangPostionAuthor(authorCode, positionCode, '', configMenu.confMenu);
    var templateHtmlLi = '<li><a class="aMenu" href="../{link}" {target}>{title}<span class="sr-only">(current)</span></a><!--menuHtml--></li>';
    var templateHtmlLihasSubmenu = '<li class="dropdown"><a class="aMenu" href="../{link}" data-toggle="dropdown">{title}<span class="caret"></span></a><!--menuHtml--></li>';
    $(parentElm).html('<ul class="nav navbar-nav"></ul>');
    //render top menu
    if (listMenu != null) {
        if (typeof(listMenu.Menu) !== 'undefined') {
            $.each(listMenu.Menu, function(index, menuItem){
                var pageCode = menuItem.pagecode;               
                if (typeof(menuItem.link) !== 'undefined') {
                    var link = menuItem.link;
                } else {
                    var link = "";
                }
                var title = getTitleTextByFieldLang(titleFieldName, menuItem);
                var target = menuItem.target;               

                if (config.menuMode != '') {
                	if (typeof(menuItem.convert) !== 'undefined'){
                    	var convert = menuItem.convert;
                    } else {
                    	var convert = true;
                    }
                    link = changeFileExtensionName(link, config.menuMode, convert);                    
                }                
                var subMenuHtml = "";
                if (typeof(menuItem.list) !== 'undefined' && menuItem.list.length > 0){
                    var templateLi = templateHtmlLihasSubmenu; 
                    subMenuHtml = setDropdownBootstrapMenu("dropdown-menu", "", titleFieldName, config.menuMode, menuItem.list);                    
                } else {
                    var templateLi = templateHtmlLi;
                }

                templateLi = templateLi.replace(/{link}/g, link);
                templateLi = templateLi.replace(/{pageid}/g, pageCode);
                templateLi = templateLi.replace(/{title}/g, title);

                if (target != '' && typeof(target) !== 'undefined') {
                    templateLi = templateLi.replace(/{target}/g, "target="+target);
                }
                
                templateLi = templateLi.replace("<!--menuHtml-->", subMenuHtml);

                $(parentElm + '> ul').append(templateLi);
            });
        }
    }
}

//render submenu for menu
function setDropdownBootstrapMenu(className, liclassName, titleFieldName, menuMode, list){
    var tempHtml = "";
    if ($.isArray(list)) {
        $.each(list, function(index, menuItem){
            var liHtml = "<li class='"+liclassName+"'><a href='../{link}' target='{target}'>{title}</a></li>";
            var link = menuItem.link;
            var title = getTitleTextByFieldLang(titleFieldName, menuItem);
            var target = menuItem.target;
            if (typeof(menuItem.convert) !== 'undefined'){
            	var convert = menuItem.convert;
            } else {
            	var convert = true;
            }

            if (menuMode != '') {
                link = changeFileExtensionName(link, menuMode, convert);                    
            }

            liHtml = liHtml.replace(/{link}/g, link);
            liHtml = liHtml.replace(/{title}/g, title);
            liHtml = liHtml.replace(/{target}/g, target);

            tempHtml = tempHtml + liHtml;
        });
        tempHtml = '<ul class="'+className+'">' + tempHtml + '</ul>';
    }
    return tempHtml;
}

//render second menu
function renderSecondMenu(authorCode, positionCode, lang, parentPageId, config, parentElm){
    var lang = getCurrentLanguage();
    var confCurrlang = getLangByCode(lang, confLang);
    var titleFieldName = "title";
    if (typeof(confCurrlang.titlefield) !== 'undefined') {
        titleFieldName = confCurrlang.titlefield;    
    }

    var listMenu = getMenuByLangPostionAuthor(authorCode, positionCode, parentPageId, configMenu.confMenu);

    var idParentPageId = parentPageId;
    var templateHtmlLi = '<li class="list-group-item {cssClass}"><a href="../{link}" data-menu-type="{type}">{title}</a></li>';
    var templateHtmlLiNotLink = '<li class="list-group-item {cssClass}" data-type="{type}"><a>{title}</a></li>';
    $(parentElm).html('<div id="leftmenu"><ul class="list-group"></ul></div>');
    var parentUlObj = $(parentElm).find('ul');
    //render second menu
    if (listMenu != null) {
        if (typeof(listMenu.Menu) !== 'undefined') {
            $.each(listMenu.Menu, function(index, menuItem){
                if (typeof(menuItem.link) !== 'undefined') {
                    var link = menuItem.link;
                    var title = getTitleTextByFieldLang(titleFieldName, menuItem);
                    var templateLi = templateHtmlLi;

                    if (config.menuMode != '') {
                    	if (typeof(menuItem.convert) !== 'undefined'){
                        	var convert = menuItem.convert;
                        } else {
                        	var convert = true;
                        }
                        link = changeFileExtensionName(link, config.menuMode, convert);                    
                    }

                    //add title menu
                    templateLi = templateLi.replace(/{link}/g, link);
                    templateLi = templateLi.replace(/{title}/g, title);
                    templateLi = templateLi.replace(/{cssClass}/g, '');
                    templateLi = templateLi.replace(/{type}/g, idParentPageId);             
                    parentUlObj.append(templateLi);
                } else {
                    var title = getTitleTextByFieldLang(titleFieldName, menuItem);
                    var templateLi = templateHtmlLiNotLink;

                    //add title menu
                    templateLi = templateLi.replace(/{title}/g, title);
                    templateLi = templateLi.replace(/{cssClass}/g, '');    
                    templateLi = templateLi.replace(/{type}/g, idParentPageId);         
                    parentUlObj.append(templateLi);
                }

                if (typeof(menuItem.list) !== 'undefined'){
                    $.each(menuItem.list, function(key, subMenuItem){
                        var linkItm = subMenuItem.link;
                        var titleItm = getTitleTextByFieldLang(titleFieldName, subMenuItem);
                        var templateLi = templateHtmlLi;                        

                        if (config.menuMode != '') {
                        	if (typeof(subMenuItem.convert) !== 'undefined'){
	                        	var convert = subMenuItem.convert;
	                        } else {
	                        	var convert = true;
	                        }
                            linkItm = changeFileExtensionName(linkItm, config.menuMode, convert);                    
                        }

                        //add title menu
                        templateLi = templateLi.replace(/{link}/g, linkItm);
                        templateLi = templateLi.replace(/{title}/g, titleItm);
                        templateLi = templateLi.replace(/{cssClass}/g, 'sub-menu-item'); 
                        templateLi = templateLi.replace(/{type}/g, idParentPageId);            
                        parentUlObj.append(templateLi);
                    });    
                }
                       
            });
        }
    }
}

//get title by language from menu config
function getTitleTextByFieldLang(titleFieldName, itemMenu){
    if (typeof(itemMenu[titleFieldName]) !== 'undefined') {
        return itemMenu[titleFieldName];
    }

    return "";
}

//get config lang by code
function getLangByCode(codeLang, configText){  
    var result = null;
    $.each(configText, function(index, value){
        if (value.code == codeLang) {
            result = value;
        }
    });   
    return result;   
}

//get menu by code and pageid, if pageId == "" get lastest menu match search condition
function getMenuByLangPostionAuthor(author, position , pageId, config) {
    var menuTarget = null;
    $.each(config, function(index, menu){
        if (author == menu.author && position ==  menu.position) {
            if (pageId != '') {
                if (menu.pageid == pageId) {
                     menuTarget = menu;
                }               
            } else {
                menuTarget = menu;
            }            
        }              
    });   
    return menuTarget;
}

//get extension from url
function changeFileExtensionName(url, menuMode, convert) {
    var link = url;
    "use strict";
    if (url === null) {
        return "";
    }
    var index = url.lastIndexOf("/");
    if (index !== -1) {
        url = url.substring(index + 1);
    }
    index = url.indexOf("?");
    if (index !== -1) {
        url = url.substring(0, index);
    }
    index = url.indexOf("#");
    if (index !== -1) {
        url = url.substring(0, index);
    }
    var lastPath = url;
    index = url.lastIndexOf(".");

    var extension = (index !== -1 )? url.substring(index + 1): "";

    if (extension != "" && convert != false) {
        if (extension.toLowerCase() != menuMode.toLowerCase()) {
            link = link.replace("." + extension, "." + menuMode.toLowerCase());
        }
    }

    return link;
};