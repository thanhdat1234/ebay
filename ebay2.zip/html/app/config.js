/**
 * Auth : Nguyen Dat
 * Date : 10m-20d-2017y
 * Email: thanhdat@allgrow-labo.jp
 */
var $api_url              = 'http://192.168.33.10:8085/codeigniter-restful/';
var $app_url              = 'http://192.168.33.10:8085//html\/';
//var $language             = 'japan';
var $language = 'english';
//var $language = 'vietnam';
//this function includes all necessary js files for the application
function include(file)
{

  var script  = document.createElement('script');
  script.src  = file;
  script.type = 'text/javascript';
  script.defer = true;
  console.log(script);
  $('#script_file').append(script);
}

/*include('app/main.js');
include('app/app_function.js');*/

/*define name param*/
var $x_api_lang        = 'X-AGL-API-ACCEPT-LANGUAGE';
var $x_api_callname    = 'X-AGL-API-USER-CALL-NAME';
var $x_api_access_key  = 'X-AGL-API-ACCESS-KEY';
var $x_api_user_token  = 'X-AGL-API-TOKEN-AUTHOR';