/*$('#login').click(function(){
     $.ajax({
            type: "POST",
            url: base_url+'api/auth/login',
            data: $('#form1').serialize(),
            success: function (data) {
                
                   if(data.status === 1){
                        setCookie('token', data.content, 1);
                        $.cookie('auth', data.Auth, { path: '/' });
                         location = '../master_usr/list.html';
                        
                    }
            },
           error:function (xhr, ajaxOptions, thrownError){
                if(xhr.status==404) {
                   var dataz = JSON.parse(xhr.responseText);
                   alert(dataz.message);
                }
            }
        });

    
});*/

var login = function(){
    $("#error").html('');
    $("#error").hide();
    var data = $('form[name="loginForm"]').serialize();
    $.ajax({
        url: $api_url+"api/usr.dll",
        data: data,
        type: "POST",
        dataType: "JSON",
        beforeSend: function(xhr){
            xhr.setRequestHeader($x_api_callname,'getLoginToken');
            xhr.setRequestHeader($x_api_lang,$language);
        },
        error: function (request, error,res) {
            var error_list = arguments[0].responseJSON.errors.error;
            if(Array.isArray(error_list)){
                for(var i=0;i< error_list.length;i++){
                    $("#error").append(error_list[i]['longMessage']+"<br>");
                }
            }else{
                $("#error").append(error_list['longMessage']);
            }
            $("#error").show();
        },
        success: function(res,status){
            if(status == 'success'){
                if(res.ack == 'success'){
                    if(res.AccountResponse){
                        //console.log(res.AccountResponse.expire_time);
                        setCookie('user_token',res.AccountResponse.user_token,res.AccountResponse.expire_time);
                        setCookie('group_id',res.AccountResponse.grp_id,res.AccountResponse.expire_time);
                        location = $app_url+'/top/index.html';
                    }else{
                        console.log('fail');
                    }
                }else{
                    console.log('fail');
                }
            }else{
                console.log('fail');
            }
        }

    });
}
$('form[name="loginForm"]').unbind('submit').bind('submit',login);
var $token = checkLogin();
if($token){
    location = $app_url+'/top/index.html'
}
console.log($token);