// Define the `phonecatApp` module
//var $ = require('jquery');
var login = angular.module('login', []);

login.controller('LoginControllerHead',function LoginControllerHead($scope,$http) {

    $scope.title_tag = "This is login page";

});

if(getCookie('user_token')) {

    location = $app_url+'/top/index.html';

}

login.controller('LoginController', function LoginController($scope,$http) {

    $scope.name = 'AGL- Login';

    $("#tex").unbind().bind('click',function () {

        $http.get("test.json")
          .then( function(response) {
              $scope.item = response.data[0];
              console.log(response.data);
              console.log(response.status);
              console.log(response.headers);
              console.log(response.config);
              //$scope.o= response;
          },function (error) {
              console.log(error);
              $("#tex").text('can\'t sent request !'+error.statusText);
          });

    });

});

login.controller('FormController', function FormController($scope,$http) {

    $scope.submit = function($request) {

        $("#error").html('');
        $("#error").hide();
        var data = $('form[name="loginForm"]').serialize();

        $.ajax({
            
            url: $api_url+"api/usr.dll",
            data: data,
            type: "POST",
            dataType: "JSON",
            beforeSend: function(xhr) {
                xhr.setRequestHeader($x_api_callname,'getLoginToken');
                xhr.setRequestHeader($x_api_lang,$language);
            },
            error: function (request, error) {
                var error_list = arguments[0].responseJSON.errors.error;
                if(Array.isArray(error_list)) {
                    for(var i=0;i< error_list.length;i++) {
                        $("#error").append(error_list[i]['longMessage']+"<br>");
                    }
                } else {
                    $("#error").append(error_list['longMessage']);
                }
                $("#error").show();
            },
            success: function(res,status) {

                if(status == 'success') {
                    if(res.ack == 'success') {
                        if(res.AccountResponse) {
                            console.log(res.AccountResponse.expire_time);
                            setCookie('user_token',res.AccountResponse.user_token,res.AccountResponse.expire_time);
                            location = $app_url+'/top/index.html'
                        }else {
                            console.log('fail');
                        }
                    } else {
                        console.log('fail');
                    }
                } else {
                    console.log('fail');
                }
                
            }

        });
    }
});