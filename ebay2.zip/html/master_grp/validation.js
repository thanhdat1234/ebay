$(document).ready(function() {
  <!--Validation Check-->
  $("#myForm").validate({
    rules: {
   
      searchKey: {
        required: false,
        minlength: 0,
      },
   
      grp_mid: {
        required: true,
        alphanum: true,
        maxlength: 10
      },
     
      grp_vch0: {
        required: true,
        minlength: 1,
        maxlength: 200
      },
    
      grp_vch1: {
        required: true,
        minlength: 1,
        maxlength: 200,
      },
     
      grp_vch2: {
        maxlength: 20
      },

   
      grp_int0: {
        required: true,
        number: 10
      },
    
      grp_int1: {
        required: true,
        number: 10
      },
  
      grp_int2: {
        required: true,
        number: 10
      },
    }
  });

 
  jQuery.validator.addMethod(
    "grpVch0ValidateCheck",
    function(val, elem){
      var result = false;

      if (val !== '') {
          result = true;
      } else {
          result = false;
      }

      return result;
    },
    '組織コートを確認してください。'
  );
});
