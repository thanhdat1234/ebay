var $token = checkLogin();
if($token == false) {
    location = $app_url+"/login/index.html";
}

$(document).ready(function () {
//checkLoginz();
var url = document.URL;
var id = url.substring(url.lastIndexOf('id=') + 3);

htmlEditFunction(id);

});

function htmlEditFunction(id_grp) {

    var token = getCookie('token');
    var html = $("#result_content").html();

    var data = {group_id:id_grp};

    $.ajax({ 

        url: $api_url+"api/group.dll",

        data: data,

        type: "GET",

        dataType: "JSON",

        beforeSend: function(xhr) {

            xhr.setRequestHeader($x_api_access_key,$token);
            xhr.setRequestHeader($x_api_callname,'getGroup');
            xhr.setRequestHeader($x_api_lang,$language);

        },

        success: function(data) {
        
        //console.log(data);

        if(data) {

            var html_show = '';
            var items = data;

            html2 = html;

            for(var key in items.ListGroupResponse.Items) {

                var re = new RegExp('<!--'+key+'-->', 'g');
                var value = items.ListGroupResponse.Items[key] ? items.ListGroupResponse.Items[key]:'';

                var html2 = html2.replace(re,value);
            
            }
            
            $("#result_content").html(html2);

            if(items['grp_dlday']) {
                console.log(items['grp_dlday']);
                mainFunctionEdit(id_grp,true);
            } else {
                mainFunctionEdit(id_grp,false);
            }

        }
    },

    error:function(data){
         //location = "./list.html";
    }

    });

}

function mainFunctionEdit(id_grp,dlday) {

    if(dlday == false) {

        $('#button3').hide();
        $('#button2').show();

    } else {

        $('#button3').show();
        $('#button2').hide();

    }

    $("#button4").click(function () {
        location = "./list.html";
    });

    $("#button3").click(function () {

        var token = getCookie('token');
       
        //dataz['token'] = token;
        // console.log(dataz);

        $.ajax({
            type:"POST",
            url:base_url+"api/apigroup/groups/"+id_grp,
            data:{token:token,type:"update",dlday:0},
            success:function(data){
                    // alert(data.message);
                    location.reload();
            },
            error:function(data){
       
                console.log(data.responseText);
                
            }
        });

    });

    $('#button2').click(function() {

        if(confirm("Are you sure ?")) {

            var parent = $(this).parent().parent('tr');
            var token = getCookie('token');
            let id = $('#grp_mid').val();
            $.ajax({
                type:"DELETE",
                url:base_url+"api/apigroup/groups/"+id,
                success: function(data){
                   
                    parent.remove();
                    location.reload();
                    
                }

            });
          
        }
    });

    $("#button1").click(function () {

        var token = getCookie('user_token');

        var dataz = $("#myForm").serialize()+"&token="+token+"&type=update";

        console.log(dataz);

        $.ajax({
            type:"PUT",
            url: $api_url+"api/group.dll",
            data:dataz,
            dataType: "JSON",
            beforeSend: function(xhr){

                xhr.setRequestHeader($x_api_access_key,token);
                xhr.setRequestHeader($x_api_callname,'updateGroup');
                xhr.setRequestHeader($x_api_lang,"english");

            },

            success:function(data) {

                console.log(data.ack);
                if (data.ack == "success") {
                    $(".alert-success").removeClass("hide");
                    
                }

            },

            error:function(data) {

                // field = JSON.parse(data.responseText);
                // if(field.field) {
                //     $(".dat_error").remove();
                //     $("#"+field.field).after(field.message);
                // }
            }
        });

    });
}

function checkLoginz() {

    var token = getCookie('token');
    if(!token) {
        location = '/html/login/index.html';
    }

    $.ajax({

        type:'POST',
        url:base_url+"check-login",
        data:{token:token},
        success:function(data){
            // console.log(data);
        },
        error:function(data){
            location = '/html/login/index.html';
            // console.log(data.responseText);
        }

    });
   
}